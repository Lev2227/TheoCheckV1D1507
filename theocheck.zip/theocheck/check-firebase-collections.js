// Simple script to check Firebase collections and their content
import 'dotenv/config';
import admin from 'firebase-admin';
import fs from 'fs';

// Check if the credentials file exists
let credentialsPath = './firebase-credentials.json';
if (!fs.existsSync(credentialsPath)) {
  credentialsPath = './sermon-gpt-firebase-adminsdk-fbsvc-e4ac4541f5.json';
  if (!fs.existsSync(credentialsPath)) {
    console.error('Firebase credentials file not found. Please provide a valid credentials file.');
    process.exit(1);
  }
}

// Initialize Firebase Admin
try {
  admin.initializeApp({
    credential: admin.credential.cert(JSON.parse(fs.readFileSync(credentialsPath, 'utf8')))
  });
  console.log('Firebase Admin initialized successfully');
} catch (error) {
  console.error('Error initializing Firebase Admin:', error);
  process.exit(1);
}

const db = admin.firestore();

// Function to check and print collection statistics
async function checkCollections() {
  console.log('\n============ FIREBASE COLLECTIONS SUMMARY ============');
  
  try {
    // List all collections in the database
    const collections = await db.listCollections();
    console.log('All collections in Firebase:');
    for (const collection of collections) {
      console.log(`- ${collection.id}`);
    }
    console.log('');
    
    // Check users collection
    const usersSnapshot = await db.collection('users').get();
    console.log(`Users collection: ${usersSnapshot.size} documents`);
    
    // Check auth_users collection if it exists
    try {
      const authUsersSnapshot = await db.collection('auth_users').get();
      console.log(`auth_users collection: ${authUsersSnapshot.size} documents`);
    } catch (e) {
      console.log('No auth_users collection found');
    }
    
    // Check sermons collection
    const sermonsSnapshot = await db.collection('sermons').get();
    console.log(`Sermons collection: ${sermonsSnapshot.size} documents`);
    
    // Sample user data (first 2 users)
    console.log('\n----- Sample User Data -----');
    let userCount = 0;
    for (const doc of usersSnapshot.docs) {
      if (userCount < 2) {
        const userData = doc.data();
        console.log(`User ID: ${doc.id}`);
        console.log(`Email: ${userData.email || 'N/A'}`);
        console.log(`Display Name: ${userData.displayName || 'N/A'}`);
        console.log(`Registration Date: ${userData.registrationDate ? new Date(userData.registrationDate.toDate()).toISOString() : 'N/A'}`);
        console.log('---');
      }
      userCount++;
    }
    
    // Sample sermon data (first 2 sermons)
    console.log('\n----- Sample Sermon Data -----');
    let sermonCount = 0;
    for (const doc of sermonsSnapshot.docs) {
      if (sermonCount < 2) {
        const sermonData = doc.data();
        console.log(`Sermon ID: ${doc.id}`);
        console.log(`Title: ${sermonData.title || 'N/A'}`);
        console.log(`User ID: ${sermonData.userId || 'N/A'}`);
        console.log(`Content Length: ${sermonData.content ? sermonData.content.length : 0} characters`);
        console.log(`Has Analysis: ${sermonData.analysis ? 'Yes' : 'No'}`);
        console.log('---');
      }
      sermonCount++;
    }
    
    console.log('\n============ END OF SUMMARY ============');
    
  } catch (error) {
    console.error('Error checking collections:', error);
  } finally {
    process.exit(0);
  }
}

// Run the check
checkCollections().catch(console.error);