# TheoCheck - System Flow Diagrams

## 1. Overall System Architecture

```
┌─────────────────────┐    ┌─────────────────────┐    ┌─────────────────────┐
│                     │    │                     │    │                     │
│   FRONTEND          │    │   BACKEND           │    │   EXTERNAL APIs     │
│   (React + TS)      │    │   (Node.js/Express)│    │                     │
│                     │    │                     │    │                     │
│ ┌─────────────────┐ │    │ ┌─────────────────┐ │    │ ┌─────────────────┐ │
│ │ User Interface  │ │    │ │ REST API        │ │    │ │ OpenAI API      │ │
│ │ - Auth Pages    │ │    │ │ - Auth Routes   │ │    │ │ - GPT-4 Analysis│ │
│ │ - Sermon Form   │ │    │ │ - Sermon Routes │ │    │ │                 │ │
│ │ - Dashboard     │ │    │ │ - Analytics     │ │    │ ┌─────────────────┐ │
│ │ - Analysis View │ │    │ │ - Payment       │ │    │ │ Firebase        │ │
│ └─────────────────┘ │    │ └─────────────────┘ │    │ │ - Auth          │ │
│                     │    │                     │    │ │ - Firestore     │ │
│ ┌─────────────────┐ │    │ ┌─────────────────┐ │    │ │                 │ │
│ │ State Management│ │    │ │ Data Processing │ │    │ ┌─────────────────┐ │
│ │ - TanStack Query│ │    │ │ - Drizzle ORM   │ │    │ │ Stripe API      │ │
│ │ - Local State   │ │    │ │ - Firebase SDK  │ │    │ │ - Payments      │ │
│ └─────────────────┘ │    │ │ - Analytics     │ │    │ │ - Webhooks      │ │
│                     │    │ └─────────────────┘ │    │ └─────────────────┘ │
└─────────────────────┘    └─────────────────────┘    └─────────────────────┘
         │                            │                            │
         │ HTTP/WebSocket             │ HTTPS/API Calls           │
         │                            │                            │
         └────────────────────────────┼────────────────────────────┘
                                      │
                              ┌───────▼───────┐
                              │   DATABASE    │
                              │  PostgreSQL   │
                              │               │
                              │ ┌───────────┐ │
                              │ │  Sermons  │ │
                              │ │   Users   │ │
                              │ │ Analytics │ │
                              │ └───────────┘ │
                              └───────────────┘
```

## 2. Sermon Analysis Workflow

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   USER      │    │  FRONTEND   │    │  BACKEND    │    │  OPENAI     │
│  PASTOR     │    │   REACT     │    │  EXPRESS    │    │    API      │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
       │                   │                   │                   │
       │ 1. Submit Sermon  │                   │                   │
       ├──────────────────►│                   │                   │
       │                   │ 2. Validate Input│                   │
       │                   ├──────────────────►│                   │
       │                   │                   │ 3. Save to DB     │
       │                   │                   ├──────────────────►│
       │                   │                   │                   │ Database
       │                   │                   │ 4. AI Analysis    │
       │                   │                   ├──────────────────►│
       │                   │                   │                   │
       │                   │                   │ 5. AI Response    │
       │                   │                   │◄──────────────────┤
       │                   │                   │                   │
       │                   │                   │ 6. Process Result │
       │                   │                   │ & Track Analytics │
       │                   │                   │                   │
       │                   │ 7. Return Analysis│                   │
       │                   │◄──────────────────┤                   │
       │ 8. Display Results│                   │                   │
       │◄──────────────────┤                   │                   │
       │                   │                   │                   │
```

## 3. Analytics Dashboard Data Flow

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  DASHBOARD  │    │  BACKEND    │    │  FIREBASE   │    │ POSTGRESQL  │
│   FRONTEND  │    │   API       │    │ FIRESTORE   │    │  DATABASE   │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
       │                   │                   │                   │
       │ 1. Request KPIs   │                   │                   │
       ├──────────────────►│                   │                   │
       │                   │ 2. Query Firebase │                   │
       │                   ├──────────────────►│                   │
       │                   │                   │ 3. Return Data    │
       │                   │◄──────────────────┤                   │
       │                   │                   │                   │
       │                   │ 4. Query Database │                   │
       │                   ├──────────────────►│                   │
       │                   │                   │ 5. Return Data    │
       │                   │◄──────────────────┤                   │
       │                   │                   │                   │
       │                   │ 6. Aggregate Data │                   │
       │                   │ & Calculate KPIs  │                   │
       │                   │                   │                   │
       │ 7. Return Metrics │                   │                   │
       │◄──────────────────┤                   │                   │
       │                   │                   │                   │
       │ 8. Render Charts  │                   │                   │
       │ & Visualizations  │                   │                   │
       │                   │                   │                   │
```

## 4. Payment Processing Flow

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│    USER     │    │  FRONTEND   │    │  BACKEND    │    │  STRIPE     │
│   DONOR     │    │   REACT     │    │  EXPRESS    │    │    API      │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
       │                   │                   │                   │
       │ 1. Select Amount  │                   │                   │
       ├──────────────────►│                   │                   │
       │                   │ 2. Create Payment │                   │
       │                   ├──────────────────►│                   │
       │                   │                   │ 3. Payment Intent │
       │                   │                   ├──────────────────►│
       │                   │                   │                   │
       │                   │                   │ 4. Client Secret  │
       │                   │                   │◄──────────────────┤
       │                   │ 5. Return Secret  │                   │
       │                   │◄──────────────────┤                   │
       │                   │                   │                   │
       │ 6. Enter Payment  │                   │                   │
       │ Details           │                   │                   │
       ├──────────────────►│                   │                   │
       │                   │ 7. Process Payment│                   │
       │                   ├──────────────────►│                   │
       │                   │                   │ 8. Confirm Payment│
       │                   │                   │◄──────────────────┤
       │                   │                   │                   │
       │                   │                   │ 9. Track Success  │
       │                   │                   │ & Update Analytics│
       │                   │                   │                   │
       │ 10. Success Page  │                   │                   │
       │◄──────────────────┤                   │                   │
       │                   │                   │                   │
```

## 5. Authentication Flow

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│    USER     │    │  FRONTEND   │    │  FIREBASE   │    │  BACKEND    │
│             │    │   REACT     │    │    AUTH     │    │  EXPRESS    │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
       │                   │                   │                   │
       │ 1. Click "Login"  │                   │                   │
       ├──────────────────►│                   │                   │
       │                   │ 2. Google Auth    │                   │
       │                   ├──────────────────►│                   │
       │                   │                   │                   │
       │ 3. Google Login   │                   │                   │
       ├──────────────────►│                   │                   │
       │                   │                   │                   │
       │ 4. ID Token       │                   │                   │
       │◄──────────────────┤                   │                   │
       │                   │ 5. Store Token    │                   │
       │                   │ & User State      │                   │
       │                   │                   │                   │
       │                   │ 6. API Requests   │                   │
       │                   │ (with auth token) │                   │
       │                   ├──────────────────►│                   │
       │                   │                   │ 7. Verify Token   │
       │                   │                   │◄──────────────────┤
       │                   │                   │                   │
       │                   │ 8. Protected      │                   │
       │                   │ Resource Access   │                   │
       │                   │◄──────────────────┤                   │
       │                   │                   │                   │
```

## 6. Real-time Analytics Tracking

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  USER       │    │  BACKEND    │    │  FIREBASE   │
│  ACTIONS    │    │  TRACKING   │    │ FIRESTORE   │
└─────────────┘    └─────────────┘    └─────────────┘
       │                   │                   │
       │ Sermon Analysis   │                   │
       ├──────────────────►│ Track Analysis    │
       │                   ├──────────────────►│
       │                   │                   │
       │ Social Share      │                   │
       ├──────────────────►│ Track Share       │
       │                   ├──────────────────►│
       │                   │                   │
       │ Donation          │                   │
       ├──────────────────►│ Track Donation    │
       │                   ├──────────────────►│
       │                   │                   │
       │ Dashboard View    │                   │
       ├──────────────────►│ Query Analytics   │
       │                   ├──────────────────►│
       │                   │                   │
       │                   │ Return KPIs       │
       │                   │◄──────────────────┤
       │ View Analytics    │                   │
       │◄──────────────────┤                   │
       │                   │                   │
```

These diagrams show the complete data flow and system interactions in TheoCheck, making it easier to understand how each component communicates and processes data throughout the platform.