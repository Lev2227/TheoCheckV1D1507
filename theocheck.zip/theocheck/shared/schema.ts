import { pgTable, text, serial, timestamp, json, decimal, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firebaseId: text("firebase_id").notNull().unique(),
  email: text("email").notNull(),
  displayName: text("display_name"),
  preferences: json("preferences").$type<UserPreferences>(),
});

export const sermons = pgTable("sermons", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  bibleReference: text("bible_reference"),
  analysis: json("analysis").$type<SermonAnalysis>(),
  topics: json("topics").$type<string[]>(),
  theologicalTradition: text("theological_tradition"),
  createdAt: timestamp("created_at").defaultNow(),
});

// KPI Tracking Tables
export const userEvents = pgTable("user_events", {
  id: serial("id").primaryKey(),
  userId: text("user_id"),
  sessionId: text("session_id"),
  eventType: text("event_type").notNull(), // 'sermon_analysis', 'sharing', 'donation', 'signup', 'login'
  eventData: json("event_data").$type<Record<string, any>>(),
  referrer: text("referrer"),
  userAgent: text("user_agent"),
  ipAddress: text("ip_address"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  userId: text("user_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default('EUR'),
  paymentMethod: text("payment_method"), // 'stripe', 'paypal', etc.
  paymentIntentId: text("payment_intent_id"),
  status: text("status").notNull(), // 'pending', 'completed', 'failed', 'refunded'
  referralSource: text("referral_source"), // How they found us
  createdAt: timestamp("created_at").defaultNow(),
});

export const sharingEvents = pgTable("sharing_events", {
  id: serial("id").primaryKey(),
  userId: text("user_id"),
  sermonId: integer("sermon_id"),
  shareMethod: text("share_method").notNull(), // 'email', 'social', 'link_copy', 'whatsapp'
  shareDestination: text("share_destination"), // Platform or email domain
  recipientEngaged: boolean("recipient_engaged").default(false), // Did recipient click/view?
  createdAt: timestamp("created_at").defaultNow(),
});

export const analysisMetrics = pgTable("analysis_metrics", {
  id: serial("id").primaryKey(),
  sermonId: integer("sermon_id").notNull(),
  userId: text("user_id").notNull(),
  analysisStartTime: timestamp("analysis_start_time").notNull(),
  analysisEndTime: timestamp("analysis_end_time"),
  modelUsed: text("model_used"), // 'gpt-4o', etc.
  tokensUsed: integer("tokens_used"),
  costEstimate: decimal("cost_estimate", { precision: 8, scale: 4 }),
  userSatisfaction: integer("user_satisfaction"), // 1-5 rating if provided
  suggestionsRequested: boolean("suggestions_requested").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const referralTracking = pgTable("referral_tracking", {
  id: serial("id").primaryKey(),
  referrerUserId: text("referrer_user_id"),
  referredUserId: text("referred_user_id"),
  referralMethod: text("referral_method"), // 'direct_share', 'referral_link', 'social_media'
  referralCode: text("referral_code"),
  conversionType: text("conversion_type"), // 'signup', 'first_analysis', 'donation'
  conversionValue: decimal("conversion_value", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export type SermonAnalysis = {
  scores: {
    fideliteBiblique: number;
    structure: number;
    applicationPratique: number;
    authenticite: number;
    interactivite: number;
  };
  overallScore: number;
  strengths: string[];
  improvements: string[];
  summary: string;
  topics: string[];
  theologicalTradition: string;
  keyScriptures: string[];
  applicationPoints: string[];
  illustrationsUsed: string[];
  audienceEngagement: {
    emotional: number;
    intellectual: number;
    practical: number;
  };
  emotionalTone: {
    joy: number;
    hope: number;
    conviction: number;
    compassion: number;
    urgency: number;
    reverence: number;
  };
};

export type SubscriptionTier = 'free' | 'premium' | 'enterprise';

export type SubscriptionInfo = {
  tier: SubscriptionTier;
  startDate: string; // ISO date string
  endDate?: string; // ISO date string, undefined if active
  features: {
    maxSermons: number;
    detailedAnalysis: boolean;
    exportFormats: string[];
    prioritySupport: boolean;
  };
  paymentHistory?: {
    date: string; // ISO date string
    amount: number;
    status: 'success' | 'failed' | 'refunded';
  }[];
  autoRenew: boolean;
};

export type UserPreferences = {
  favoriteTopics: string[];
  theologicalTradition: string;
  preferredStyle: string;
  lastViewedSermons: number[];
  subscription?: SubscriptionInfo;
};

export const insertUserSchema = createInsertSchema(users).pick({
  firebaseId: true,
  email: true,
  displayName: true,
});

export const insertSermonSchema = createInsertSchema(sermons)
  .pick({
    title: true,
    content: true,
    bibleReference: true,
  })
  .extend({
    title: z.string().min(1, "Title is required"),
    content: z.string().min(50, "Sermon content must be at least 50 characters"),
    bibleReference: z.string().optional(),
  });

// KPI Tracking Schemas
export const insertUserEventSchema = createInsertSchema(userEvents).omit({ id: true, timestamp: true });
export const insertDonationSchema = createInsertSchema(donations).omit({ id: true, createdAt: true });
export const insertSharingEventSchema = createInsertSchema(sharingEvents).omit({ id: true, createdAt: true });
export const insertAnalysisMetricSchema = createInsertSchema(analysisMetrics).omit({ id: true, createdAt: true });
export const insertReferralTrackingSchema = createInsertSchema(referralTracking).omit({ id: true, createdAt: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Sermon = typeof sermons.$inferSelect;
export type InsertSermon = z.infer<typeof insertSermonSchema>;

// KPI Tracking Types
export type UserEvent = typeof userEvents.$inferSelect;
export type InsertUserEvent = z.infer<typeof insertUserEventSchema>;
export type Donation = typeof donations.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type SharingEvent = typeof sharingEvents.$inferSelect;
export type InsertSharingEvent = z.infer<typeof insertSharingEventSchema>;
export type AnalysisMetric = typeof analysisMetrics.$inferSelect;
export type InsertAnalysisMetric = z.infer<typeof insertAnalysisMetricSchema>;
export type ReferralTracking = typeof referralTracking.$inferSelect;
export type InsertReferralTracking = z.infer<typeof insertReferralTrackingSchema>;