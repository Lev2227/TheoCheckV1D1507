// Script to migrate user data from Firebase Authentication and track registrations for KPI metrics
import 'dotenv/config';
import admin from 'firebase-admin';
import pg from 'pg';
import fs from 'fs';
const { Pool } = pg;

// Initialize Firebase Admin with credentials file
if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.cert(JSON.parse(fs.readFileSync('./firebase-credentials.json', 'utf8')))
    });
    console.log('Firebase Admin initialized successfully');
  } catch (error) {
    console.error('Error initializing Firebase Admin:', error);
    process.exit(1);
  }
}

const db = admin.firestore();
const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });

// Helper function to get week number for KPI tracking
function getWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${weekNo.toString().padStart(2, '0')}`;
}

// Helper function to get date string in YYYY-MM-DD format
function getDateString(date) {
  return date.toISOString().split('T')[0];
}

// Helper function to update KPI metrics
async function updateKPI(type, field, value, date) {
  try {
    // Check if KPI record already exists
    const result = await pgPool.query(
      'SELECT * FROM kpis WHERE type = $1 AND date = $2',
      [type, date]
    );

    if (result.rows.length > 0) {
      // Update existing record
      await pgPool.query(
        `UPDATE kpis SET ${field} = ${field} + $1 WHERE type = $2 AND date = $3`,
        [value, type, date]
      );
      console.log(`Updated ${type} KPI for ${date}, ${field} += ${value}`);
    } else {
      // Create new record with default values
      const fields = {
        new_users: 0,
        donations: 0,
        donation_amount: 0,
        shares: 0,
        submitted_sermons: 0
      };
      fields[field] = value;

      await pgPool.query(
        `INSERT INTO kpis (type, date, new_users, donations, donation_amount, shares, submitted_sermons) 
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [type, date, fields.new_users, fields.donations, fields.donation_amount, fields.shares, fields.submitted_sermons]
      );
      console.log(`Created new ${type} KPI for ${date}, ${field} = ${value}`);
    }
  } catch (error) {
    console.error(`Error updating KPI (${type}, ${date}, ${field}):`, error);
  }
}

// Check if the users table exists and create it if it doesn't
async function ensureUsersTable() {
  try {
    // Check if the users table exists
    const tableCheck = await pgPool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'users'
      );
    `);
    
    const tableExists = tableCheck.rows[0].exists;
    
    if (!tableExists) {
      console.log('Users table does not exist. Creating it...');
      
      // Create the users table
      await pgPool.query(`
        CREATE TABLE users (
          id SERIAL PRIMARY KEY,
          firebase_id TEXT UNIQUE NOT NULL,
          email TEXT NOT NULL,
          display_name TEXT,
          registration_date TIMESTAMP,
          shares JSONB DEFAULT '{"whatsapp": null, "facebook": null, "email": null}',
          submitted_sermons JSONB DEFAULT '{}'
        );
      `);
      
      console.log('Users table created successfully');
    } else {
      console.log('Users table already exists');
    }
  } catch (error) {
    console.error('Error ensuring users table exists:', error);
    throw error;
  }
}

// Extract user IDs from sermons to ensure we have all users
async function extractUsersFromSermons() {
  try {
    console.log('Extracting user IDs from sermons collection...');
    
    const sermonsSnapshot = await db.collection('sermons').get();
    const userIds = new Set();
    
    sermonsSnapshot.forEach(doc => {
      const sermon = doc.data();
      if (sermon.userId) {
        userIds.add(sermon.userId);
      }
    });
    
    console.log(`Found ${userIds.size} unique user IDs in sermons collection`);
    return Array.from(userIds);
  } catch (error) {
    console.error('Error extracting user IDs from sermons:', error);
    return [];
  }
}

// Retrieve user data from Firebase and track registrations
async function migrateUserData() {
  try {
    console.log('Starting user data migration from Firebase Authentication...');
    
    // Ensure the users table exists
    await ensureUsersTable();
    
    // Get all users from Firebase Authentication
    const listUsersResult = await admin.auth().listUsers();
    const firebaseAuthUsers = listUsersResult.users;
    
    console.log(`Found ${firebaseAuthUsers.length} users in Firebase Authentication`);
    
    // Get all users from Firestore users collection
    const usersSnapshot = await db.collection('users').get();
    console.log(`Found ${usersSnapshot.size} users in Firestore users collection`);
    
    // Extract user IDs from sermons
    const sermonUserIds = await extractUsersFromSermons();
    
    // Combine all user sources
    const combinedUserIds = new Set();
    
    // Add Authentication users
    firebaseAuthUsers.forEach(user => combinedUserIds.add(user.uid));
    
    // Add Firestore users
    usersSnapshot.forEach(doc => combinedUserIds.add(doc.id));
    
    // Add users from sermons
    sermonUserIds.forEach(id => combinedUserIds.add(id));
    
    console.log(`Combined total of ${combinedUserIds.size} unique users to process`);
    
    // Track users processed
    let processed = 0;
    let newUsers = 0;
    let errors = 0;
    
    // Process all users
    for (const userId of combinedUserIds) {
      try {
        // Check if user already exists in PostgreSQL
        const existingResult = await pgPool.query(
          'SELECT * FROM users WHERE firebase_id = $1',
          [userId]
        );
        
        if (existingResult.rows.length === 0) {
          // Try to get user from Authentication
          let email = `user-${userId.substring(0, 6)}@example.com`;
          let displayName = `User ${userId.substring(0, 6)}`;
          let creationTime = new Date();
          
          // Find user in Authentication records
          const authUser = firebaseAuthUsers.find(u => u.uid === userId);
          if (authUser) {
            email = authUser.email || email;
            displayName = authUser.displayName || displayName;
            creationTime = new Date(authUser.metadata.creationTime);
          }
          
          // Find user in Firestore
          const firestoreUserDoc = await db.collection('users').doc(userId).get();
          if (firestoreUserDoc.exists) {
            const firestoreUser = firestoreUserDoc.data();
            email = firestoreUser.email || email;
            displayName = firestoreUser.displayName || displayName;
            if (firestoreUser.registrationDate) {
              creationTime = firestoreUser.registrationDate.toDate();
            }
          }
          
          const dateStr = getDateString(creationTime);
          const weekStr = getWeekNumber(creationTime);
          
          // Create new user record in PostgreSQL
          await pgPool.query(
            `INSERT INTO users 
            (firebase_id, email, display_name, registration_date, shares, submitted_sermons) 
            VALUES ($1, $2, $3, $4, $5, $6)`,
            [
              userId,
              email,
              displayName,
              creationTime,
              JSON.stringify({ whatsapp: null, facebook: null, email: null }),
              JSON.stringify({})
            ]
          );
          
          console.log(`Created new user record: ${email} (${userId})`);
          
          // Update KPI metrics for new user registration based on creation time
          await updateKPI('daily', 'new_users', 1, dateStr);
          await updateKPI('weekly', 'new_users', 1, weekStr);
          await updateKPI('totals', 'new_users', 1, null);
          
          newUsers++;
        } else {
          console.log(`User ${userId} already exists in PostgreSQL`);
        }
        
        processed++;
      } catch (error) {
        console.error(`Error processing user ${userId}:`, error);
        errors++;
      }
    }
    
    console.log(`User migration complete. Processed: ${processed}, New users: ${newUsers}, Errors: ${errors}`);
  } catch (error) {
    console.error('Error migrating user data:', error);
  } finally {
    await pgPool.end();
  }
}

// Run the migration
migrateUserData().catch(console.error);