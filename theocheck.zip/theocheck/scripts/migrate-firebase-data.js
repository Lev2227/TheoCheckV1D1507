// Master script to migrate all data from Firebase to PostgreSQL
import 'dotenv/config';
import admin from 'firebase-admin';
import pg from 'pg';
import fs from 'fs';

const { Pool } = pg;
const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });

// Initialize Firebase Admin
try {
  admin.initializeApp({
    credential: admin.credential.cert(JSON.parse(fs.readFileSync('./firebase-credentials.json', 'utf8')))
  });
  console.log('Firebase Admin initialized successfully');
} catch (error) {
  console.error('Error initializing Firebase Admin:', error);
  process.exit(1);
}

const db = admin.firestore();

// Helper functions
function getWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${weekNo.toString().padStart(2, '0')}`;
}

function getDateString(date) {
  return date.toISOString().split('T')[0];
}

// Ensure database tables exist
async function ensureDatabaseTables() {
  try {
    console.log('Ensuring database tables exist...');
    
    // Users table
    await pgPool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        firebase_id TEXT UNIQUE NOT NULL,
        email TEXT NOT NULL,
        display_name TEXT,
        registration_date TIMESTAMP,
        shares JSONB DEFAULT '{"whatsapp": null, "facebook": null, "email": null}',
        submitted_sermons JSONB DEFAULT '{}',
        preferences JSONB DEFAULT '{"favoriteTopics": [], "theologicalTradition": "", "preferredStyle": "", "lastViewedSermons": []}'
      );
    `);
    
    // Sermons table
    await pgPool.query(`
      CREATE TABLE IF NOT EXISTS sermons (
        id SERIAL PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(firebase_id),
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        bible_reference TEXT,
        analysis JSONB,
        topics JSONB,
        theological_tradition TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    
    // Donations table
    await pgPool.query(`
      CREATE TABLE IF NOT EXISTS donations (
        id SERIAL PRIMARY KEY,
        user_id TEXT REFERENCES users(firebase_id),
        amount DECIMAL(10, 2) NOT NULL,
        currency TEXT DEFAULT 'EUR',
        payment_method TEXT,
        status TEXT NOT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    
    // KPIs table
    await pgPool.query(`
      CREATE TABLE IF NOT EXISTS kpis (
        id SERIAL PRIMARY KEY,
        type TEXT NOT NULL,
        date TEXT,
        new_users INTEGER DEFAULT 0,
        donations INTEGER DEFAULT 0,
        donation_amount DECIMAL(10, 2) DEFAULT 0,
        shares INTEGER DEFAULT 0,
        submitted_sermons INTEGER DEFAULT 0,
        UNIQUE(type, date)
      );
    `);
    
    // Newsletter subscriptions table
    await pgPool.query(`
      CREATE TABLE IF NOT EXISTS newsletter_subscriptions (
        id SERIAL PRIMARY KEY,
        user_id TEXT REFERENCES users(firebase_id),
        email TEXT NOT NULL UNIQUE,
        active BOOLEAN DEFAULT TRUE,
        locale TEXT DEFAULT 'fr',
        subscribe_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    
    // Contacts table
    await pgPool.query(`
      CREATE TABLE IF NOT EXISTS contacts (
        id SERIAL PRIMARY KEY,
        name TEXT,
        email TEXT NOT NULL,
        message TEXT NOT NULL,
        responded BOOLEAN DEFAULT FALSE,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    
    console.log('Database tables created/verified successfully');
  } catch (error) {
    console.error('Error ensuring database tables:', error);
    throw error;
  }
}

// Helper function to update KPI metrics
async function updateKPI(type, field, value, date) {
  try {
    // Check if KPI record already exists
    const result = await pgPool.query(
      'SELECT * FROM kpis WHERE type = $1 AND date = $2',
      [type, date]
    );

    if (result.rows.length > 0) {
      // Update existing record
      await pgPool.query(
        `UPDATE kpis SET ${field} = ${field} + $1 WHERE type = $2 AND date = $3`,
        [value, type, date]
      );
      console.log(`Updated ${type} KPI for ${date || 'totals'}, ${field} += ${value}`);
    } else {
      // Create new record with default values
      const fields = {
        new_users: 0,
        donations: 0,
        donation_amount: 0,
        shares: 0,
        submitted_sermons: 0
      };
      fields[field] = value;

      await pgPool.query(
        `INSERT INTO kpis (type, date, new_users, donations, donation_amount, shares, submitted_sermons) 
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [type, date, fields.new_users, fields.donations, fields.donation_amount, fields.shares, fields.submitted_sermons]
      );
      console.log(`Created new ${type} KPI for ${date || 'totals'}, ${field} = ${value}`);
    }
  } catch (error) {
    console.error(`Error updating KPI (${type}, ${date || 'totals'}, ${field}):`, error);
  }
}

// Extract all user IDs from all sources
async function collectAllUserIds() {
  try {
    console.log('Collecting all user IDs from all sources...');
    
    const userIds = new Set();
    
    // 1. Get users from Firebase Authentication
    const listUsersResult = await admin.auth().listUsers();
    listUsersResult.users.forEach(user => userIds.add(user.uid));
    console.log(`Found ${listUsersResult.users.length} users in Firebase Authentication`);
    
    // 2. Get users from Firestore users collection
    const usersSnapshot = await db.collection('users').get();
    usersSnapshot.forEach(doc => userIds.add(doc.id));
    console.log(`Found ${usersSnapshot.size} users in Firestore users collection`);
    
    // 3. Extract user IDs from sermons
    const sermonsSnapshot = await db.collection('sermons').get();
    sermonsSnapshot.forEach(doc => {
      const sermon = doc.data();
      if (sermon.userId) {
        userIds.add(sermon.userId);
      }
    });
    console.log(`Found ${sermonsSnapshot.size} sermons that might contain user IDs`);
    
    // 4. Extract user IDs from metrics collection (if it exists)
    try {
      const metricsSnapshot = await db.collection('metrics').get();
      metricsSnapshot.forEach(doc => {
        const metric = doc.data();
        if (metric.userId) {
          userIds.add(metric.userId);
        }
      });
      console.log(`Checked metrics collection for user IDs`);
    } catch (error) {
      console.log('No metrics collection found or error accessing it');
    }
    
    // 5. Extract user IDs from newsletter subscriptions
    try {
      const newsletterSnapshot = await db.collection('newsletter_subscriptions').get();
      newsletterSnapshot.forEach(doc => {
        const subscription = doc.data();
        if (subscription.userId) {
          userIds.add(subscription.userId);
        }
      });
      console.log(`Checked newsletter_subscriptions collection for user IDs`);
    } catch (error) {
      console.log('No newsletter_subscriptions collection found or error accessing it');
    }
    
    console.log(`Combined total of ${userIds.size} unique users from all sources`);
    return Array.from(userIds);
  } catch (error) {
    console.error('Error collecting user IDs:', error);
    return [];
  }
}

// Migrate users
async function migrateUsers() {
  try {
    console.log('\n=========== MIGRATING USERS ===========');
    
    // Get all user IDs from all sources
    const allUserIds = await collectAllUserIds();
    
    // Track progress
    let processed = 0;
    let created = 0;
    let updated = 0;
    let errors = 0;
    
    // Get all Firebase Auth users for lookup
    const listUsersResult = await admin.auth().listUsers();
    const authUsers = listUsersResult.users;
    
    // Process each user
    for (const userId of allUserIds) {
      try {
        // Check if user already exists in PostgreSQL
        const existingResult = await pgPool.query(
          'SELECT * FROM users WHERE firebase_id = $1',
          [userId]
        );
        
        // Initialize user data
        let userData = {
          email: `user-${userId.substring(0, 6)}@example.com`,
          displayName: `User ${userId.substring(0, 6)}`,
          registrationDate: new Date(),
          preferences: {
            favoriteTopics: [],
            theologicalTradition: '',
            preferredStyle: '',
            lastViewedSermons: []
          },
          shares: {
            whatsapp: null,
            facebook: null,
            email: null
          },
          submittedSermons: {}
        };
        
        // Get user from Firebase Auth if available
        const authUser = authUsers.find(u => u.uid === userId);
        if (authUser) {
          userData.email = authUser.email || userData.email;
          userData.displayName = authUser.displayName || userData.displayName;
          userData.registrationDate = new Date(authUser.metadata.creationTime);
        }
        
        // Get user from Firestore if available
        const firestoreUserDoc = await db.collection('users').doc(userId).get();
        if (firestoreUserDoc.exists) {
          const firestoreUser = firestoreUserDoc.data();
          userData.email = firestoreUser.email || userData.email;
          userData.displayName = firestoreUser.displayName || userData.displayName;
          
          if (firestoreUser.registrationDate) {
            userData.registrationDate = firestoreUser.registrationDate.toDate();
          }
          
          if (firestoreUser.preferences) {
            userData.preferences = firestoreUser.preferences;
          }
          
          if (firestoreUser.shares) {
            userData.shares = firestoreUser.shares;
          }
        }
        
        // Check for sermons to populate submittedSermons
        const userSermons = await db.collection('sermons')
          .where('userId', '==', userId)
          .get();
        
        userSermons.forEach(doc => {
          userData.submittedSermons[doc.id] = true;
        });
        
        // Update KPI trackers for dates
        const dateStr = getDateString(userData.registrationDate);
        const weekStr = getWeekNumber(userData.registrationDate);
        
        if (existingResult.rows.length === 0) {
          // Create new user
          await pgPool.query(
            `INSERT INTO users 
            (firebase_id, email, display_name, registration_date, shares, submitted_sermons, preferences) 
            VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [
              userId,
              userData.email,
              userData.displayName,
              userData.registrationDate,
              JSON.stringify(userData.shares),
              JSON.stringify(userData.submittedSermons),
              JSON.stringify(userData.preferences)
            ]
          );
          
          console.log(`Created user: ${userData.email} (${userId})`);
          
          // Update KPI metrics
          await updateKPI('daily', 'new_users', 1, dateStr);
          await updateKPI('weekly', 'new_users', 1, weekStr);
          await updateKPI('totals', 'new_users', 1, null);
          
          created++;
        } else {
          // Update existing user
          await pgPool.query(
            `UPDATE users SET 
              email = $1, 
              display_name = $2, 
              registration_date = $3, 
              shares = $4, 
              submitted_sermons = $5, 
              preferences = $6
            WHERE firebase_id = $7`,
            [
              userData.email,
              userData.displayName,
              userData.registrationDate,
              JSON.stringify(userData.shares),
              JSON.stringify(userData.submittedSermons),
              JSON.stringify(userData.preferences),
              userId
            ]
          );
          
          console.log(`Updated user: ${userData.email} (${userId})`);
          updated++;
        }
        
        processed++;
      } catch (error) {
        console.error(`Error processing user ${userId}:`, error);
        errors++;
      }
    }
    
    console.log(`\nUsers migration complete: Processed ${processed}, Created ${created}, Updated ${updated}, Errors ${errors}`);
  } catch (error) {
    console.error('Error migrating users:', error);
  }
}

// Migrate sermons
async function migrateSermons() {
  try {
    console.log('\n=========== MIGRATING SERMONS ===========');
    
    const sermonsSnapshot = await db.collection('sermons').get();
    console.log(`Found ${sermonsSnapshot.size} sermons in Firestore`);
    
    // Track progress
    let processed = 0;
    let created = 0;
    let updated = 0;
    let errors = 0;
    
    for (const doc of sermonsSnapshot.docs) {
      try {
        const sermon = doc.data();
        
        // Skip if missing critical data
        if (!sermon.title || !sermon.content || !sermon.userId) {
          console.log(`Skipping sermon ${doc.id}: Missing required fields`);
          continue;
        }
        
        // Check if user exists in PostgreSQL
        const userCheck = await pgPool.query(
          'SELECT id FROM users WHERE firebase_id = $1',
          [sermon.userId]
        );
        
        if (userCheck.rows.length === 0) {
          console.log(`Skipping sermon ${doc.id}: User ${sermon.userId} not found in PostgreSQL`);
          continue;
        }
        
        // Check if sermon already exists
        const existingSermon = await pgPool.query(
          'SELECT id FROM sermons WHERE user_id = $1 AND title = $2',
          [sermon.userId, sermon.title]
        );
        
        // Convert Firebase timestamp to JS Date or use current date
        const timestamp = sermon.createdAt ? 
          new Date(sermon.createdAt._seconds * 1000) : 
          new Date();
        
        // Update KPI dates
        const dateStr = getDateString(timestamp);
        const weekStr = getWeekNumber(timestamp);
        
        if (existingSermon.rows.length === 0) {
          // Create new sermon
          const result = await pgPool.query(
            `INSERT INTO sermons 
            (user_id, title, content, bible_reference, analysis, topics, theological_tradition, timestamp) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
            RETURNING id`,
            [
              sermon.userId,
              sermon.title,
              sermon.content,
              sermon.bibleReference || null,
              sermon.analysis ? JSON.stringify(sermon.analysis) : null,
              sermon.analysis?.topics ? JSON.stringify(sermon.analysis.topics) : null,
              sermon.analysis?.theologicalTradition || null,
              timestamp
            ]
          );
          
          const sermonId = result.rows[0].id;
          console.log(`Created sermon: ${sermon.title} (ID: ${sermonId})`);
          
          // Update user's submittedSermons
          await pgPool.query(
            `UPDATE users 
             SET submitted_sermons = submitted_sermons || jsonb_build_object($1::text, true)
             WHERE firebase_id = $2`,
            [sermonId.toString(), sermon.userId]
          );
          
          // Update KPI metrics
          await updateKPI('daily', 'submitted_sermons', 1, dateStr);
          await updateKPI('weekly', 'submitted_sermons', 1, weekStr);
          await updateKPI('totals', 'submitted_sermons', 1, null);
          
          created++;
        } else {
          // Update existing sermon
          const sermonId = existingSermon.rows[0].id;
          
          await pgPool.query(
            `UPDATE sermons SET 
              content = $1, 
              bible_reference = $2, 
              analysis = $3, 
              topics = $4, 
              theological_tradition = $5, 
              timestamp = $6
            WHERE id = $7`,
            [
              sermon.content,
              sermon.bibleReference || null,
              sermon.analysis ? JSON.stringify(sermon.analysis) : null,
              sermon.analysis?.topics ? JSON.stringify(sermon.analysis.topics) : null,
              sermon.analysis?.theologicalTradition || null,
              timestamp,
              sermonId
            ]
          );
          
          console.log(`Updated sermon: ${sermon.title} (ID: ${sermonId})`);
          updated++;
        }
        
        processed++;
      } catch (error) {
        console.error(`Error processing sermon ${doc.id}:`, error);
        errors++;
      }
    }
    
    console.log(`\nSermons migration complete: Processed ${processed}, Created ${created}, Updated ${updated}, Errors ${errors}`);
  } catch (error) {
    console.error('Error migrating sermons:', error);
  }
}

// Migrate newsletter subscriptions
async function migrateNewsletterSubscriptions() {
  try {
    console.log('\n=========== MIGRATING NEWSLETTER SUBSCRIPTIONS ===========');
    
    // Check if the collection exists
    let newsletterSnapshot;
    try {
      newsletterSnapshot = await db.collection('newsletter_subscriptions').get();
      console.log(`Found ${newsletterSnapshot.size} newsletter subscriptions in Firestore`);
    } catch (error) {
      console.log('No newsletter_subscriptions collection found or error accessing it');
      return;
    }
    
    // Track progress
    let processed = 0;
    let created = 0;
    let errors = 0;
    
    for (const doc of newsletterSnapshot.docs) {
      try {
        const subscription = doc.data();
        
        // Skip if missing email
        if (!subscription.email) {
          console.log(`Skipping newsletter subscription ${doc.id}: Missing email`);
          continue;
        }
        
        // Check if subscription already exists
        const existingSubscription = await pgPool.query(
          'SELECT id FROM newsletter_subscriptions WHERE email = $1',
          [subscription.email]
        );
        
        if (existingSubscription.rows.length === 0) {
          // Get user ID if available
          let userId = subscription.userId || null;
          
          // If userId is provided, make sure it exists in users table
          if (userId) {
            const userCheck = await pgPool.query(
              'SELECT id FROM users WHERE firebase_id = $1',
              [userId]
            );
            
            if (userCheck.rows.length === 0) {
              userId = null; // Reset if user not found
            }
          }
          
          // Create new subscription
          await pgPool.query(
            `INSERT INTO newsletter_subscriptions 
            (user_id, email, active, locale, subscribe_date) 
            VALUES ($1, $2, $3, $4, $5)`,
            [
              userId,
              subscription.email,
              subscription.active !== false, // Default to true if not specified
              subscription.locale || 'fr',
              subscription.subscribeDate ? new Date(subscription.subscribeDate._seconds * 1000) : new Date()
            ]
          );
          
          console.log(`Created newsletter subscription for: ${subscription.email}`);
          created++;
        } else {
          console.log(`Newsletter subscription already exists for: ${subscription.email}`);
        }
        
        processed++;
      } catch (error) {
        console.error(`Error processing newsletter subscription ${doc.id}:`, error);
        errors++;
      }
    }
    
    console.log(`\nNewsletter subscriptions migration complete: Processed ${processed}, Created ${created}, Errors ${errors}`);
  } catch (error) {
    console.error('Error migrating newsletter subscriptions:', error);
  }
}

// Migrate contact messages
async function migrateContacts() {
  try {
    console.log('\n=========== MIGRATING CONTACTS ===========');
    
    // Check if the collection exists
    let contactsSnapshot;
    try {
      contactsSnapshot = await db.collection('contacts').get();
      console.log(`Found ${contactsSnapshot.size} contact messages in Firestore`);
    } catch (error) {
      console.log('No contacts collection found or error accessing it');
      return;
    }
    
    // Track progress
    let processed = 0;
    let created = 0;
    let errors = 0;
    
    for (const doc of contactsSnapshot.docs) {
      try {
        const contact = doc.data();
        
        // Skip if missing message
        if (!contact.message || !contact.email) {
          console.log(`Skipping contact ${doc.id}: Missing required fields`);
          continue;
        }
        
        // Check if already exists (by exact match)
        const existingContact = await pgPool.query(
          'SELECT id FROM contacts WHERE email = $1 AND message = $2',
          [contact.email, contact.message]
        );
        
        if (existingContact.rows.length === 0) {
          // Create new contact
          await pgPool.query(
            `INSERT INTO contacts 
            (name, email, message, responded, timestamp) 
            VALUES ($1, $2, $3, $4, $5)`,
            [
              contact.name || null,
              contact.email,
              contact.message,
              contact.responded || false,
              contact.timestamp ? new Date(contact.timestamp._seconds * 1000) : new Date()
            ]
          );
          
          console.log(`Created contact message from: ${contact.email}`);
          created++;
        } else {
          console.log(`Contact message already exists from: ${contact.email}`);
        }
        
        processed++;
      } catch (error) {
        console.error(`Error processing contact ${doc.id}:`, error);
        errors++;
      }
    }
    
    console.log(`\nContacts migration complete: Processed ${processed}, Created ${created}, Errors ${errors}`);
  } catch (error) {
    console.error('Error migrating contacts:', error);
  }
}

// Main migration function
async function migrateFirebaseData() {
  try {
    console.log('========================================');
    console.log('STARTING FIREBASE TO POSTGRESQL MIGRATION');
    console.log('========================================\n');
    
    // 1. Ensure database tables
    await ensureDatabaseTables();
    
    // 2. Migrate users
    await migrateUsers();
    
    // 3. Migrate sermons
    await migrateSermons();
    
    // 4. Migrate newsletter subscriptions
    await migrateNewsletterSubscriptions();
    
    // 5. Migrate contacts
    await migrateContacts();
    
    console.log('\n========================================');
    console.log('MIGRATION COMPLETED SUCCESSFULLY');
    console.log('========================================');
    console.log('PostgreSQL now contains all data from Firebase sources:');
    console.log('- User accounts from Firebase Authentication');
    console.log('- User profiles from Firestore');
    console.log('- Sermons with analysis');
    console.log('- Newsletter subscriptions');
    console.log('- Contact messages');
    console.log('- KPI metrics for tracking');
    
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    await pgPool.end();
    process.exit(0);
  }
}

// Run the migration
migrateFirebaseData().catch(console.error);