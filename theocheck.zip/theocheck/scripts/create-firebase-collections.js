// Script to create collections in Firebase from PostgreSQL data
import 'dotenv/config';
import admin from 'firebase-admin';
import pg from 'pg';
import fs from 'fs';
const { Pool } = pg;

// Initialize PostgreSQL connection
const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });

// Initialize Firebase Admin
try {
  admin.initializeApp({
    credential: admin.credential.cert(JSON.parse(fs.readFileSync('./firebase-credentials.json', 'utf8')))
  });
  console.log('Firebase Admin initialized successfully');
} catch (error) {
  console.error('Error initializing Firebase Admin:', error);
  process.exit(1);
}

const db = admin.firestore();

// Helper function to get week number for KPI tracking
function getWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${weekNo.toString().padStart(2, '0')}`;
}

// Helper function to update KPI metrics
async function updateKPI(type, field, value, date) {
  try {
    // Check if KPI record already exists
    const result = await pgPool.query(
      'SELECT * FROM kpis WHERE type = $1 AND date = $2',
      [type, date || null]
    );

    if (result.rows.length > 0) {
      // Update existing record
      await pgPool.query(
        `UPDATE kpis SET ${field} = ${field} + $1 WHERE type = $2 AND date = $3`,
        [value, type, date || null]
      );
      console.log(`Updated ${type} KPI for ${date || 'totals'}, ${field} += ${value}`);
    } else {
      // Create new record with default values
      const fields = {
        new_users: 0,
        donations: 0,
        donation_amount: 0,
        shares: 0,
        submitted_sermons: 0
      };
      fields[field] = value;

      await pgPool.query(
        `INSERT INTO kpis (type, date, new_users, donations, donation_amount, shares, submitted_sermons) 
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [type, date, fields.new_users, fields.donations, fields.donation_amount, fields.shares, fields.submitted_sermons]
      );
      console.log(`Created new ${type} KPI for ${date || 'totals'}, ${field} = ${value}`);
    }
  } catch (error) {
    console.error(`Error updating KPI (${type}, ${date || 'totals'}, ${field}):`, error);
  }
}

// Function to create users collection in Firebase
async function createUsersCollection() {
  try {
    console.log('\nProcessing users...');
    
    // Get all users from PostgreSQL
    const result = await pgPool.query('SELECT * FROM users');
    console.log(`Found ${result.rows.length} users in PostgreSQL`);
    
    let created = 0;
    let updated = 0;
    let errors = 0;
    
    for (const user of result.rows) {
      try {
        // Check if user already exists in Firebase
        const userRef = db.collection('users').doc(user.firebase_id);
        const userDoc = await userRef.get();
        
        if (!userDoc.exists) {
          // Create new user in Firebase
          await userRef.set({
            email: user.email,
            displayName: user.display_name,
            registrationDate: admin.firestore.Timestamp.fromDate(new Date(user.registration_date)),
            preferences: {
              favoriteTopics: [],
              theologicalTradition: '',
              preferredStyle: '',
              lastViewedSermons: []
            }
          });
          console.log(`Created user ${user.firebase_id} in Firebase`);
          created++;
        } else {
          // Update existing user in Firebase
          await userRef.update({
            email: user.email,
            displayName: user.display_name,
            registrationDate: admin.firestore.Timestamp.fromDate(new Date(user.registration_date))
          });
          console.log(`Updated user ${user.firebase_id} in Firebase`);
          updated++;
        }
      } catch (error) {
        console.error(`Error processing user ${user.id}:`, error);
        errors++;
      }
    }
    
    console.log(`Users processing complete. Created: ${created}, Updated: ${updated}, Errors: ${errors}`);
  } catch (error) {
    console.error('Error creating users collection:', error);
  }
}

// Function to create sermons collection in Firebase
async function createSermonsCollection() {
  try {
    console.log('\nProcessing sermons...');
    
    // Get all sermons from PostgreSQL
    const result = await pgPool.query('SELECT * FROM sermons');
    console.log(`Found ${result.rows.length} sermons in PostgreSQL`);
    
    let created = 0;
    let updated = 0;
    let errors = 0;
    
    for (const sermon of result.rows) {
      try {
        // Generate a unique ID for the sermon in Firebase
        const sermonId = db.collection('sermons').doc().id;
        const sermonRef = db.collection('sermons').doc(sermonId);
        
        // Create sermon in Firebase
        await sermonRef.set({
          userId: sermon.user_id,
          title: sermon.title,
          content: sermon.content,
          bibleReference: sermon.bible_reference,
          analysis: sermon.analysis,
          createdAt: admin.firestore.Timestamp.fromDate(new Date(sermon.timestamp))
        });
        
        console.log(`Created sermon ${sermonId} in Firebase`);
        created++;
        
        // Track in KPI metrics
        const creationDate = new Date(sermon.timestamp);
        const dateStr = creationDate.toISOString().split('T')[0]; // YYYY-MM-DD
        const weekStr = getWeekNumber(creationDate);
        
        await updateKPI('daily', 'submitted_sermons', 1, dateStr);
        await updateKPI('weekly', 'submitted_sermons', 1, weekStr);
        await updateKPI('totals', 'submitted_sermons', 1, null);
      } catch (error) {
        console.error(`Error processing sermon ${sermon.id}:`, error);
        errors++;
      }
    }
    
    console.log(`Sermons processing complete. Created: ${created}, Updated: ${updated}, Errors: ${errors}`);
  } catch (error) {
    console.error('Error creating sermons collection:', error);
  }
}

// Main function to create all collections
async function createFirebaseCollections() {
  try {
    console.log('Starting to create Firebase collections from PostgreSQL data...');
    
    // Create users collection
    await createUsersCollection();
    
    // Create sermons collection
    await createSermonsCollection();
    
    console.log('\nFirebase collections creation completed successfully');
  } catch (error) {
    console.error('Error creating Firebase collections:', error);
  } finally {
    await pgPool.end();
    process.exit(0);
  }
}

// Run the creation process
createFirebaseCollections().catch(console.error);