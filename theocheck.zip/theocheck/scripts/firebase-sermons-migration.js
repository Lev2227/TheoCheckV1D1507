// Script to migrate sermon data from Firebase to PostgreSQL and track sermon submissions for KPI metrics
import 'dotenv/config';
import admin from 'firebase-admin';
import pg from 'pg';
const { Pool } = pg;

// Initialize Firebase Admin
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n')
    })
  });
}

const db = admin.firestore();
const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });

// Helper function to get week number for KPI tracking
function getWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${weekNo.toString().padStart(2, '0')}`;
}

// Helper function to get date string in YYYY-MM-DD format
function getDateString(date) {
  return date.toISOString().split('T')[0];
}

// Helper function to update KPI metrics
async function updateKPI(type, field, value, date) {
  try {
    // Check if KPI record already exists
    const result = await pgPool.query(
      'SELECT * FROM kpis WHERE type = $1 AND date = $2',
      [type, date || null]
    );

    if (result.rows.length > 0) {
      // Update existing record
      await pgPool.query(
        `UPDATE kpis SET ${field} = ${field} + $1 WHERE type = $2 AND date = $3`,
        [value, type, date || null]
      );
      console.log(`Updated ${type} KPI for ${date || 'totals'}, ${field} += ${value}`);
    } else {
      // Create new record with default values
      const fields = {
        new_users: 0,
        donations: 0,
        donation_amount: 0,
        shares: 0,
        submitted_sermons: 0
      };
      fields[field] = value;

      await pgPool.query(
        `INSERT INTO kpis (type, date, new_users, donations, donation_amount, shares, submitted_sermons) 
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [type, date, fields.new_users, fields.donations, fields.donation_amount, fields.shares, fields.submitted_sermons]
      );
      console.log(`Created new ${type} KPI for ${date || 'totals'}, ${field} = ${value}`);
    }
  } catch (error) {
    console.error(`Error updating KPI (${type}, ${date || 'totals'}, ${field}):`, error);
  }
}

// Update user's submittedSermons field
async function updateUserSubmittedSermons(userId, sermonId) {
  try {
    // Verify user exists
    const userResult = await pgPool.query(
      'SELECT * FROM users WHERE firebase_id = $1',
      [userId]
    );
    
    if (userResult.rows.length === 0) {
      console.log(`User ${userId} not found, cannot update submitted sermons`);
      return;
    }
    
    const user = userResult.rows[0];
    
    // Update user's submittedSermons field
    const submittedSermons = user.submitted_sermons || {};
    submittedSermons[sermonId] = true;
    
    await pgPool.query(
      'UPDATE users SET submitted_sermons = $1 WHERE firebase_id = $2',
      [JSON.stringify(submittedSermons), userId]
    );
    
    console.log(`Updated submitted sermons for user ${userId}, added sermon ${sermonId}`);
  } catch (error) {
    console.error(`Error updating user submitted sermons for ${userId}:`, error);
  }
}

// Migrate sermon data from Firebase to PostgreSQL
async function migrateSermonData() {
  try {
    console.log('Starting sermon data migration from Firebase to PostgreSQL...');
    
    // Get all sermons from Firebase
    const sermonsSnapshot = await db.collection('sermons').get();
    console.log(`Found ${sermonsSnapshot.size} sermons in Firebase`);
    
    // Track sermons processed
    let processed = 0;
    let newSermons = 0;
    let errors = 0;
    
    for (const doc of sermonsSnapshot.docs) {
      try {
        const firebaseSermon = doc.data();
        
        // Skip if missing critical data
        if (!firebaseSermon.title || !firebaseSermon.content || !firebaseSermon.userId) {
          console.log(`Skipping sermon ${doc.id}: Missing title, content, or userId`);
          continue;
        }
        
        // Check if sermon already exists in PostgreSQL
        const existingResult = await pgPool.query(
          'SELECT * FROM sermons WHERE title = $1 AND user_id = $2',
          [firebaseSermon.title, firebaseSermon.userId]
        );
        
        if (existingResult.rows.length === 0) {
          // Convert Firebase timestamp to JS Date or use current date
          const timestamp = firebaseSermon.createdAt ? 
            new Date(firebaseSermon.createdAt._seconds * 1000) : 
            new Date();
          
          const dateStr = getDateString(timestamp);
          const weekStr = getWeekNumber(timestamp);
          
          // Insert sermon into PostgreSQL
          const result = await pgPool.query(
            `INSERT INTO sermons 
            (user_id, title, content, bible_reference, analysis, topics, theological_tradition, timestamp) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
            RETURNING id`,
            [
              firebaseSermon.userId,
              firebaseSermon.title,
              firebaseSermon.content,
              firebaseSermon.bibleReference || null,
              firebaseSermon.analysis ? JSON.stringify(firebaseSermon.analysis) : null,
              firebaseSermon.analysis?.topics ? JSON.stringify(firebaseSermon.analysis.topics) : null,
              firebaseSermon.analysis?.theologicalTradition || null,
              timestamp
            ]
          );
          
          const sermonId = result.rows[0].id;
          console.log(`Migrated sermon ${sermonId}: ${firebaseSermon.title}`);
          
          // Update user's submittedSermons
          await updateUserSubmittedSermons(firebaseSermon.userId, sermonId);
          
          // Update KPIs for sermon submissions
          await updateKPI('daily', 'submitted_sermons', 1, dateStr);
          await updateKPI('weekly', 'submitted_sermons', 1, weekStr);
          await updateKPI('totals', 'submitted_sermons', 1, null);
          
          newSermons++;
        } else {
          console.log(`Sermon already exists: ${firebaseSermon.title} by user ${firebaseSermon.userId}`);
        }
        
        processed++;
      } catch (error) {
        console.error(`Error processing sermon ${doc.id}:`, error);
        errors++;
      }
    }
    
    console.log(`Sermon migration complete. Processed: ${processed}, New sermons: ${newSermons}, Errors: ${errors}`);
  } catch (error) {
    console.error('Error migrating sermon data:', error);
  } finally {
    await pgPool.end();
  }
}

// Run the migration
migrateSermonData().catch(console.error);