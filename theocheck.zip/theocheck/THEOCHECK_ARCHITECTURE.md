# TheoCheck - Complete Technical Architecture Guide

## Overview
TheoCheck is a multilingual AI-powered sermon analysis platform that helps pastors and Christian leaders analyze their sermons using advanced AI technology. The platform provides detailed theological analysis, engagement metrics, and professional insights to improve sermon quality and delivery.

## System Architecture

### Frontend (React + TypeScript)
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and building
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Internationalization**: React-i18next (French & English)

### Backend (Node.js + Express)
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with tsx for execution
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time Data**: Firebase Firestore for analytics
- **Authentication**: Firebase Auth with Google Sign-in
- **Payment Processing**: Stripe integration

### External Services
- **OpenAI API**: GPT-4 for sermon analysis
- **Firebase**: Authentication, Firestore for real-time analytics
- **Stripe**: Payment processing for donations
- **PostgreSQL**: Primary database for sermon storage

---

## Data Flow Architecture

```
User Input → React Frontend → Express API → Processing Layer → Storage/External APIs
                    ↓
           Real-time Updates ← Firebase Firestore ← Analytics Tracking
```

---

## API Interactions & Endpoints

### Internal APIs (Express Backend)

#### 1. Authentication APIs
- `POST /api/auth/login` - User login with Firebase token
- `POST /api/auth/register` - User registration
- `GET /api/auth/user` - Get current user profile

#### 2. Sermon Management APIs
- `POST /api/sermons` - Submit sermon for analysis
- `GET /api/sermons/:id` - Retrieve specific sermon
- `GET /api/sermons/user/:userId` - Get user's sermon history
- `PATCH /api/sermons/:id/analysis` - Update sermon analysis

#### 3. Analytics & KPI APIs
- `GET /api/kpi-dashboard` - Retrieve dashboard metrics
- `POST /api/track/event` - Track user events
- `POST /api/track/share` - Track social sharing
- `POST /api/track/donation-success` - Track donation events

#### 4. Payment APIs
- `POST /api/create-payment-intent` - Create Stripe payment intent
- `GET /api/verify-payment/:id` - Verify payment status

### External APIs

#### 1. OpenAI API
- **Purpose**: Sermon analysis using GPT-4
- **Endpoint**: `https://api.openai.com/v1/chat/completions`
- **Request Format**:
```json
{
  "model": "gpt-4",
  "messages": [
    {
      "role": "system",
      "content": "You are a biblical theology expert..."
    },
    {
      "role": "user",
      "content": "Analyze this sermon: [sermon content]"
    }
  ]
}
```
- **Response**: Structured JSON with theological analysis

#### 2. Firebase APIs
- **Authentication**: Google Sign-in, user management
- **Firestore**: Real-time analytics data storage
- **Collections**: `donations`, `sharing_events`, `sermons`, `sermoncount`

#### 3. Stripe API
- **Purpose**: Payment processing for donations
- **Endpoints**: Payment intents, webhook handling
- **Security**: API keys, webhook signatures

---

## Feature Breakdown

### 1. User Authentication
**Components Involved:**
- Frontend: `LoginPage.tsx`, `AuthCheck.tsx`
- Backend: Firebase Admin SDK
- Firebase: Authentication service

**Flow:**
1. User clicks "Sign in with Google"
2. Firebase Auth popup opens
3. User authenticates with Google
4. Firebase returns ID token
5. Frontend stores token and updates user state
6. Protected routes become accessible

### 2. Sermon Analysis (Core Feature)
**Components Involved:**
- Frontend: `SermonForm.tsx`, `SermonAnalysis.tsx`
- Backend: OpenAI integration, Firebase storage
- Database: PostgreSQL for sermon storage

**Detailed Process:**
1. User submits sermon text via form
2. Frontend validates input and sends POST to `/api/sermons`
3. Backend saves sermon to PostgreSQL
4. Backend sends sermon to OpenAI API with specialized prompt
5. OpenAI returns structured analysis
6. Backend processes and stores analysis
7. Analytics tracking fires to Firebase
8. Frontend displays results with visualizations

### 3. Analytics Dashboard
**Components Involved:**
- Frontend: `dashboard.tsx` with Recharts
- Backend: Firebase Firestore queries
- Multiple data sources: donations, shares, analyses

**Data Sources:**
- Firebase `donations` collection
- Firebase `sharing_events` collection
- Firebase `sermoncount` collection
- Real-time aggregation of metrics

### 4. Payment System
**Components Involved:**
- Frontend: `StripePayment.tsx`, `CheckoutForm.tsx`
- Backend: Stripe integration
- Webhook handling for payment confirmation

---

## Analysis Feature - Deep Dive

### Purpose & Insights
The analysis feature provides pastors with:
- **Theological Assessment**: Biblical fidelity, doctrinal accuracy
- **Structural Analysis**: Sermon organization and flow
- **Engagement Metrics**: Audience connection strategies
- **Practical Application**: Real-world relevance
- **Improvement Suggestions**: Specific recommendations

### Data Sources
1. **User Input**: Sermon text (2000+ characters)
2. **AI Processing**: OpenAI GPT-4 analysis
3. **Historical Data**: Previous sermon patterns
4. **Engagement Tracking**: User interaction metrics

### Analysis Process

#### Step 1: Data Collection
```typescript
// Frontend submission
const sermonData = {
  title: string,
  content: string,
  bibleReference?: string,
  userId: string
}
```

#### Step 2: AI Processing
```typescript
// Backend OpenAI prompt
const analysisPrompt = `
Analyze this Christian sermon according to five key criteria:
1. Biblical Fidelity (0-10)
2. Structure & Organization (0-10)
3. Practical Application (0-10)
4. Authenticity & Passion (0-10)
5. Audience Interaction (0-10)

Provide detailed feedback including:
- Strengths and areas for improvement
- Key theological themes
- Audience engagement level
- Practical application suggestions
- Overall score and summary
`;
```

#### Step 3: Data Processing
The AI returns structured JSON:
```typescript
interface SermonAnalysis {
  scores: {
    fideliteBiblique: number;
    structure: number;
    applicationPratique: number;
    authenticite: number;
    interactivite: number;
  };
  overallScore: number;
  strengths: string[];
  improvements: string[];
  summary: string;
  topics: string[];
  theologicalTradition: string;
  keyScriptures: string[];
  applicationPoints: string[];
  emotionalTone: {
    joy: number;
    hope: number;
    conviction: number;
    compassion: number;
    urgency: number;
    reverence: number;
  };
}
```

#### Step 4: Visualization
Results are presented using:
- **Recharts**: Bar charts, pie charts, line graphs
- **Score Cards**: Individual metric displays
- **Text Analysis**: Detailed feedback sections
- **Progress Indicators**: Visual score representations

### Example Analysis Workflow

1. **User Input**: Pastor submits sermon "The Grace of God"
2. **Validation**: Frontend checks minimum length (2000+ chars)
3. **API Request**: POST to `/api/sermons` with sermon data
4. **Database Storage**: Sermon saved to PostgreSQL
5. **AI Analysis**: OpenAI processes with specialized prompt
6. **Response Processing**: Backend structures AI response
7. **Analytics Tracking**: Firebase records analysis event
8. **Results Display**: Frontend shows comprehensive analysis
9. **Historical Storage**: Analysis saved for future reference

### Security & Privacy Measures

#### Data Protection
- **Encryption**: HTTPS for all communications
- **Authentication**: Firebase Auth tokens
- **API Security**: Rate limiting, input validation
- **Database Security**: Parameterized queries, access controls

#### Privacy Measures
- **User Data**: Only authenticated users access their sermons
- **Analytics**: Aggregated data only, no personal content exposed
- **Payment Data**: Stripe handles sensitive payment information
- **Sermon Content**: Encrypted storage, user-specific access

---

## Performance Optimizations

### Frontend Performance
- **Code Splitting**: Lazy loading of components
- **Caching**: TanStack Query for API response caching
- **Bundle Optimization**: Vite's tree-shaking and compression
- **Image Optimization**: SVG icons, optimized assets

### Backend Performance
- **Database Indexing**: Optimized queries on frequently accessed data
- **Connection Pooling**: PostgreSQL connection management
- **Async Processing**: Non-blocking sermon analysis
- **Rate Limiting**: API abuse prevention

### Analysis Feature Performance
- **Streaming**: Real-time updates during analysis
- **Caching**: Analysis results cached for repeat views
- **Batch Processing**: Multiple sermons processed efficiently
- **Error Handling**: Graceful degradation for API failures

---

## Security Implementation

### API Security
- **Authentication**: Firebase JWT tokens
- **Authorization**: Role-based access control
- **Input Validation**: Zod schema validation
- **Rate Limiting**: Prevents API abuse

### Data Security
- **Encryption**: TLS 1.3 for data in transit
- **Database Security**: Parameterized queries prevent SQL injection
- **Secret Management**: Environment variables for sensitive data
- **CORS**: Proper cross-origin resource sharing configuration

### Payment Security
- **Stripe Integration**: PCI DSS compliant payment processing
- **Webhook Verification**: Signed webhook payload validation
- **No Storage**: Credit card data never stored locally

---

## Current Limitations & Improvements

### Current Limitations
1. **Rate Limits**: OpenAI API has usage limits
2. **Processing Time**: Large sermons take 10-30 seconds to analyze
3. **Language Support**: Currently French and English only
4. **Mobile Optimization**: Some charts need mobile improvements

### Suggested Improvements
1. **Background Processing**: Queue system for large analyses
2. **Enhanced Caching**: Redis for improved performance
3. **Multi-language**: Add Spanish, German, Portuguese
4. **Advanced Analytics**: Machine learning for trend analysis
5. **Real-time Collaboration**: Multiple users per sermon
6. **Export Features**: PDF reports, email summaries

---

## Technology Stack Summary

### Frontend
- React 18 + TypeScript
- Vite build tool
- Tailwind CSS + shadcn/ui
- Recharts for data visualization
- TanStack Query for state management
- Wouter for routing
- React-i18next for internationalization

### Backend
- Node.js + Express
- TypeScript execution with tsx
- Drizzle ORM + PostgreSQL
- Firebase Admin SDK
- Stripe Node.js library
- OpenAI API integration

### Infrastructure
- Replit hosting
- PostgreSQL database
- Firebase services
- Stripe payment processing
- OpenAI API services

This architecture provides a robust, scalable platform for AI-powered sermon analysis with comprehensive analytics, secure payment processing, and professional data visualizations.