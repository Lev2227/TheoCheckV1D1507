import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useTranslation } from "react-i18next";
import { trackEvent } from "@/components/analytics/GoogleAnalytics";
import { subscribeToNewsletter, isEmailSubscribed } from "@/lib/newsletter";
import { useAuth } from "@/lib/hooks/useAuth";
import { Loader2 } from "lucide-react";

interface NewsletterPopupProps {
  delay?: number; // Delay before display in ms
  frequency?: number; // Display frequency in days (0 = once)
  forceOpen?: boolean; // Force open (for cases when we want to explicitly display)
  onClose?: () => void;
}

export function NewsletterPopup({ 
  delay = 15000, 
  frequency = 0,
  forceOpen = false, 
  onClose 
}: NewsletterPopupProps) {
  const [isOpen, setIsOpen] = useState(forceOpen);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const isEnglish = i18n.language.startsWith('en');

  // Create schema with localized error message
  const createNewsletterSchema = () => z.object({
    email: z.string().email({ 
      message: isEnglish ? "Please enter a valid email address" : "Veuillez entrer une adresse email valide" 
    }),
  });

  type NewsletterFormData = z.infer<ReturnType<typeof createNewsletterSchema>>;

  useEffect(() => {
    if (forceOpen) {
      setIsOpen(true);
      return;
    }

    // Check when the popup was last seen
    const lastSeen = localStorage.getItem("theocheck_newsletter_last_seen");
    const isSubscribed = localStorage.getItem("theocheck_newsletter_subscribed");
    
    // If user is already subscribed, don't show popup
    if (isSubscribed === "true") return;
    
    // If frequency is set to 0, only show once
    if (frequency === 0 && lastSeen) return;

    // If a frequency is set, check if enough time has passed
    if (lastSeen && frequency > 0) {
      const lastDate = new Date(lastSeen);
      const now = new Date();
      const daysSinceLastSeen = Math.floor((now.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysSinceLastSeen < frequency) return;
    }
    
    // If all conditions are met, show popup after delay
    const timer = setTimeout(() => {
      setIsOpen(true);
      trackEvent('engagement', 'newsletter_popup_shown');
      // Update last seen date
      localStorage.setItem("theocheck_newsletter_last_seen", new Date().toISOString());
    }, delay);
    
    return () => clearTimeout(timer);
  }, [delay, frequency, forceOpen]);

  // If forceOpen changes, update state
  useEffect(() => {
    if (forceOpen) {
      setIsOpen(true);
    }
  }, [forceOpen]);

  const form = useForm<NewsletterFormData>({
    resolver: zodResolver(createNewsletterSchema()),
    defaultValues: {
      email: user?.email || "",
    },
  });

  const handleSubmit = async (data: NewsletterFormData) => {
    setIsLoading(true);
    trackEvent('engagement', 'newsletter_signup_attempt', data.email);
    
    try {
      // First check if email is already subscribed
      const alreadySubscribed = await isEmailSubscribed(data.email);
      
      if (alreadySubscribed) {
        toast({
          title: t("newsletter.alreadySubscribed", "You're already subscribed!", { defaultValue: "Vous êtes déjà abonné !" }),
          description: t("newsletter.alreadySubscribedDesc", "This email is already in our newsletter list.", { defaultValue: "Cet email est déjà dans notre liste de diffusion." }),
        });
        
        // Mark as subscribed in localStorage
        localStorage.setItem("theocheck_newsletter_subscribed", "true");
        
        setIsOpen(false);
        if (onClose) onClose();
        return;
      }
      
      // Subscribe to newsletter
      const success = await subscribeToNewsletter(
        data.email,
        user?.uid,
        i18n.language
      );
      
      if (success) {
        trackEvent('engagement', 'newsletter_signup_success', data.email);
        toast({
          title: t("newsletter.thankYou", "Thank you for subscribing!", { defaultValue: "Merci de vous être inscrit !" }),
          description: t("newsletter.thankYouDesc", "You'll receive our updates and best practices for sermon preparation.", { defaultValue: "Vous recevrez nos mises à jour et meilleures pratiques pour la préparation de sermons." }),
        });
        
        // Mark as subscribed in localStorage
        localStorage.setItem("theocheck_newsletter_subscribed", "true");
        localStorage.setItem("theocheck_newsletter_email", data.email);
      } else {
        trackEvent('engagement', 'newsletter_signup_error', data.email);
        toast({
          title: t("newsletter.failed", "Subscription failed", { defaultValue: "Échec de l'abonnement" }),
          description: t("newsletter.failedDesc", "We couldn't process your subscription. Please try again later.", { defaultValue: "Nous n'avons pas pu traiter votre abonnement. Veuillez réessayer plus tard." }),
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Newsletter subscription error:", error);
      trackEvent('engagement', 'newsletter_signup_error', data.email);
      toast({
        title: t("newsletter.error", "An error occurred", { defaultValue: "Une erreur s'est produite" }),
        description: t("newsletter.errorDesc", "We couldn't process your subscription. Please try again later.", { defaultValue: "Nous n'avons pas pu traiter votre abonnement. Veuillez réessayer plus tard." }),
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setIsOpen(false);
      if (onClose) onClose();
    }
  };

  const handleClose = () => {
    // Mark last seen date
    localStorage.setItem("theocheck_newsletter_last_seen", new Date().toISOString());
    trackEvent('engagement', 'newsletter_popup_dismissed');
    
    setIsOpen(false);
    if (onClose) onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {t("newsletter.title", "Subscribe to our Newsletter", { defaultValue: "Abonnez-vous à notre Newsletter" })}
          </DialogTitle>
          <DialogDescription>
            {t("newsletter.description", "Stay updated with the latest theological insights and sermon tips!", { defaultValue: "Restez informé des dernières analyses théologiques et conseils pour vos sermons !" })}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("newsletter.emailLabel", "Email Address", { defaultValue: "Adresse Email" })}</FormLabel>
                    <FormControl>
                      <Input placeholder={t("newsletter.emailPlaceholder", "you@example.com", { defaultValue: "vous@example.com" })} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex gap-2">
                {isLoading ? (
                  <Button 
                    disabled
                    className="w-full"
                  >
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {t("common.processing", "Processing...", { defaultValue: "Traitement en cours..." })}
                  </Button>
                ) : (
                  <>
                    <Button 
                      type="submit" 
                      className="w-full bg-[#E6F591] text-[#38334D] hover:bg-[#E6F591]/80"
                    >
                      {t("newsletter.subscribe", "Subscribe", { defaultValue: "S'abonner" })}
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={handleClose}
                      className="w-full"
                    >
                      {t("newsletter.notNow", "Not now", { defaultValue: "Plus tard" })}
                    </Button>
                  </>
                )}
              </div>
            </form>
          </Form>
        </div>

        <DialogFooter className="text-xs text-muted-foreground">
          {t("newsletter.privacy", "We respect your privacy and will never share your information.", { defaultValue: "Nous respectons votre vie privée et ne partagerons jamais vos informations." })}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}