import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { Share2, Heart } from "lucide-react";
import { ShareDialog } from "@/components/ui/share-dialog";
import { DonationDialog } from "@/components/ui/donation-dialog";

interface PromotionPopupProps {
  delay?: number; // Délai avant l'affichage en ms
  frequency?: number; // Fréquence d'affichage en jours
}

export function PromotionPopup({ delay = 120000, frequency = 1 }: PromotionPopupProps) {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isDonationOpen, setIsDonationOpen] = useState(false);

  useEffect(() => {
    // Vérifier si le popup a déjà été affiché récemment
    const lastShown = localStorage.getItem("theocheck_promotion_last_shown");
    const currentDate = new Date().getTime();
    
    if (lastShown) {
      const daysSinceLastShown = (currentDate - parseInt(lastShown)) / (1000 * 60 * 60 * 24);
      
      // Ne pas afficher si affiché récemment selon la fréquence
      if (daysSinceLastShown < frequency) {
        return;
      }
    }
    
    // Afficher après le délai spécifié
    const timer = setTimeout(() => {
      setIsOpen(true);
    }, delay);
    
    return () => clearTimeout(timer);
  }, [delay, frequency]);

  const handleClose = () => {
    setIsOpen(false);
    
    // Enregistrer le moment où le popup a été affiché
    localStorage.setItem("theocheck_promotion_last_shown", new Date().getTime().toString());
  };

  const handleShare = () => {
    setIsOpen(false);
    setIsShareOpen(true);
  };

  const handleDonate = () => {
    setIsOpen(false);
    setIsDonationOpen(true);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("promotion.likeOurService")}</DialogTitle>
          </DialogHeader>
          
          <div className="py-6">
            <DialogDescription className="text-base mb-4">
              {t("promotion.helpUsGrow")}
            </DialogDescription>
            
            <div className="flex flex-col space-y-3">
              <Button onClick={handleShare} className="flex items-center gap-2">
                <Share2 className="h-4 w-4" />
                {t("promotion.shareWithFriends", "Partagez theocheck avec des amis")}
              </Button>
              
              <Button onClick={handleDonate} variant="outline" className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-rose-500" />
                {t("promotion.supportUs", "Soutenez TheoCheck")}
              </Button>
            </div>
          </div>
          
          <DialogFooter className="sm:justify-start border-t pt-4">
            <Button variant="ghost" onClick={handleClose}>
              {t("common.maybeNextTime")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <ShareDialog 
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        title={t("share.theocheck.title")}
        description={t("share.theocheck.description")}
        url={window.location.origin}
      />
      
      <DonationDialog
        isOpen={isDonationOpen}
        onClose={() => setIsDonationOpen(false)}
      />
    </>
  );
}
