import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card";
import { Sparkles, MessageSquare, BarChart3, FileText, Share2 } from "lucide-react";

interface FeatureTourProps {
  forceOpen?: boolean;
  onClose?: () => void;
}

export function FeatureTour({ forceOpen = false, onClose }: FeatureTourProps) {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(forceOpen);
  
  useEffect(() => {
    if (forceOpen) {
      setIsOpen(true);
      return;
    }
    
    // Vérifier si l'utilisateur a déjà vu la présentation
    const hasSeenTour = localStorage.getItem("theocheck_feature_tour_seen");
    
    if (!hasSeenTour) {
      // Montrer la présentation après un court délai
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [forceOpen]);
  
  const handleClose = () => {
    // Marquer comme vu
    localStorage.setItem("theocheck_feature_tour_seen", "true");
    setIsOpen(false);
    
    if (onClose) {
      onClose();
    }
  };
  
  const features = [
    {
      id: "analysis",
      title: t("features.analysis.title", "Analyse complète"),
      description: t("features.analysis.description", "Analyse détaillée de la structure et du contenu"),
      icon: <MessageSquare className="h-8 w-8 text-primary" />,
      details: [
        t("features.analysis.details.scripture", "Fidélité biblique et utilisation des écritures"),
        t("features.analysis.details.structure", "Structure et cohérence du message"),
        t("features.analysis.details.application", "Application pratique et pertinence"),
        t("features.analysis.details.delivery", "Style et ton de la prédication")
      ]
    },
    {
      id: "visualize",
      title: t("features.visualization.title", "Visualisation interactive"),
      description: t("features.visualization.description", "Graphiques interactifs pour mieux comprendre vos forces"),
      icon: <BarChart3 className="h-8 w-8 text-primary" />,
      details: [
        t("features.visualization.details.radar", "Graphique radar des compétences"),
        t("features.visualization.details.strengths", "Analyse de vos points forts"),
        t("features.visualization.details.comparison", "Comparaison avec vos précédents sermons"),
        t("features.visualization.details.progress", "Suivi de vos progrès dans le temps")
      ]
    },
    {
      id: "export",
      title: t("features.report.title", "Rapports détaillés"),
      description: t("features.report.description", "Téléchargez un rapport complet pour approfondir"),
      icon: <FileText className="h-8 w-8 text-primary" />,
      details: [
        t("features.report.details.pdf", "Rapport PDF téléchargeable"),
        t("features.report.details.advice", "Conseils personnalisés pour s'améliorer"),
        t("features.report.details.highlights", "Mise en évidence des points clés"),
        t("features.report.details.resources", "Ressources et références recommandées")
      ]
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Sparkles className="h-5 w-5 text-primary" />
            {t("features.welcome", "Bienvenue sur TheoCheck")}
          </DialogTitle>
          <DialogDescription>
            {t("features.subtitle", "Découvrez les fonctionnalités qui vous aideront à améliorer vos sermons")}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <Tabs defaultValue="analysis" className="w-full">
            <TabsList className="grid grid-cols-3">
              {features.map(feature => (
                <TabsTrigger key={feature.id} value={feature.id}>
                  {feature.id === "analysis" ? t("features.analysis.tab", "Analyse") : 
                   feature.id === "visualize" ? t("features.visualization.tab", "Graphiques") :
                   t("features.report.tab", "Rapports")}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {features.map(feature => (
              <TabsContent key={feature.id} value={feature.id} className="mt-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4 mb-4">
                      {feature.icon}
                      <div>
                        <CardTitle>{feature.title}</CardTitle>
                        <CardDescription>{feature.description}</CardDescription>
                      </div>
                    </div>
                    
                    <ul className="space-y-2">
                      {feature.details.map((detail, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-primary">✓</span>
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        <DialogFooter>
          <Button onClick={handleClose}>
            {t("features.getStarted", "Commencer à utiliser TheoCheck")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}