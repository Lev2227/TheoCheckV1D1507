import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { useToast } from "@/hooks/use-toast";
import { Heart, Coffee, Star, Check, ArrowRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

interface DonationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

type DonationTier = {
  id: string;
  title: string;
  amount: number;
  description: string;
  icon: React.ReactNode;
  popular?: boolean;
};

export function DonationDialog({ isOpen, onClose, onSuccess }: DonationDialogProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedAmount, setSelectedAmount] = useState<number>(3);

  const tiers: DonationTier[] = [
    {
      id: "small",
      title: t("donation.tiers.small.title", "Café"),
      amount: 1,
      description: t("donation.tiers.small.description", "Un petit soutien ponctuel"),
      icon: <Coffee className="h-5 w-5" />,
    },
    {
      id: "medium",
      title: t("donation.tiers.medium.title", "Standard"),
      amount: 3,
      description: t("donation.tiers.medium.description", "Soutenez notre développement"),
      icon: <Heart className="h-5 w-5" />,
      popular: true,
    },
    {
      id: "large",
      title: t("donation.tiers.large.title", "Premium"),
      amount: 5,
      description: t("donation.tiers.large.description", "Un soutien généreux"),
      icon: <Star className="h-5 w-5" />,
    },
  ];

  const handleSelectAmount = (amount: number) => {
    setSelectedAmount(amount);
  };

  const handleDonate = () => {
    // Rediriger vers la page de paiement avec le montant sélectionné
    onClose();
    setLocation(`/checkout?amount=${selectedAmount}`);
    
    if (onSuccess) {
      onSuccess();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t("donation.title", "Soutenez TheoCheck")}</DialogTitle>
          <DialogDescription>
            {t("donation.description", "Votre soutien est essentiel pour nous aider à améliorer cet outil.")}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 py-4">
          {tiers.map((tier) => (
            <Card 
              key={tier.id}
              className={cn(
                "cursor-pointer transition-all hover:border-primary",
                selectedAmount === tier.amount ? "border-primary bg-primary/5" : "",
                tier.popular ? "ring-2 ring-primary ring-offset-2" : ""
              )}
              onClick={() => handleSelectAmount(tier.amount)}
            >
              <CardHeader className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {tier.icon}
                    <CardTitle className="text-sm font-medium">{tier.title}</CardTitle>
                  </div>
                  {selectedAmount === tier.amount && (
                    <Check className="h-4 w-4 text-primary" />
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <div className="text-xl font-bold">{tier.amount.toFixed(2)} €</div>
                <CardDescription className="text-xs mt-1">
                  {tier.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Button 
          className="w-full" 
          onClick={handleDonate}
        >
          <Heart className="mr-2 h-5 w-5 text-rose-500" />
          {t("donation.proceedToPayment", "Procéder au paiement")}
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
        
        <DialogFooter className="flex flex-col text-center">
          <p className="text-xs text-muted-foreground">
            {t("donation.paymentSecure", "Paiement sécurisé via Stripe")}
          </p>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
