import React from "react";

interface LogoProps {
  className?: string;
}

export function TheoLogo({ className }: LogoProps) {
  return (
    <img 
      src="/images/theocheck-logo.png" 
      alt="TheoCheck" 
      className={className} 
    />
  );
}