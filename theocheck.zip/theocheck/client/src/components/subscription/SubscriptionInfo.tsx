import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SubscriptionInfo, SubscriptionTier } from "@shared/schema";
import { Crown, CheckCircle, AlertCircle, Clock, Sparkles } from "lucide-react";

interface SubscriptionInfoProps {
  subscription?: SubscriptionInfo;
  onUpgrade: () => void;
}

export function SubscriptionInfoCard({ subscription, onUpgrade }: SubscriptionInfoProps) {
  const { t } = useTranslation();
  
  // If no subscription data exists, default to free tier
  const subscriptionData = subscription || {
    tier: 'free' as SubscriptionTier,
    startDate: new Date().toISOString(),
    features: {
      maxSermons: 5,
      detailedAnalysis: false,
      exportFormats: ['pdf'],
      prioritySupport: false
    },
    autoRenew: false
  };
  
  const getStatusColor = (tier: SubscriptionTier) => {
    switch(tier) {
      case 'premium': return 'text-amber-500';
      case 'enterprise': return 'text-violet-500';
      default: return 'text-emerald-500';
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{t("subscription.title")}</CardTitle>
            <CardDescription>{t("subscription.description")}</CardDescription>
          </div>
          <Badge variant={subscriptionData.tier === 'free' ? 'outline' : 'default'} className="ml-auto">
            <span className="flex items-center gap-1">
              {subscriptionData.tier !== 'free' && (
                <Crown className="h-3.5 w-3.5" />
              )}
              {t(`subscription.tiers.${subscriptionData.tier}`)}
            </span>
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-medium mb-2">{t("subscription.featuresTitle")}</h3>
            <ul className="space-y-3 mt-4">
              <li className="flex items-start gap-3">
                {subscriptionData.features.maxSermons > 10 ? (
                  <Clock className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                ) : (
                  <Clock className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                )}
                <span className="text-sm">
                  {t("subscription.sermonLimit", { count: subscriptionData.features.maxSermons })}
                </span>
              </li>
              
              <li className="flex items-start gap-3">
                {subscriptionData.features.detailedAnalysis ? (
                  <CheckCircle className="h-5 w-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                )}
                <span className="text-sm">
                  {t("subscription.detailedAnalysis")}
                </span>
              </li>
              
              <li className="flex items-start gap-3">
                {subscriptionData.features.prioritySupport ? (
                  <Sparkles className="h-5 w-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                )}
                <span className="text-sm">
                  {t("subscription.prioritySupport")}
                </span>
              </li>
              
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                <span className="text-sm">
                  {t("subscription.exportFormats", { 
                    formats: subscriptionData.features.exportFormats.join(', ').toUpperCase() 
                  })}
                </span>
              </li>
            </ul>
          </div>
          
          {subscriptionData.tier !== 'free' && (
            <div>
              <h3 className="text-sm font-medium mb-2">{t("subscription.status")}</h3>
              <p className="text-sm text-muted-foreground">
                {t("subscription.activeUntil", { 
                  date: new Date(subscriptionData.endDate || "2099-12-31").toLocaleDateString() 
                })}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {subscriptionData.autoRenew 
                  ? t("subscription.autoRenewEnabled")
                  : t("subscription.autoRenewDisabled")
                }
              </p>
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="pt-2">
        {subscriptionData.tier === 'free' ? (
          <Button 
            className="w-full text-base py-6 font-semibold shadow-md hover:shadow-lg transition-all" 
            onClick={onUpgrade}
            size="lg"
          >
            {t("subscription.upgrade")}
          </Button>
        ) : (
          <div className="w-full grid grid-cols-2 gap-2">
            <Button variant="outline">{t("subscription.manage")}</Button>
            <Button variant="default">{t("subscription.viewInvoices")}</Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}