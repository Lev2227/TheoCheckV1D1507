import { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { SubscriptionTier } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { SubscriptionPlans } from "./SubscriptionPlans";
import { apiRequest } from "@/lib/queryClient";
import { Sparkles, CheckCircle } from "lucide-react";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTier: SubscriptionTier;
  onSuccess: () => void;
}

export function UpgradeModal({ isOpen, onClose, currentTier, onSuccess }: UpgradeModalProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSelectPlan = (tier: SubscriptionTier) => {
    setSelectedTier(tier);
  };
  
  const handleUpgrade = async () => {
    if (!selectedTier || selectedTier === currentTier) return;
    
    setIsSubmitting(true);
    try {
      // Simulate API call for now
      // In a real application, this would hit a payment processing endpoint
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // After successful payment/upgrade
      toast({
        title: t("subscription.upgradeSuccess"),
        description: t("subscription.upgradeSuccessDetails"),
      });
      
      onSuccess();
      onClose();
    } catch (error) {
      toast({
        title: t("subscription.upgradeError"),
        description: t("subscription.upgradeErrorDetails"),
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[calc(100vw-32px)] max-w-[1200px] max-h-[calc(100vh-64px)] overflow-y-auto overflow-x-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Sparkles className="h-5 w-5 text-amber-500" />
            {t("subscription.upgradePlan")}
          </DialogTitle>
          <DialogDescription className="mt-2">
            {t("subscription.upgradePlanDescription")}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4 px-2 md:px-4">
          <SubscriptionPlans
            currentTier={currentTier}
            onSelectPlan={handleSelectPlan}
          />
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={onClose}
            disabled={isSubmitting}
          >
            {t("common.cancel")}
          </Button>
          <Button 
            onClick={handleUpgrade}
            disabled={!selectedTier || selectedTier === currentTier || isSubmitting}
            className="gap-2 py-6 px-6 font-semibold shadow-md hover:shadow-lg transition-all"
            size="lg"
          >
            {isSubmitting ? (
              <>
                <span className="animate-spin inline-block h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1" />
                {t("common.processing")}
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4" />
                {t("subscription.proceedToPayment")}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}