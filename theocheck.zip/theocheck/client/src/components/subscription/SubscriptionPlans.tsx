import { useTranslation } from "react-i18next";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, X, CheckCircle, Sparkles, Crown } from "lucide-react";
import { SubscriptionTier } from "@shared/schema";

interface SubscriptionPlanProps {
  currentTier: SubscriptionTier;
  onSelectPlan: (tier: SubscriptionTier) => void;
}

export function SubscriptionPlans({ currentTier, onSelectPlan }: SubscriptionPlanProps) {
  const { t } = useTranslation();
  
  const plans = [
    {
      tier: 'free' as SubscriptionTier,
      price: 0,
      features: [
        { name: t("subscription.features.sermonLimit", { count: 5 }), included: true },
        { name: t("subscription.features.basicAnalysis"), included: true },
        { name: t("subscription.features.pdfExport"), included: true },
        { name: t("subscription.features.detailedAnalysis"), included: false },
        { name: t("subscription.features.prioritySupport"), included: false },
        { name: t("subscription.features.advancedExports"), included: false },
      ]
    },
    {
      tier: 'premium' as SubscriptionTier,
      price: 3,
      features: [
        { name: t("subscription.features.sermonLimit", { count: 50 }), included: true },
        { name: t("subscription.features.basicAnalysis"), included: true },
        { name: t("subscription.features.pdfExport"), included: true },
        { name: t("subscription.features.detailedAnalysis"), included: true },
        { name: t("subscription.features.prioritySupport"), included: false },
        { name: t("subscription.features.advancedExports"), included: true },
      ]
    },
    {
      tier: 'enterprise' as SubscriptionTier,
      price: 5,
      features: [
        { name: t("subscription.features.unlimitedSermons"), included: true },
        { name: t("subscription.features.basicAnalysis"), included: true },
        { name: t("subscription.features.pdfExport"), included: true },
        { name: t("subscription.features.detailedAnalysis"), included: true },
        { name: t("subscription.features.prioritySupport"), included: true },
        { name: t("subscription.features.advancedExports"), included: true },
      ]
    }
  ];
  
  return (
    <div className="flex flex-col md:flex-row md:items-stretch gap-3 md:gap-4 lg:gap-6 w-full">
      {plans.map((plan) => (
        <Card 
          key={plan.tier} 
          className={`relative flex-1 min-w-0
            ${plan.tier === currentTier ? 'border-primary' : plan.tier === 'premium' ? 'border-amber-200 dark:border-amber-800 shadow-lg' : 'border-border'} 
            ${plan.tier === 'premium' ? 'z-10 md:scale-105' : 'z-0'}
          `}
        >
          {plan.tier === currentTier && (
            <div className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/4">
              <span className="bg-primary text-primary-foreground text-xs rounded-full px-2 py-1 font-medium shadow-md">
                {t("subscription.currentPlan")}
              </span>
            </div>
          )}
          
          {plan.tier === 'premium' && plan.tier !== currentTier && (
            <div className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/4">
              <span className="bg-amber-500 text-white text-xs rounded-full px-2 py-1 font-medium shadow-md flex items-center gap-1">
                <Sparkles className="h-3 w-3" />
                {t("subscription.popular")}
              </span>
            </div>
          )}
          
          <CardHeader className={`
            ${plan.tier === 'premium' 
              ? 'bg-gradient-to-br from-amber-50 to-amber-100/50 dark:from-amber-950/30 dark:to-amber-900/10 border-b border-amber-200/50 dark:border-amber-800/30' 
              : plan.tier === 'enterprise'
                ? 'bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-b' 
                : plan.tier !== 'free'
                  ? 'bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-b'
                  : ''} 
            rounded-t-lg pb-3 pt-3 px-4 md:px-6 md:pb-4 md:pt-4
          `}>
            <CardTitle className={`text-center text-xl font-bold ${plan.tier === 'premium' ? 'text-amber-700 dark:text-amber-400' : ''}`}>
              {t(`subscription.tiers.${plan.tier}`)}
            </CardTitle>
            <CardDescription className="text-center text-lg font-medium mt-2">
              {plan.price === 0 
                ? t("subscription.free") 
                : <>
                    {plan.tier === 'premium' && <span className="text-2xl font-bold text-amber-600 dark:text-amber-500">${plan.price.toFixed(2)}</span>}
                    {plan.tier !== 'premium' && <span>${plan.price.toFixed(2)}</span>}
                    <span className="text-sm ml-1">{t("subscription.perMonth")}</span>
                  </>
              }
            </CardDescription>
          </CardHeader>
          
          <CardContent className="text-sm md:text-base px-4 md:px-6 py-3 md:py-4 lg:px-8 md:h-[380px] lg:h-[360px] flex flex-col">
            {plan.tier === 'premium' && (
              <div className="mb-4 pb-3 border-b border-amber-100 dark:border-amber-800/30">
                <p className="text-xs md:text-sm text-amber-700 dark:text-amber-400 italic flex items-center gap-1.5">
                  <Sparkles className="h-3 md:h-3.5 w-3 md:w-3.5" />
                  {t("subscription.premiumRecommendation")}
                </p>
              </div>
            )}
            <ul className="space-y-2 md:space-y-3 mt-2 flex-grow">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-start gap-3">
                  {feature.included ? (
                    <div className={`p-1 rounded-full ${plan.tier === 'premium' ? 'bg-amber-50 dark:bg-amber-950/30' : 'bg-emerald-50 dark:bg-emerald-950/30'}`}>
                      <Check className={`h-4 w-4 flex-shrink-0 ${plan.tier === 'premium' ? 'text-amber-500' : 'text-emerald-500'}`} />
                    </div>
                  ) : (
                    <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-full">
                      <X className="h-4 w-4 text-slate-400 flex-shrink-0" />
                    </div>
                  )}
                  <span className="text-sm lg:text-base">{feature.name}</span>
                </li>
              ))}
            </ul>
          </CardContent>
          
          <CardFooter className="pt-2 px-4 md:px-6 pb-3 md:pb-4">
            <Button 
              className={`w-full font-semibold text-sm md:text-base flex items-center justify-center gap-2 
                ${plan.tier !== 'free' && plan.tier !== currentTier ? 'py-5 shadow-md hover:shadow-lg transition-all' : 'py-4'}
                ${plan.tier === 'premium' && plan.tier !== currentTier ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white border-none' : ''}
              `}
              variant={plan.tier === currentTier 
                ? "outline" 
                : plan.tier === 'free' 
                  ? "secondary" 
                  : plan.tier === 'premium' 
                    ? "default" 
                    : "default"}
              onClick={() => onSelectPlan(plan.tier)}
              disabled={plan.tier === currentTier}
            >
              {plan.tier === currentTier ? (
                <>
                  <CheckCircle className="h-4 w-4" />
                  {t("subscription.currentPlanButton")}
                </>
              ) : plan.tier === 'premium' ? (
                <>
                  <Sparkles className="h-4 w-4" />
                  {t("subscription.selectPlan")}
                </>
              ) : plan.tier === 'enterprise' ? (
                <>
                  <Crown className="h-4 w-4" />
                  {t("subscription.selectPlan")}
                </>
              ) : (
                t("subscription.selectPlan")
              )}
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}