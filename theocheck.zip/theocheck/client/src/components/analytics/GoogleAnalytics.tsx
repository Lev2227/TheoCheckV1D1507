import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';

declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

// Fonction utilitaire pour suivre des événements spécifiques
export const trackEvent = (category: string, action: string, label?: string, value?: number) => {
  if (window.gtag) {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
};

// Fonction utilitaire pour suivre les conversions (par exemple, les abonnements)
export const trackConversion = (action: string, value?: number) => {
  if (window.gtag) {
    window.gtag('event', 'conversion', {
      send_to: 'G-JX930MDL6P/' + action,
      value: value,
    });
  }
};

export function GoogleAnalytics() {
  const [location] = useLocation();
  const [prevLocation, setPrevLocation] = useState('');
  
  useEffect(() => {
    if (location !== prevLocation) {
      setPrevLocation(location);
      
      // Envoyer un événement de changement de page à Google Analytics
      if (window.gtag) {
        window.gtag('config', 'G-JX930MDL6P', {
          page_path: location,
        });
      }
    }
  }, [location, prevLocation]);
  
  return null; // Ce composant ne rend rien dans le DOM
}