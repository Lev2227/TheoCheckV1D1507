import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTranslation } from "react-i18next";
import { ArrowRight } from "lucide-react";

interface CustomAmountFormProps {
  initialAmount: number;
  onConfirm: (amount: number) => void;
  onCancel: () => void;
}

export function CustomAmountForm({ initialAmount, onConfirm, onCancel }: CustomAmountFormProps) {
  const { t } = useTranslation();
  const [amount, setAmount] = useState<string>(initialAmount.toString());
  const [isValid, setIsValid] = useState<boolean>(true);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setAmount(value);
    
    const numValue = parseFloat(value);
    setIsValid(!isNaN(numValue) && numValue > 0);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!isNaN(numAmount) && numAmount > 0) {
      onConfirm(numAmount);
    }
  };

  const predefinedAmounts = [5, 10, 25, 50, 100];

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{t('donation.chooseAmount', 'Choisissez un montant')}</CardTitle>
        <CardDescription>
          {t('donation.custom', 'Personnalisez votre contribution')}
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-5 gap-2 mb-4">
            {predefinedAmounts.map((amt) => (
              <Button 
                key={amt}
                type="button"
                variant="outline"
                onClick={() => setAmount(amt.toString())}
                className={`h-12 font-medium ${amount === amt.toString() ? 'border-primary bg-primary/10' : ''}`}
              >
                {amt} €
              </Button>
            ))}
          </div>
          
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Input
                type="number"
                min="0.50"
                step="0.50"
                value={amount}
                onChange={handleAmountChange}
                className="pr-8 text-lg font-bold h-12"
                placeholder={t('donation.amount', 'Montant')}
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-lg font-bold">€</span>
            </div>
          </div>
          
          {!isValid && (
            <p className="text-sm text-destructive">
              {t('donation.invalidAmount', 'Veuillez entrer un montant valide')}
            </p>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t('common.cancel')}
          </Button>
          <Button 
            type="submit" 
            disabled={!isValid || amount === ''}
          >
            {t('donation.confirm', 'Confirmer')}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}