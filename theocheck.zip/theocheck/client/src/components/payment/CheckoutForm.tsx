import { useState } from 'react';
import { useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";
import { Loader2 } from "lucide-react";

interface CheckoutFormProps {
  amount: number;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export function CheckoutForm({ amount, onSuccess, onCancel }: CheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { t } = useTranslation();
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!stripe || !elements) {
      // Stripe.js n'a pas encore chargé
      return;
    }

    setIsLoading(true);

    try {
      const result = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/payment-success`,
        },
        redirect: 'if_required',
      });

      if (result.error) {
        // Afficher l'erreur à l'utilisateur
        toast({
          title: t("payment.error"),
          description: result.error.message || t("payment.genericError"),
          variant: "destructive",
        });
      } else {
        // Le paiement a été traité avec succès
        toast({
          title: t("payment.success"),
          description: t("payment.successMessage"),
        });
        
        if (onSuccess) {
          onSuccess();
        }
      }
    } catch (error) {
      console.error('Erreur de paiement:', error);
      toast({
        title: t("payment.error"),
        description: t("payment.genericError"),
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    if (onCancel) {
      onCancel();
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{t("payment.title")}</CardTitle>
        <CardDescription>
          {t("payment.securePayment")}
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="rounded-md border p-4 bg-muted/50">
            <div className="text-sm font-medium mb-1">{t("payment.amount")}</div>
            <div className="text-2xl font-bold">{amount.toFixed(2)} €</div>
          </div>
          
          <div className="mt-4">
            <PaymentElement />
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button 
            type="button" 
            variant="outline" 
            onClick={handleCancel}
            disabled={isLoading}
          >
            {t("payment.cancel")}
          </Button>
          <Button 
            type="submit" 
            disabled={!stripe || isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {t("payment.processing")}
              </>
            ) : (
              t("payment.pay")
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}