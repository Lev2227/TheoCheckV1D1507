import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { auth } from "@/lib/firebase";
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  GoogleAuthProvider,
  signInWithPopup
} from "firebase/auth";
import { LoginForm, RegisterForm, loginSchema, registerSchema } from "@/lib/auth";
import { useTranslation } from "react-i18next";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { NewsletterPopup } from "@/components/ui/newsletter-popup";
import { FeatureTour } from "@/components/ui/feature-tour";
import { Separator } from "@/components/ui/separator";
const GoogleLogo = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
  </svg>
);

export function LoginPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showFeatureTour, setShowFeatureTour] = useState(false);
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language.startsWith('en');

  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
      acceptTerms: false,
    },
  });

  const handleLogin = async (data: LoginForm) => {
    setLoading(true);
    try {
      console.log("Tentative de connexion avec:", data.email);
      const userCredential = await signInWithEmailAndPassword(auth, data.email, data.password);
      console.log("Connexion réussie:", userCredential.user.email);
      setLocation("/");
      toast({
        title: t("auth.loginSuccess", "Connexion réussie"),
        description: t("auth.welcomeMessage", "Bienvenue sur TheoCheck"),
      });
    } catch (error: any) {
      console.error("Erreur de connexion:", error);
      let message = t("auth.errors.generic", "Une erreur s'est produite lors de la connexion");
      if (error.code === "auth/user-not-found") {
        message = t("auth.errors.userNotFound", "Aucun compte trouvé avec cet email");
      } else if (error.code === "auth/wrong-password") {
        message = t("auth.errors.wrongPassword", "Mot de passe incorrect");
      } else if (error.code === "auth/invalid-email") {
        message = t("auth.errors.invalidEmail", "Format d'email invalide");
      }
      toast({
        title: t("auth.loginError", "Erreur de connexion"),
        description: message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(auth, provider);
      console.log("Connexion Google réussie:", userCredential.user.email);
      setLocation("/");
      toast({
        title: t("auth.loginSuccess", "Connexion réussie"),
        description: t("auth.welcomeMessage", "Bienvenue sur TheoCheck"),
      });
    } catch (error: any) {
      console.error("Erreur de connexion Google:", error);
      let message = t("auth.errors.generic", "Une erreur s'est produite lors de la connexion");
      if (error.code === "auth/popup-closed-by-user") {
        message = t("auth.errors.popupClosed", "La fenêtre de connexion a été fermée");
      } else if (error.code === "auth/cancelled-popup-request") {
        message = t("auth.errors.popupCancelled", "La demande de connexion a été annulée");
      }
      toast({
        title: t("auth.loginError", "Erreur de connexion"),
        description: message,
        variant: "destructive",
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleRegister = async (data: RegisterForm) => {
    if (data.password !== data.confirmPassword) {
      toast({
        title: t("auth.registerError", "Erreur d'inscription"),
        description: t("auth.errors.passwordMismatch", "Les mots de passe ne correspondent pas"),
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      console.log("Tentative d'inscription avec:", data.email);
      const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
      console.log("Inscription réussie:", userCredential.user.email);
      
      // Marquer que ce compte est nouveau et afficher le tour des fonctionnalités
      localStorage.setItem("theocheck_new_user", "true");
      setShowFeatureTour(true);
      
      toast({
        title: t("auth.registerSuccess", "Inscription réussie"),
        description: t("auth.welcomeMessage", "Bienvenue sur TheoCheck"),
      });
    } catch (error: any) {
      console.error("Erreur d'inscription:", error);
      let message = t("auth.errors.genericRegister", "Une erreur s'est produite lors de l'inscription");
      if (error.code === "auth/email-already-in-use") {
        message = t("auth.errors.emailInUse", "Un compte existe déjà avec cet email");
      } else if (error.code === "auth/invalid-email") {
        message = t("auth.errors.invalidEmail", "Format d'email invalide");
      } else if (error.code === "auth/weak-password") {
        message = t("auth.errors.weakPassword", "Le mot de passe doit contenir au moins 6 caractères");
      }
      toast({
        title: t("auth.registerError", "Erreur d'inscription"),
        description: message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-gray-50 px-4 py-4 sm:py-0">
      <NewsletterPopup delay={10000} frequency={60} />
      <FeatureTour forceOpen={showFeatureTour} onClose={() => {
        setShowFeatureTour(false);
        setLocation("/");
      }} />
      <div className="grid w-full max-w-[1200px] gap-4 sm:gap-6 lg:grid-cols-2">
        <Card className="lg:p-2">
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl font-bold">
              {t("auth.welcome", "Bienvenue sur TheoCheck")}
            </CardTitle>
            <CardDescription>
              {t("auth.startAnalyzing", "Connectez-vous pour commencer à analyser vos sermons")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signin" className="space-y-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin">{t("auth.login", "Se connecter")}</TabsTrigger>
                <TabsTrigger value="signup">{t("auth.register", "S'inscrire")}</TabsTrigger>
              </TabsList>

              <TabsContent value="signin">
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.email", "Email")}</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.password", "Mot de passe")}</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading 
                        ? t("auth.loggingIn", "Connexion...") 
                        : t("auth.login", "Se connecter")}
                    </Button>
                  </form>
                </Form>

                <div className="my-3"></div>

                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full flex items-center justify-center shadow-sm hover:shadow transition-shadow" 
                  onClick={handleGoogleLogin}
                  disabled={googleLoading}
                >
                  {googleLoading ? (
                    <span className="animate-spin inline-block h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2" />
                  ) : (
                    <span className="mr-2 flex items-center justify-center"><GoogleLogo /></span>
                  )}
                  {t("auth.continueWithGoogle", "Continuer avec Google")}
                </Button>
              </TabsContent>

              <TabsContent value="signup">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.email", "Email")}</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.password", "Mot de passe")}</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.confirmPassword", "Confirmer le mot de passe")}</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="acceptTerms"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className="text-sm">
                              {isEnglish 
                                ? "I accept the " 
                                : "J'accepte les "}
                              <Link href="/terms" className="text-primary hover:underline">
                                {isEnglish 
                                  ? "Terms of Use" 
                                  : "Conditions d'Utilisation"}
                              </Link>
                              {isEnglish ? " and " : " et la "}
                              <Link href="/privacy" className="text-primary hover:underline">
                                {isEnglish 
                                  ? "Privacy Policy" 
                                  : "Politique de Confidentialité"}
                              </Link>
                            </FormLabel>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading 
                        ? t("auth.registering", "Inscription...") 
                        : t("auth.register", "S'inscrire")}
                    </Button>
                  </form>
                </Form>

                <div className="my-3"></div>

                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full flex items-center justify-center shadow-sm hover:shadow transition-shadow" 
                  onClick={handleGoogleLogin}
                  disabled={googleLoading}
                >
                  {googleLoading ? (
                    <span className="animate-spin inline-block h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2" />
                  ) : (
                    <span className="mr-2 flex items-center justify-center"><GoogleLogo /></span>
                  )}
                  {t("auth.signupWithGoogle", "S'inscrire avec Google")}
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="hidden lg:block">
          <div className="space-y-4 rounded-lg bg-primary/5 p-8">
            <h2 className="text-xl sm:text-2xl font-bold">{t("auth.analyzeWith", "Analysez vos sermons avec TheoCheck")}</h2>
            <ul className="space-y-2">
              <li className="flex items-center">
                ✓ {t("auth.features.analysis", "Analyse détaillée de la structure et du contenu")}
              </li>
              <li className="flex items-center">
                ✓ {t("auth.features.charts", "Graphiques interactifs pour visualiser les points forts")}
              </li>
              <li className="flex items-center">
                ✓ {t("auth.features.suggestions", "Suggestions personnalisées pour améliorer vos prédications")}
              </li>
              <li className="flex items-center">
                ✓ {t("auth.features.pdf", "Rapports PDF téléchargeables")}
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}