import { type SermonAnalysis } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Share2, Heart, Lightbulb } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useTranslation } from "react-i18next";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { useState, useEffect } from "react";
import { ShareDialog } from "@/components/ui/share-dialog";
import { DonationDialog } from "@/components/ui/donation-dialog";
import { trackEvent } from "@/components/analytics/GoogleAnalytics";

interface SermonAnalysisProps {
  analysis: SermonAnalysis;
  sermonId: number;
  sermonContent?: string;
}

export function SermonAnalysisView({ analysis, sermonId, sermonContent }: SermonAnalysisProps) {
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const [detailedAnalysis, setDetailedAnalysis] = useState<string | null>(null);
  const [isGeneratingDetailedAnalysis, setIsGeneratingDetailedAnalysis] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isDonationOpen, setIsDonationOpen] = useState(false);
  const [showDonationPrompt, setShowDonationPrompt] = useState(false);
  
  // États pour les suggestions personnalisées
  const [customSuggestions, setCustomSuggestions] = useState<string | null>(null);
  const [isLoadingCustomSuggestions, setIsLoadingCustomSuggestions] = useState(false);
  const [showCustomSuggestions, setShowCustomSuggestions] = useState(false);
  
  // Déterminer la langue actuelle
  const currentLanguage = i18n.language || window.localStorage.getItem('i18nextLng') || 'fr';
  const isEnglish = currentLanguage.startsWith('en');
  
  // Détecter le mode sombre
  const [isDarkMode, setIsDarkMode] = useState(
    document.documentElement.classList.contains('dark')
  );
  
  // Observer les changements de mode (clair/sombre)
  useEffect(() => {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === 'class') {
          setIsDarkMode(document.documentElement.classList.contains('dark'));
        }
      });
    });

    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    });

    return () => observer.disconnect();
  }, []);

  // Données pour le graphique radar
  const radarData = [
    {
      subject: isEnglish ? "Biblical Accuracy" : "Fidélité Biblique",
      score: analysis.scores.fideliteBiblique,
    },
    {
      subject: isEnglish ? "Structure" : "Structure",
      score: analysis.scores.structure,
    },
    {
      subject: isEnglish ? "Practical Application" : "Application Pratique",
      score: analysis.scores.applicationPratique,
    },
    {
      subject: isEnglish ? "Authenticity" : "Authenticité",
      score: analysis.scores.authenticite,
    },
    {
      subject: isEnglish ? "Engagement" : "Interactivité",
      score: analysis.scores.interactivite,
    },
  ];

  // Composant Tooltip personnalisé
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border border-border p-2 rounded shadow-lg">
          <p className="text-foreground">{`${payload[0].payload.subject}: ${payload[0].value}/10`}</p>
        </div>
      );
    }
    return null;
  };

  // Gestion du partage
  const handleShare = () => {
    trackEvent('analysis_interaction', 'share_dialog_open', `sermon_${sermonId}`);
    setIsShareOpen(true);
  };

  // Gestionnaire pour le don
  const handleDonate = () => {
    trackEvent('analysis_interaction', 'donation_dialog_open', `sermon_${sermonId}`);
    setIsDonationOpen(true);
  };
  
  // Gestionnaire pour les suggestions personnalisées
  const handleCustomSuggestions = async () => {
    if (customSuggestions) {
      setShowCustomSuggestions(!showCustomSuggestions);
      trackEvent('analysis_interaction', showCustomSuggestions ? 'hide_suggestions' : 'show_suggestions', `sermon_${sermonId}`);
      return;
    }
    
    trackEvent('analysis_interaction', 'request_suggestions', `sermon_${sermonId}`);
    
    setIsLoadingCustomSuggestions(true);
    try {
      console.log("Demande de suggestions personnalisées pour le sermon:", sermonId);
      
      const authCheckResponse = await apiRequest('GET', '/api/user');
      if (!authCheckResponse.ok) {
        throw new Error(isEnglish ? 'Authentication required' : 'Authentification requise');
      }
      
      const response = await apiRequest('POST', `/api/sermons/${sermonId}/get-custom-suggestions`, {
        language: isEnglish ? 'en' : 'fr'
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || (isEnglish ? 'Failed to get personalized suggestions' : 'Échec de l\'obtention des suggestions personnalisées'));
      }
      
      const data = await response.json();
      
      if (!data.customSuggestions) {
        throw new Error(isEnglish ? 'No suggestions received' : 'Aucune suggestion reçue');
      }
      
      setCustomSuggestions(data.customSuggestions);
      setShowCustomSuggestions(true);
      
      toast({
        title: isEnglish ? 'Enhanced suggestions ready!' : 'Suggestions améliorées prêtes !',
        description: isEnglish ? 'Based on our hybrid analysis system.' : 'Basées sur notre système d\'analyse hybride.',
      });
      
      setTimeout(() => {
        document.getElementById('custom-suggestions')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 300);
    } catch (error) {
      console.error("Error generating custom suggestions:", error);
      toast({
        title: isEnglish ? 'Error' : 'Erreur',
        description: error instanceof Error ? error.message : (isEnglish ? 'Failed to generate suggestions' : 'Échec de la génération des suggestions'),
        variant: 'destructive'
      });
    } finally {
      setIsLoadingCustomSuggestions(false);
    }
  };

  const handleDetailedAnalysis = async () => {
    if (!sermonContent) {
      toast({
        title: t("errors.error"),
        description: t("errors.contentRequired"),
        variant: "destructive",
      });
      return;
    }
    
    trackEvent('analysis_interaction', 'request_detailed_analysis', `sermon_${sermonId}`);

    setIsGeneratingDetailedAnalysis(true);
    try {
      const authCheckResponse = await apiRequest('GET', '/api/user');
      if (!authCheckResponse.ok) {
        throw new Error(t("errors.loginRequired"));
      }

      console.log("Demande d'analyse détaillée basée sur l'analyse hybride pour le sermon:", sermonId);
      
      const response = await apiRequest('POST', `/api/sermons/${sermonId}/detailed-analysis`, {
        language: currentLanguage.startsWith('en') ? 'en' : 'fr'
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Échec de la génération de l\'analyse détaillée');
      }
      
      const data = await response.json();
      
      if (!data.detailedAnalysis) {
        throw new Error('Aucune analyse détaillée reçue');
      }
      
      setDetailedAnalysis(data.detailedAnalysis);
      
      trackEvent('analysis_interaction', 'detailed_analysis_completed', `sermon_${sermonId}`, data.detailedAnalysis.length);
      
      toast({
        title: t("analysis.success"),
        description: 'Analyse détaillée générée avec l\'analyse hybride !',
      });
      
      setTimeout(() => {
        document.getElementById('detailed-analysis')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 300);
      
    } catch (error: any) {
      console.error("Error generating detailed analysis:", error);
      toast({
        title: t("errors.error"),
        description: error.message || t("errors.analysisGeneration"),
        variant: "destructive",
      });
    } finally {
      setIsGeneratingDetailedAnalysis(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">{t("analysis.results")}</h2>
        <div className="flex items-center justify-center space-x-2 mb-4">
          <div className="text-4xl font-bold text-primary">{analysis.overallScore}</div>
          <div className="text-lg text-muted-foreground">/10</div>
        </div>
      </div>

      {/* Graphique Radar */}
      <Card className="border-muted-foreground/20">
        <CardHeader>
          <CardTitle>{isEnglish ? "Performance Analysis" : "Analyse de Performance"}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#9FB7B3" strokeOpacity={0.3} />
                <PolarAngleAxis
                  dataKey="subject"
                  tick={{ 
                    fill: isDarkMode ? '#E6F591' : '#2D2A43', 
                    fontSize: 12, 
                    fontWeight: 600
                  }}
                />
                <Radar
                  name="Score"
                  dataKey="score"
                  fill="#E6F591"
                  fillOpacity={0.7}
                  stroke="#E6F591"
                  label={false}
                />
                <Tooltip content={<CustomTooltip />} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Points forts */}
      <Card className="border-muted-foreground/20">
        <CardHeader>
          <CardTitle>{t("analysis.strengths")}</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {analysis.strengths.map((strength, i) => (
              <li key={i} className="flex items-start space-x-2">
                <span className="text-green-500 mt-1">✓</span>
                <span>{strength}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Améliorations suggérées */}
      <Card className="border-muted-foreground/20">
        <CardHeader>
          <CardTitle>{t("analysis.improvements")}</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {analysis.improvements.map((improvement, i) => (
              <li key={i} className="flex items-start space-x-2">
                <span className="text-orange-500 mt-1">→</span>
                <span>{improvement}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card className="border-muted-foreground/20">
        <CardHeader>
          <CardTitle>{t("analysis.summary")}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="leading-relaxed">{analysis.summary}</p>
        </CardContent>
      </Card>

      <Card className="border-muted-foreground/20">
        <CardHeader>
          <CardTitle>{t("analysis.keyPoints", "Points clef de votre message")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {analysis.topics.map((topic, i) => (
              <span 
                key={i} 
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-500/20 text-red-500"
              >
                {topic}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-muted-foreground/20">
        <CardHeader>
          <CardTitle>{t("analysis.keyScriptures")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {analysis.keyScriptures.map((scripture, i) => (
              <div 
                key={i}
                className="text-sm px-3 py-2 bg-primary/15 rounded border border-primary/20 shadow-sm"
              >
                {scripture}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <div className="flex flex-wrap gap-4">
          <Button 
            variant="default" 
            className="gap-2"
            onClick={handleDetailedAnalysis}
            disabled={isGeneratingDetailedAnalysis || !sermonContent}
          >
            {isGeneratingDetailedAnalysis ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {t("analysis.generating")}
              </>
            ) : (
              <>
                <FileText className="h-4 w-4" />
                {t("analysis.detailedAnalysis")}
              </>
            )}
          </Button>
          
          <Button 
            variant={customSuggestions && showCustomSuggestions ? "secondary" : "outline"}
            className="gap-2"
            onClick={handleCustomSuggestions}
            disabled={isLoadingCustomSuggestions}
          >
            {isLoadingCustomSuggestions ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {isEnglish ? "Generating..." : "Génération..."}
              </>
            ) : (
              <>
                <Lightbulb className="h-4 w-4" />
                {isEnglish ? "Smart Suggestions" : "Suggestions Intelligentes"}
              </>
            )}
          </Button>
          
          <Button variant="outline" className="gap-2" onClick={handleShare}>
            <Share2 className="h-4 w-4" />
            {t("analysis.share")}
          </Button>
          
          <Button variant="outline" className="gap-2" onClick={handleDonate}>
            <Heart className="h-4 w-4" />
            {isEnglish ? "Support us" : "Soutenez-nous"}
          </Button>
        </div>
      </div>

      {/* Affichage des suggestions personnalisées améliorées */}
      {customSuggestions && showCustomSuggestions && (
        <div id="custom-suggestions" className="mt-6 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg border border-blue-200 dark:border-blue-800 shadow-lg">
          <h3 className="text-xl font-bold mb-4 flex items-center text-blue-900 dark:text-blue-100">
            <Lightbulb className="mr-2 h-5 w-5" />
            {isEnglish ? "🎯 Hyper-Personalized Suggestions" : "🎯 Suggestions Hyper-Personnalisées"}
          </h3>
          <div className="mb-4 p-3 bg-blue-100 dark:bg-blue-800/30 rounded-md border-l-4 border-blue-500">
            <p className="text-sm text-blue-900 dark:text-blue-100 font-medium">
              {isEnglish 
                ? "✨ These suggestions are based on our advanced hybrid analysis system that examined your sermon with 6 specialized AI agents."
                : "✨ Ces suggestions sont basées sur notre système d'analyse hybride avancé qui a examiné votre sermon avec 6 agents IA spécialisés."}
            </p>
          </div>
          <div 
            className="prose prose-sm dark:prose-invert max-w-none bg-white/90 dark:bg-gray-800/90 p-4 rounded-md border border-blue-200 dark:border-blue-700 shadow-inner"
            dangerouslySetInnerHTML={{
              __html: customSuggestions
            }}
          />
        </div>
      )}

      {/* Affichage de l'analyse détaillée */}
      {detailedAnalysis && (
        <div id="detailed-analysis" className="mt-6">
          <Card className="border-muted-foreground/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                {isEnglish ? "Enhanced Detailed Analysis" : "Analyse Détaillée Améliorée"}
              </CardTitle>
              <CardDescription>
                {isEnglish 
                  ? "Generated using our hybrid analysis system with specialized AI agents"
                  : "Générée avec notre système d'analyse hybride et des agents IA spécialisés"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div 
                className="prose prose-sm dark:prose-invert max-w-none"
                dangerouslySetInnerHTML={{
                  __html: detailedAnalysis
                }}
              />
            </CardContent>
          </Card>
        </div>
      )}

      <ShareDialog 
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        url={`${window.location.origin}/analysis/${sermonId}`}
        title={isEnglish ? "Sermon Analysis Results" : "Résultats d'Analyse de Sermon"}
        description={isEnglish ? "Check out my sermon analysis results" : "Découvrez les résultats d'analyse de mon sermon"}
      />

      <DonationDialog 
        isOpen={isDonationOpen}
        onClose={() => setIsDonationOpen(false)}
      />
    </div>
  );
}