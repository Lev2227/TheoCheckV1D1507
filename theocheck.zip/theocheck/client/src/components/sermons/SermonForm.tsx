import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSermonSchema, type InsertSermon } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Loader2, Users, MessageSquare } from "lucide-react";
import { useTranslation } from "react-i18next";
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trackEvent } from "@/components/analytics/GoogleAnalytics";
import { NewsletterPopup } from "@/components/ui/newsletter-popup";

const MALICIOUS_PATTERNS = [
  "IGNORE ALL PREVIOUS INSTRUCTIONS",
  "IGNORE PREVIOUS INSTRUCTIONS",
  "DISREGARD ALL INSTRUCTIONS",
];

export function SermonForm() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { t } = useTranslation();
  
  // État pour gérer le popup newsletter
  const [showNewsletterPopup, setShowNewsletterPopup] = useState(false);
  
  // États pour les sliders d'audience, de ton et sélection de tradition théologique
  const [targetAudience, setTargetAudience] = useState<number>(3); // Valeur par défaut: médiane
  const [toneFormality, setToneFormality] = useState<number>(3); // Valeur par défaut: médiane
  const [theologicalTradition, setTheologicalTradition] = useState<string>("reformed"); // Valeur par défaut: reformed
  const [selectedTab, setSelectedTab] = useState<string>("sermon");
  
  // Fonction pour gérer le changement d'onglet avec suivi d'événement
  const handleTabChange = (tab: string) => {
    setSelectedTab(tab);
    trackEvent('ui_interaction', 'tab_change', `sermon_form_${tab}`);
  };

  const form = useForm<InsertSermon>({
    resolver: zodResolver(insertSermonSchema),
    defaultValues: {
      title: "",
      content: "",
      bibleReference: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertSermon) => {
      // Check for malicious content before submitting
      const hasMaliciousContent = MALICIOUS_PATTERNS.some(pattern => 
        data.content.toUpperCase().includes(pattern) || 
        data.title.toUpperCase().includes(pattern)
      );

      if (hasMaliciousContent) {
        setLocation("/error");
        throw new Error("Potentially harmful content detected");
      }

      // Ajouter les métadonnées sur l'audience, le ton et la tradition théologique
      const enrichedData = {
        ...data,
        targetAudience,
        toneFormality,
        theologicalTradition
      };

      // Envoyer les données au backend
      const res = await apiRequest("POST", "/api/sermons", enrichedData);
      return res.json();
    },
    onSuccess: async (data) => {
      // Suivi d'événement Google Analytics
      trackEvent(
        'sermon', 
        'analysis_completed', 
        `sermon_${data.id}`, 
        data.content.length
      );

      // Track sermon analysis in Firebase KPI
      try {
        await apiRequest('POST', '/api/track/event', {
          eventType: 'sermon_analysis',
          data: {
            sermonId: data.id,
            contentLength: data.content.length,
            timestamp: new Date()
          }
        });
      } catch (error) {
        console.error('Failed to track sermon analysis:', error);
      }

      toast({
        title: t("sermons.success"),
        description: t("sermons.submissionSuccess"),
      });
      
      // Afficher le popup de newsletter après l'analyse
      setShowNewsletterPopup(true);
      
      form.reset();
      // Redirect to the analysis page
      setLocation(`/analysis/${data.id}`);
    },
    onError: (error: any) => {
      console.error("Sermon submission error:", error);

      // If it's the malicious content error, we've already redirected
      if (error.message === "Potentially harmful content detected") {
        // Suivi d'événement pour contenu malveillant potentiel
        trackEvent('error', 'malicious_content_detected', 'sermon_form');
        return;
      }

      let errorMessage = t("sermons.analysisError");
      let errorType = 'unknown_error';

      if (error.message) {
        if (error.message.includes("429")) {
          errorMessage = t("sermons.serviceUnavailable");
          errorType = 'rate_limit_error';
        } else if (error.message.includes("401")) {
          errorMessage = t("sermons.authError");
          errorType = 'auth_error';
        }
      }
      
      // Suivi d'événement pour les erreurs
      trackEvent('error', errorType, error.message);

      toast({
        title: t("common.error"),
        description: errorMessage,
        variant: "destructive",
      });

      // Redirect to error page for serious errors
      if (error.message.includes("429") || error.message.includes("401")) {
        setLocation("/error");
      }
    },
  });

  return (
    <>
      <NewsletterPopup 
        forceOpen={showNewsletterPopup} 
        onClose={() => setShowNewsletterPopup(false)} 
      />
      <Tabs defaultValue="sermon" onValueChange={handleTabChange} className="w-full">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="sermon" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            {t("sermons.form.sermonContent", "Contenu du sermon")}
          </TabsTrigger>
          <TabsTrigger value="audience" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            {t("sermons.form.targetSettings", "Analysis Preferences", { defaultValue: "Préférences d'analyse" })}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sermon" className="space-y-4">
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => {
                // Suivi d'événement avant de soumettre le formulaire
                trackEvent('sermon', 'submission_attempt', undefined, data.content.length);
                mutation.mutate(data);
              })} className="space-y-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("sermons.form.title")}</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("sermons.form.content")}</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        className="min-h-[300px]" 
                        onFocus={() => trackEvent('form_interaction', 'field_focus', 'sermon_content')}
                        onChange={(e) => {
                          field.onChange(e);
                          // Si la longueur du contenu est un multiple de 500 caractères, on enregistre un événement
                          if (e.target.value.length > 0 && e.target.value.length % 500 === 0) {
                            trackEvent('form_interaction', 'content_progress', `${e.target.value.length}_chars`);
                          }
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="bibleReference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("sermons.form.bibleReference")}</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder={t("sermons.form.bibleReferencePlaceholder")} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="pt-4">
                <Button type="submit" disabled={mutation.isPending} size="lg" className="w-full">
                  {mutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t("sermons.form.analyzing")}
                    </>
                  ) : (
                    t("sermons.form.submit")
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </TabsContent>

        <TabsContent value="audience" className="space-y-6">
          <Card className="border-primary/20 shadow-sm">
            <CardHeader className="bg-primary/5 rounded-t-lg">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                {t("sermons.targetAudience.title", "Analysis Preferences", { defaultValue: "Préférences d'analyse" })}
              </CardTitle>
              <CardDescription>
                {t("sermons.targetAudience.description", "Customize how your sermon will be analyzed", { defaultValue: "Personnalisez la façon dont votre sermon sera analysé" })}
              </CardDescription>
              <div className="mt-2 flex items-center p-3 bg-yellow-100 dark:bg-yellow-900/40 text-yellow-800 dark:text-yellow-200 rounded-md text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 flex-shrink-0">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" x2="12" y1="8" y2="12"/>
                  <line x1="12" x2="12.01" y1="16" y2="16"/>
                </svg>
                {t("sermons.featureInDevelopment", "Our team is currently developing this feature.", { defaultValue: "Notre équipe développe actuellement cette fonctionnalité." })}
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <Label>{t("sermons.targetAudience.label", "Audience Type", { defaultValue: "Type d'audience" })}</Label>
                  <span className="text-sm font-medium">
                    {targetAudience === 1 && t("sermons.targetAudience.committed", "Committed Christians", { defaultValue: "Chrétiens convaincus" })}
                    {targetAudience === 2 && t("sermons.targetAudience.committedPlus", "Engaged Christians", { defaultValue: "Chrétiens engagés" })}
                    {targetAudience === 3 && t("sermons.targetAudience.mixed", "Mixed Audience", { defaultValue: "Public mixte" })}
                    {targetAudience === 4 && t("sermons.targetAudience.seekersPlus", "Open Seekers", { defaultValue: "Chercheurs ouverts" })}
                    {targetAudience === 5 && t("sermons.targetAudience.seekers", "New or Non-believers", { defaultValue: "Nouveaux ou non-croyants" })}
                  </span>
                </div>
                <Slider
                  min={1}
                  max={5}
                  step={1}
                  value={[targetAudience]}
                  onValueChange={(value) => {
                    setTargetAudience(value[0]);
                    trackEvent('form_interaction', 'audience_selected', `audience_level_${value[0]}`);
                  }}
                  className="py-4"
                />
                <div className="flex text-xs text-muted-foreground justify-between">
                  <span>{t("sermons.targetAudience.committed", "Committed Christians", { defaultValue: "Chrétiens convaincus" })}</span>
                  <span>{t("sermons.targetAudience.seekers", "New or Non-believers", { defaultValue: "Nouveaux ou non-croyants" })}</span>
                </div>
              </div>

              <div className="space-y-3 pt-4">
                <div className="flex justify-between">
                  <Label>{t("sermons.tone.label", "Message Tone", { defaultValue: "Ton du message" })}</Label>
                  <span className="text-sm font-medium">
                    {toneFormality === 1 && t("sermons.tone.academic", "Academic", { defaultValue: "Académique" })}
                    {toneFormality === 2 && t("sermons.tone.formal", "Formal", { defaultValue: "Formel" })}
                    {toneFormality === 3 && t("sermons.tone.balanced", "Balanced", { defaultValue: "Équilibré" })}
                    {toneFormality === 4 && t("sermons.tone.conversational", "Conversational", { defaultValue: "Conversationnel" })}
                    {toneFormality === 5 && t("sermons.tone.casual", "Casual", { defaultValue: "Informel" })}
                  </span>
                </div>
                <Slider
                  min={1}
                  max={5}
                  step={1} 
                  value={[toneFormality]}
                  onValueChange={(value) => {
                    setToneFormality(value[0]);
                    trackEvent('form_interaction', 'tone_selected', `tone_level_${value[0]}`);
                  }}
                  className="py-4"
                />
                <div className="flex text-xs text-muted-foreground justify-between">
                  <span>{t("sermons.tone.academic", "Academic", { defaultValue: "Académique" })}</span>
                  <span>{t("sermons.tone.casual", "Casual", { defaultValue: "Informel" })}</span>
                </div>
              </div>
              
              <div className="space-y-3 pt-6 border-t border-border">
                <div className="flex justify-between">
                  <Label>{t("settings.preferences.theologicalTradition", "Theological Tradition", { defaultValue: "Tradition théologique" })}</Label>
                  <Select 
                    value={theologicalTradition} 
                    onValueChange={(value) => {
                      setTheologicalTradition(value);
                      trackEvent('form_interaction', 'tradition_selected', value);
                    }}
                  >
                    <SelectTrigger className="w-[180px] bg-primary/10 border-primary/30">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="reformed">{t("settings.preferences.traditions.reformed", "Reformed", { defaultValue: "Réformée" })}</SelectItem>
                      <SelectItem value="lutheran">{t("settings.preferences.traditions.lutheran", "Lutheran", { defaultValue: "Luthérienne" })}</SelectItem>
                      <SelectItem value="catholic">{t("settings.preferences.traditions.catholic", "Catholic", { defaultValue: "Catholique" })}</SelectItem>
                      <SelectItem value="baptist">{t("settings.preferences.traditions.baptist", "Baptist", { defaultValue: "Baptiste" })}</SelectItem>
                      <SelectItem value="pentecostal">{t("settings.preferences.traditions.pentecostal", "Pentecostal", { defaultValue: "Pentecôtiste" })}</SelectItem>
                      <SelectItem value="orthodox">{t("settings.preferences.traditions.orthodox", "Orthodox", { defaultValue: "Orthodoxe" })}</SelectItem>
                      <SelectItem value="evangelical">{t("settings.preferences.traditions.evangelical", "Evangelical", { defaultValue: "Évangélique" })}</SelectItem>
                      <SelectItem value="charismatic">{t("settings.preferences.traditions.charismatic", "Charismatic", { defaultValue: "Charismatique" })}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-xs text-muted-foreground">
                  {t("sermons.theologicalTradition.help", "This option adapts the analysis according to the theological tradition you follow.", { defaultValue: "Cette option adapte l'analyse selon la tradition théologique que vous suivez." })}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Button 
            onClick={() => handleTabChange("sermon")} 
            className="w-full" 
            size="lg"
          >
            {t("sermons.targetAudience.continue", "Continue to content", { defaultValue: "Continuer vers le contenu" })}
          </Button>
        </TabsContent>
      </Tabs>
    </>
  );
}