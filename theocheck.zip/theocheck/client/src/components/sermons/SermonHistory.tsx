import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import type { Sermon } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useTranslation } from "react-i18next";
import { FileText, Calendar, BookOpen, BarChart2, History, Clock, Search, Download, Eye } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { SermonAnalysis } from "@shared/schema";

export function SermonHistory() {
  const [, setLocation] = useLocation();
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  const { data: sermons, isLoading } = useQuery<Sermon[]>({
    queryKey: ["/api/sermons"],
  });

  // Filtrer les sermons selon la recherche et l'onglet actif
  const filteredSermons = sermons?.filter(sermon => {
    // Filtrer par texte de recherche
    const matchesSearch = 
      searchTerm === "" || 
      sermon.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sermon.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (sermon.bibleReference && sermon.bibleReference.toLowerCase().includes(searchTerm.toLowerCase()));
      
    // Filtrer par onglet actif
    if (activeTab === "all") return matchesSearch;
    if (activeTab === "analyzed") return matchesSearch && sermon.analysis;
    if (activeTab === "pending") return matchesSearch && !sermon.analysis;
    
    return matchesSearch;
  }).sort((a, b) => {
    // Trier par date de création (les plus récents d'abord)
    const dateA = a.createdAt ? new Date(a.createdAt) : new Date(0);
    const dateB = b.createdAt ? new Date(b.createdAt) : new Date(0);
    return dateB.getTime() - dateA.getTime();
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex gap-4 mb-6">
          <Skeleton className="h-10 w-full" />
        </div>
        <div className="flex gap-2 mb-6">
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="border border-primary/10">
            <CardHeader>
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-4 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!sermons?.length) {
    return (
      <Card className="p-6 text-center border border-primary/10">
        <div className="my-8 flex flex-col items-center justify-center">
          <History className="h-16 w-16 text-muted-foreground mb-4" />
          <CardTitle className="text-2xl mb-2">{t("sermons.history.empty.title", "Votre historique est vide")}</CardTitle>
          <CardDescription className="max-w-md mb-6">
            {t("sermons.history.empty.description", "Commencez par soumettre un sermon pour l'analyser et le retrouver dans votre historique.")}
          </CardDescription>
          <Button 
            onClick={() => setLocation("/analyze")}
            className="mt-2"
          >
            {t("sermons.history.empty.cta", "Soumettre un sermon")}
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input 
          className="pl-10 bg-background" 
          placeholder={t("sermons.history.search", "Rechercher dans vos sermons...")}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4 grid w-full grid-cols-3">
          <TabsTrigger value="all" className="flex items-center gap-2">
            <History className="h-4 w-4" />
            {t("sermons.history.filters.all", "Tous")}
            <Badge variant="outline" className="ml-1">
              {sermons.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="analyzed" className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            {t("sermons.history.filters.analyzed", "Analysés")}
            <Badge variant="outline" className="ml-1">
              {sermons.filter(sermon => sermon.analysis).length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="pending" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            {t("sermons.history.filters.pending", "En attente")}
            <Badge variant="outline" className="ml-1">
              {sermons.filter(sermon => !sermon.analysis).length}
            </Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-2">
          {!filteredSermons?.length ? (
            <Card className="p-6 text-center">
              <CardTitle className="text-lg mb-2">{t("sermons.history.noResults", "Aucun résultat")}</CardTitle>
              <CardDescription>
                {t("sermons.history.tryAnotherSearch", "Essayez une autre recherche")}
              </CardDescription>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredSermons.map((sermon) => (
                <Card key={sermon.id} className="overflow-hidden border border-primary/10 hover:border-primary/30 transition-colors">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl group cursor-pointer" onClick={() => setLocation(`/analysis/${sermon.id}`)}>
                          <span className="group-hover:text-primary transition-colors">{sermon.title}</span>
                        </CardTitle>
                        <div className="mt-2 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4 text-secondary" />
                            {sermon.createdAt &&
                              format(new Date(sermon.createdAt), "d MMMM yyyy", {
                                locale: fr,
                              })}
                          </div>
                          {sermon.bibleReference && (
                            <div className="flex items-center gap-1">
                              <BookOpen className="h-4 w-4 text-secondary" />
                              {sermon.bibleReference}
                            </div>
                          )}
                        </div>
                      </div>
                      <Badge 
                        variant={sermon.analysis ? "default" : "secondary"}
                        className={sermon.analysis ? "bg-green-500/20 text-green-700 hover:bg-green-500/30" : ""}
                      >
                        {sermon.analysis ? t("sermons.history.status.analyzed", "Analysé") : t("sermons.history.status.pending", "En attente")}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="prose prose-sm max-w-none text-muted-foreground">
                      <p>{sermon.content.slice(0, 150)}...</p>
                    </div>
                    {sermon.analysis && (
                      <div className="mt-4 flex items-center">
                        <div className="flex-1">
                          <div className="text-sm font-medium mb-1">{t("sermons.history.overallScore", "Note globale")}:</div>
                          <Badge className={`px-3 py-1 bg-primary/80 text-white ${sermon.analysis.overallScore >= 80 ? 'bg-green-600' : sermon.analysis.overallScore >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}>
                            {sermon.analysis.overallScore}/100
                          </Badge>
                        </div>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="bg-muted/5 flex items-center justify-end gap-2 border-t p-3">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setLocation(`/analysis/${sermon.id}`)}
                      className="text-xs"
                    >
                      <Eye className="mr-1 h-3 w-3" />
                      {t("sermons.history.actions.view", "Voir l'analyse")}
                    </Button>
                    {sermon.analysis && (
                      <Button 
                        size="sm"
                        className="text-xs bg-primary hover:bg-primary/90"
                        onClick={() => {
                          // Generate PDF report (to be implemented)
                          console.log("Generating PDF for sermon:", sermon.id);
                        }}
                      >
                        <Download className="mr-1 h-3 w-3" />
                        {t("sermons.history.actions.download", "Télécharger")}
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}