import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/hooks/useAuth";
import { auth } from "@/lib/firebase";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Settings, Languages, Menu, Globe } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";
import { useIsMobile } from "@/hooks/use-mobile";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { TheoLogo } from "@/components/ui/TheoLogo";

export function Navbar() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const isMobile = useIsMobile();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLanguageChange = (value: string) => {
    i18n.changeLanguage(value);
    toast({
      title: t("common.languageChanged"),
      description: t("common.languageChangeEffect"),
    });
  };

  // Paramètre onSelect qui sera utilisé pour fermer le menu mobile après sélection
  const NavLinks = ({ onSelect }: { onSelect?: () => void }) => (
    <>
      <Link href="/analyze" onClick={onSelect}>
        <Button variant="ghost" className="text-sm font-medium hover:bg-primary/10 hover:text-primary">
          {t("common.analyze")}
        </Button>
      </Link>
      <Link href="/criteria" onClick={onSelect}>
        <Button variant="ghost" className="text-sm font-medium hover:bg-primary/10 hover:text-primary">
          {t("common.criteria")}
        </Button>
      </Link>
      <Link href="/about" onClick={onSelect}>
        <Button variant="ghost" className="text-sm font-medium hover:bg-primary/10 hover:text-primary">
          {t("common.about")}
        </Button>
      </Link>
      <Link href="/contact" onClick={onSelect}>
        <Button variant="ghost" className="text-sm font-medium hover:bg-primary/10 hover:text-primary">
          {t("common.contact")}
        </Button>
      </Link>
    </>
  );

  const UserMenu = ({ onSelect }: { onSelect?: () => void }) => (
    <>
      <Link href="/settings" onClick={onSelect}>
        <Button variant="ghost" className="text-sm font-medium hover:bg-primary/10 hover:text-primary">
          <Settings className="h-4 w-4 mr-1" />
          <span className="hidden sm:inline">{t("common.settings")}</span>
        </Button>
      </Link>
      <Button 
        variant="ghost" 
        onClick={() => {
          auth.signOut();
          if (onSelect) onSelect();
        }} 
        className="text-sm font-medium hover:bg-primary/10 hover:text-primary"
      >
        {t("common.logout")}
      </Button>
    </>
  );

  return (
    <nav className="border-b border-primary/10 bg-background shadow-sm fixed top-0 left-0 right-0 z-50 w-full">
      <div className="mx-auto flex h-14 md:h-16 max-w-7xl items-center px-4">
        <Link href="/">
          <span className="flex items-center cursor-pointer">
            <TheoLogo className="h-10 w-auto" />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="ml-2 text-xs md:text-sm bg-[#E6F591] text-[#38334D] dark:bg-[#E6F591] dark:text-[#38334D] px-1.5 py-0.5 rounded-md font-bold cursor-help animate-pulse">
                    BETA
                  </span>
                </TooltipTrigger>
                <TooltipContent className="max-w-[250px] text-sm text-[#38334D] dark:text-[#E6F591] bg-white dark:bg-[#38334D] border border-[#9EB5B3]">
                  {t("common.betaMessage")}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </span>
        </Link>

        {isMobile ? (
          <div className="ml-auto">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[250px]">
                <div className="flex flex-col space-y-4 py-4">
                  <NavLinks onSelect={() => setIsMenuOpen(false)} />
                  {user ? (
                    <div className="flex flex-col space-y-4">
                      <Link href="/settings" onClick={() => setIsMenuOpen(false)}>
                        <Button variant="ghost" className="w-full justify-start">
                          <Settings className="mr-2 h-4 w-4" />
                          {t("common.settings")}
                        </Button>
                      </Link>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start" 
                        onClick={() => {
                          handleLanguageChange(i18n.language === 'fr' ? 'en' : 'fr');
                          setIsMenuOpen(false);
                        }}
                      >
                        <Languages className="mr-2 h-4 w-4" />
                        {i18n.language === 'fr' ? 'English' : 'Français'}
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start" 
                        onClick={() => {
                          auth.signOut();
                          setIsMenuOpen(false);
                        }}
                      >
                        {t("common.logout")}
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start" 
                        onClick={() => {
                          handleLanguageChange(i18n.language === 'fr' ? 'en' : 'fr');
                          setIsMenuOpen(false);
                        }}
                      >
                        <Globe className="mr-2 h-4 w-4" />
                        {i18n.language === 'fr' ? 'English' : 'Français'}
                      </Button>
                      <Link href="/login" onClick={() => setIsMenuOpen(false)}>
                        <Button className="w-full">{t("common.login")}</Button>
                      </Link>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        ) : (
          <div className="ml-auto flex items-center space-x-4">
            <NavLinks />
            
            {/* Selector de langue toujours visible */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="text-sm font-medium hover:bg-primary/10 hover:text-primary">
                  <Globe className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline-block">{i18n.language === 'fr' ? 'FR' : 'EN'}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>{t("common.language")}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleLanguageChange('fr')}>
                  <Badge variant={i18n.language === 'fr' ? "default" : "outline"} className="mr-2">FR</Badge>
                  Français
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleLanguageChange('en')}>
                  <Badge variant={i18n.language === 'en' ? "default" : "outline"} className="mr-2">EN</Badge>
                  English
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {user ? (
              <UserMenu />
            ) : (
              <Link href="/login">
                <Button>{t("common.login")}</Button>
              </Link>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}