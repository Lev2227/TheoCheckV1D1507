import { Link } from "wouter";
import { useTranslation } from "react-i18next";
import { TheoLogo } from "@/components/ui/TheoLogo";

export function Footer() {
  const { t, i18n } = useTranslation();
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-primary/5 py-6 border-t border-border">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0 flex items-center gap-2">
            <TheoLogo className="h-8 w-auto" />
            <div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground flex items-center">
                  &copy; {currentYear}
                </p>
                <p className="text-xs text-secondary/90 italic">"{t("about.tagline")}"</p>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <Link href="/about">
              <span className="text-muted-foreground hover:text-primary hover:bg-primary/10 px-2 py-1 rounded-md transition-colors cursor-pointer">
                {t("common.about")}
              </span>
            </Link>
            <Link href="/contact">
              <span className="text-muted-foreground hover:text-primary hover:bg-primary/10 px-2 py-1 rounded-md transition-colors cursor-pointer">
                {t("common.contact")}
              </span>
            </Link>
            <Link href="/privacy">
              <span className="text-muted-foreground hover:text-primary hover:bg-primary/10 px-2 py-1 rounded-md transition-colors cursor-pointer">
                {t("common.privacy")}
              </span>
            </Link>
            <Link href="/terms">
              <span className="text-muted-foreground hover:text-primary hover:bg-primary/10 px-2 py-1 rounded-md transition-colors cursor-pointer">
                {t("common.terms")}
              </span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}