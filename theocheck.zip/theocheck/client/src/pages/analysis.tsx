import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { type Sermon } from "@shared/schema";
import { SermonAnalysisView } from "@/components/sermons/SermonAnalysis";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useState } from "react";

export default function Analysis() {
  const [location] = useLocation();
  const { t, i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const sermonId = parseInt(location.split("/")[2]); // Get sermon ID from URL

  const { data: sermon, isLoading } = useQuery<Sermon>({
    queryKey: [`/api/sermons/${sermonId}`],
  });

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12">
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-64" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!sermon?.analysis) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12">
        <Card>
          <CardHeader>
            <CardTitle>{t("sermons.form.analyzing")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              {t("sermons.serviceUnavailable")}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:py-12 overflow-x-hidden">
      <h1 className="mb-6 sm:mb-8 text-2xl sm:text-3xl font-bold">{t("analysis.results")}</h1>
      <Card className="mb-6 overflow-hidden">
        <CardHeader>
          <CardTitle>{sermon.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <Collapsible open={isOpen} onOpenChange={setIsOpen}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="text-sm text-muted-foreground flex-1">
                {!isOpen && sermon.content.length > 150 
                  ? <p>{sermon.content.slice(0, 150)}...</p>
                  : null}
              </div>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="w-full sm:w-auto">
                  {isOpen ? (
                    <>
                      <ChevronUp className="h-4 w-4 mr-1" />
                      {i18n.language.startsWith('fr') ? "Réduire" : "Collapse"}
                    </>
                  ) : (
                    <>
                      <ChevronDown className="h-4 w-4 mr-1" />
                      {sermon.content.length > 150 
                        ? (i18n.language.startsWith('fr') ? "Afficher tout" : "Show all") 
                        : (i18n.language.startsWith('fr') ? "Afficher" : "Show")
                      }
                    </>
                  )}
                </Button>
              </CollapsibleTrigger>
            </div>
            <CollapsibleContent>
              <div className="prose prose-sm mt-4 max-w-none text-muted-foreground">
                <p className="whitespace-pre-wrap break-words">{sermon.content}</p>
              </div>
            </CollapsibleContent>
          </Collapsible>
        </CardContent>
      </Card>
      <SermonAnalysisView analysis={sermon.analysis} sermonId={sermon.id} sermonContent={sermon.content} />
    </div>
  );
}