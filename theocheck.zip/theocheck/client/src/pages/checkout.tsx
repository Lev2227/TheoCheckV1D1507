import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { StripePayment } from '@/components/payment/StripePayment';
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useTranslation } from "react-i18next";
import { CustomAmountForm } from '@/components/payment/CustomAmountForm';

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { t } = useTranslation();
  const [amount, setAmount] = useState(9.99); // Montant par défaut
  const [showAmountForm, setShowAmountForm] = useState(false);
  
  // Récupérer le montant à partir de l'URL si disponible
  const queryParams = new URLSearchParams(window.location.search);
  const urlAmount = queryParams.get('amount');
  
  // Mettre à jour le montant si spécifié dans l'URL
  // Traiter le montant URL au chargement initial
  useEffect(() => {
    if (urlAmount) {
      const parsedAmount = parseFloat(urlAmount);
      if (!isNaN(parsedAmount) && parsedAmount > 0) {
        setAmount(parsedAmount);
      }
    }
  }, [urlAmount]);

  const handleSuccess = () => {
    // Redirection vers la page de succès gérée par Stripe via le paramètre return_url
  };

  const handleCancel = () => {
    setLocation('/'); // Retour à la page d'accueil en cas d'annulation
  };
  
  const handleEditAmount = () => {
    setShowAmountForm(true);
  };
  
  const handleAmountConfirm = (newAmount: number) => {
    setAmount(newAmount);
    setShowAmountForm(false);
    
    // Mettre à jour l'URL sans rechargement de page
    const url = new URL(window.location.href);
    url.searchParams.set('amount', newAmount.toString());
    window.history.replaceState({}, '', url);
  };
  
  const handleAmountCancel = () => {
    setShowAmountForm(false);
  };

  return (
    <div className="container max-w-xl mx-auto py-12">
      {showAmountForm ? (
        <CustomAmountForm 
          initialAmount={amount}
          onConfirm={handleAmountConfirm}
          onCancel={handleAmountCancel}
        />
      ) : (
        <>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>{t("payment.checkoutTitle")}</CardTitle>
              <CardDescription>
                {t("payment.checkoutDescription")}
                <div className="mt-4 flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">{t("payment.amount")}</div>
                    <div className="text-xl font-bold">{amount.toFixed(2)} €</div>
                  </div>
                  <button 
                    onClick={handleEditAmount}
                    className="text-sm text-primary underline hover:no-underline"
                  >
                    {t("common.edit", "Modifier")}
                  </button>
                </div>
              </CardDescription>
            </CardHeader>
          </Card>
          
          <StripePayment 
            amount={amount}
            description={t("payment.donationDescription")}
            onSuccess={handleSuccess}
            onCancel={handleCancel}
          />
        </>
      )}
    </div>
  );
}