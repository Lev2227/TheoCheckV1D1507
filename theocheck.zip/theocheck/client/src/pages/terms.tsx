import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function TermsOfUse() {
  const { t } = useTranslation();
  const lastUpdated = "2025-05-07"; // Date mise à jour pour correspondre à la politique de confidentialité
  
  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-theo-dark mb-2">{t("terms.title")}</h1>
        <p className="text-muted-foreground">
          Dernière mise à jour: {lastUpdated}
        </p>
      </div>
      
      <div className="prose prose-lg max-w-none text-muted-foreground mb-8">
        <p>
          Bienvenue sur TheoCheck. Veuillez lire attentivement ces conditions d'utilisation avant d'utiliser 
          notre application d'analyse de sermons. En utilisant TheoCheck, vous acceptez d'être lié par ces conditions.
        </p>
      </div>
      
      <div className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.acceptanceOfTerms.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              En accédant à TheoCheck ou en l'utilisant, vous acceptez d'être lié par ces Conditions d'Utilisation 
              et par toutes les lois et réglementations applicables. Si vous n'acceptez pas ces conditions, vous 
              ne pouvez pas utiliser TheoCheck.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.services.title")}</CardTitle>
            <CardDescription>Fonctionnalités et services proposés par TheoCheck</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              TheoCheck est un service d'analyse de sermons assisté par intelligence artificielle qui offre les 
              fonctionnalités suivantes :
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground ml-4">
              <li>Analyse de sermons basée sur des critères théologiques et homilétiques</li>
              <li>Retours personnalisés et suggestions d'amélioration</li>
              <li>Stockage sécurisé de vos sermons et analyses</li>
              <li>Possibilité d'exporter et de partager vos analyses</li>
              <li>Tableaux de bord et visualisations pour comprendre vos points forts et axes d'amélioration</li>
            </ul>
            <p className="text-muted-foreground mt-4">
              Nous nous réservons le droit de modifier, suspendre ou interrompre tout ou partie de nos services 
              à tout moment, avec ou sans préavis.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.intellectualProperty.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                TheoCheck, y compris son contenu, ses fonctionnalités et sa technologie, est protégé par les lois sur 
                la propriété intellectuelle. Le nom, le logo, les logiciels, les designs, les textes et autres éléments 
                de TheoCheck sont la propriété exclusive de TheoCheck ou de ses concédants de licence.
              </p>
              <p className="text-muted-foreground">
                Vous conservez tous les droits sur les sermons et autres contenus que vous soumettez à TheoCheck pour analyse. 
                En soumettant du contenu, vous nous accordez une licence mondiale, non exclusive, libre de redevances, pour 
                utiliser ce contenu dans le seul but de vous fournir nos services.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.userContent.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                En soumettant du contenu à TheoCheck, vous garantissez que vous avez le droit de le faire et que 
                ce contenu ne viole pas les droits d'autrui. Vous êtes entièrement responsable de l'exactitude, de 
                la légalité et de la conformité du contenu que vous soumettez.
              </p>
              <p className="text-muted-foreground">
                Nous ne revendiquons aucun droit de propriété sur votre contenu, mais nous nous réservons le droit 
                de l'utiliser de manière anonymisée pour améliorer nos services, notamment pour entraîner nos 
                algorithmes d'analyse. Toute utilisation sera conforme à notre politique de confidentialité.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.liability.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                TheoCheck est fourni "tel quel" sans garantie d'aucune sorte. Nous ne garantissons pas l'exactitude, 
                la fiabilité ou l'efficacité des analyses produites par notre service. L'analyse théologique est un 
                domaine complexe et subjectif, et nos évaluations doivent être considérées comme des suggestions et 
                non comme des vérités absolues.
              </p>
              <p className="text-muted-foreground">
                En aucun cas, TheoCheck, ses dirigeants, administrateurs, employés ou agents ne seront responsables 
                de tout dommage direct, indirect, accessoire, spécial ou consécutif découlant de l'utilisation ou de 
                l'impossibilité d'utiliser notre service.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.privacy.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Votre vie privée est importante pour nous. Notre Politique de Confidentialité explique comment nous 
              recueillons, utilisons et protégeons vos informations personnelles. En utilisant TheoCheck, vous 
              consentez également aux pratiques décrites dans notre Politique de Confidentialité.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.changes.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Nous nous réservons le droit de modifier ces conditions à tout moment. Les modifications prendront 
              effet dès leur publication sur notre site. Votre utilisation continue de TheoCheck après la publication 
              des changements constitue votre acceptation de ces changements. Nous vous encourageons à consulter 
              régulièrement ces conditions.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-theo-dark">{t("terms.contact.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Pour toute question concernant ces conditions d'utilisation, veuillez nous contacter via notre 
              formulaire de contact ou à l'adresse terms@theocheck.com.
            </p>
          </CardContent>
        </Card>
        
        <div className="pt-6 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Dernière mise à jour: {lastUpdated}
          </p>
        </div>
      </div>
    </div>
  );
}