import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { MessageSquare, Linkedin, Globe } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function About() {
  const { t } = useTranslation();

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="mb-8 text-3xl font-bold">{t("about.title")}</h1>

      <Card className="mb-8">
        <CardContent className="pt-6 prose prose-gray dark:prose-invert">
          <p>{t("about.mission.description")}</p>
          <p className="text-xl font-semibold">{t("about.solution.title")}</p>
          <p>{t("about.solution.description")}</p>
          <blockquote className="border-l-4 pl-4 italic">
            "{t("about.quote.text")}" {t("about.quote.author")}
          </blockquote>
          <p>{t("about.future.text")}</p>
          <p>{t("about.commitment.text")}</p>
          <p className="text-lg font-semibold">{t("about.tagline")}</p>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardContent className="pt-6 prose prose-gray dark:prose-invert">
          <h2 className="text-xl font-semibold mb-4">{t("about.team.title")}</h2>
          <p>{t("about.team.description")}</p>
          <div className="mt-6 space-y-8">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-semibold">{t("about.team.members.stephane.name")}</h3>
                <a href="https://fr.linkedin.com/in/hamelinsteph" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-[#0077b5] hover:text-[#0077b5]/80 transition-colors">
                  <Linkedin className="h-4 w-4" />
                  <span className="sr-only">LinkedIn</span>
                </a>
                <a href="https://parlecoute.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-purple-900 dark:text-purple-400 hover:opacity-80 transition-opacity">
                  <Globe className="h-4 w-4" />
                  <span className="sr-only">Site web</span>
                </a>
                <Badge variant="outline" className="text-xs bg-primary/10">Fondateur</Badge>
              </div>
              <p>{t("about.team.members.stephane.description")}</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Fondateur de <a href="https://parlecoute.com" target="_blank" rel="noopener noreferrer" className="text-purple-900 dark:text-purple-400 hover:underline font-medium">parlecoute.com</a>, la société mère de TheoCheck.
              </p>
            </div>
            <div>
              <h3 className="font-semibold">{t("about.team.members.lev.name")}</h3>
              <p>{t("about.team.members.lev.description")}</p>
            </div>
            <div>
              <h3 className="font-semibold">{t("about.team.members.ivan.name")}</h3>
              <p>{t("about.team.members.ivan.description")}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* CTA pour analyser un sermon */}
      <Card className="mb-8 bg-primary/5 border border-primary/20">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold mb-2">{t("about.analyze.title", "Essayez TheoCheck dès maintenant")}</h2>
              <p className="text-gray-700 dark:text-gray-300">
                {t("about.analyze.description", "Analysez votre sermon et obtenez des retours instantanés pour améliorer votre prédication.")}
              </p>
            </div>
            <Link href="/analyze">
              <Button size="lg" className="w-full md:w-auto">
                <MessageSquare className="mr-2 h-5 w-5" />
                {t("about.analyze.cta", "Analyser un sermon")}
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Liens et coordonnées */}
      <div className="border-t pt-8 mt-12">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-center sm:text-left">
            <p className="text-sm text-muted-foreground">
              TheoCheck est un produit de <a href="https://parlecoute.com" target="_blank" rel="noopener noreferrer" className="text-purple-900 dark:text-purple-400 hover:underline font-medium">parlecoute.com</a>
            </p>
          </div>
          <div className="flex items-center gap-4">
            <a href="https://fr.linkedin.com/in/hamelinsteph" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-[#0077b5] hover:text-[#0077b5]/80 transition-colors">
              <Linkedin className="h-5 w-5" />
              <span className="text-sm">LinkedIn</span>
            </a>
            <a href="https://parlecoute.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-purple-900 dark:text-purple-400 hover:opacity-80 transition-opacity">
              <Globe className="h-5 w-5" />
              <span className="text-sm">parlecoute.com</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}