import { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

export default function AnalysisCriteria() {
  const { t, i18n } = useTranslation();
  const [activeTab, setActiveTab] = useState<string>("criteria");
  const currentLang = i18n.language.startsWith('en') ? 'en' : 'fr';
  
  // Exemple de données pour le graphique radar
  const sampleChartData = [
    { subject: currentLang === 'fr' ? "Fidélité Biblique" : "Biblical Accuracy", score: 8 },
    { subject: currentLang === 'fr' ? "Structure" : "Logical Flow", score: 7 },
    { subject: currentLang === 'fr' ? "Application" : "Practical Application", score: 9 },
    { subject: currentLang === 'fr' ? "Authenticité" : "Spiritual Impact", score: 6 },
    { subject: currentLang === 'fr' ? "Interactivité" : "Engagement", score: 8 }
  ];

  // Custom tooltip component for the radar chart
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background p-2 rounded-lg border shadow-sm">
          <p className="font-semibold">{payload[0].payload.subject}</p>
          <p className="text-muted-foreground">{currentLang === 'fr' ? 'Score:' : 'Score:'} {payload[0].value}/10</p>
        </div>
      );
    }
    return null;
  };

  // Critères en français
  const frenchCriteria = [
    {
      id: "biblical-fidelity",
      title: "Fidélité Biblique 📖",
      description: "Le sermon est-il en accord avec la Bible ? Les Écritures sont-elles correctement interprétées et appliquées ?",
      aspects: [
        "Exégèse correcte – Le texte biblique est expliqué dans son contexte.",
        "Absence de distorsion théologique – Aucun verset n'est détourné pour appuyer une idée personnelle.",
        "Doctrine solide – Le message est fidèle aux enseignements bibliques fondamentaux.",
        "Utilisation équilibrée de la Bible – Plusieurs passages sont mobilisés pour étayer le message."
      ],
      mistakes: [
        "Citations bibliques sorties de leur contexte.",
        "Développement d'une interprétation erronée ou subjective.",
        "Sermon centré sur l'expérience personnelle plutôt que sur la Parole de Dieu."
      ],
      color: "bg-emerald-100 dark:bg-emerald-950",
      iconColor: "text-emerald-600 dark:text-emerald-400",
      borderColor: "border-emerald-200 dark:border-emerald-800"
    },
    {
      id: "structure",
      title: "Structure 🏗",
      description: "Le sermon est-il logique, fluide et bien organisé ?",
      aspects: [
        "Introduction engageante – Présente clairement le sujet et capte l'attention.",
        "Cohérence du message – Les idées sont logiquement enchaînées.",
        "Transitions fluides – Pas de rupture soudaine ou d'idées dispersées.",
        "Conclusion marquante – Résume les points clés et offre une direction claire."
      ],
      mistakes: [
        "Un désordre dans la présentation des idées.",
        "Des digressions inutiles qui brouillent le message.",
        "Une conclusion faible, sans appel clair à l'action ou à la réflexion."
      ],
      color: "bg-blue-100 dark:bg-blue-950",
      iconColor: "text-blue-600 dark:text-blue-400",
      borderColor: "border-blue-200 dark:border-blue-800"
    },
    {
      id: "application",
      title: "Application 🔥",
      description: "Le sermon aide-t-il les auditeurs à appliquer l'enseignement biblique à leur vie quotidienne ?",
      aspects: [
        "Pertinence – Le message répond aux besoins et défis réels des auditeurs.",
        "Appel à l'action – Encourage une transformation concrète.",
        "Exemples pratiques – Illustre les principes bibliques avec des situations réelles.",
        "Équilibre entre théorie et action – Ne se limite pas à une simple explication, mais incite à changer."
      ],
      mistakes: [
        "Un message trop abstrait ou théorique.",
        "Aucune indication claire sur comment appliquer l'enseignement.",
        "Une approche trop moraliste, focalisée sur l'effort humain au lieu de la grâce divine."
      ],
      color: "bg-orange-100 dark:bg-orange-950",
      iconColor: "text-orange-600 dark:text-orange-400",
      borderColor: "border-orange-200 dark:border-orange-800"
    },
    {
      id: "authenticity",
      title: "Authenticité ❤️",
      description: "Le sermon est-il sincère, inspirant et profondément connecté à la foi ?",
      aspects: [
        "Tonalité sincère – Le message semble authentique et personnel.",
        "Passion et conviction – L'orateur transmet une foi vivante et engagée.",
        "Message christocentrique – Jésus est au centre, et non l'orateur ou des idées philosophiques.",
        "Impact spirituel – Le sermon pousse à la réflexion, à la repentance et à la croissance spirituelle."
      ],
      mistakes: [
        "Un ton froid ou détaché, qui manque de conviction.",
        "Un sermon axé sur l'orateur plutôt que sur Dieu et l'Évangile.",
        "Une approche trop intellectuelle, déconnectée de la vie spirituelle des auditeurs."
      ],
      color: "bg-purple-100 dark:bg-purple-950",
      iconColor: "text-purple-600 dark:text-purple-400",
      borderColor: "border-purple-200 dark:border-purple-800"
    },
    {
      id: "interactivity",
      title: "Interactivité 🎙",
      description: "Le sermon engage-t-il l'auditoire et favorise-t-il une expérience dynamique ?",
      aspects: [
        "Questions ouvertes – L'orateur pose des questions qui stimulent la réflexion.",
        "Utilisation d'anecdotes et d'exemples – Permet de mieux capter l'attention.",
        "Interaction avec l'audience – Adapte le message en fonction des réactions et de l'écoute.",
        "Variété des moyens de communication – Exemples, illustrations, changements de ton…"
      ],
      mistakes: [
        "Un monologue statique, sans interaction.",
        "Trop de concepts abstraits, difficiles à suivre sans illustration.",
        "Un ton monotone ou robotique, qui réduit l'impact du message."
      ],
      color: "bg-pink-100 dark:bg-pink-950",
      iconColor: "text-pink-600 dark:text-pink-400",
      borderColor: "border-pink-200 dark:border-pink-800"
    }
  ];

  // Critères en anglais
  const englishCriteria = [
    {
      id: "biblical-accuracy",
      title: "Biblical Accuracy 📖",
      description: "Does the sermon faithfully align with Scripture? Are biblical texts correctly interpreted and applied?",
      aspects: [
        "Correct exegesis – Does the sermon interpret Scripture accurately in its original context?",
        "No theological distortion – Avoids misquoting or twisting verses to fit personal ideas.",
        "Faithfulness to doctrine – Aligns with sound theological principles rather than personal opinions.",
        "Balanced use of Scripture – Uses multiple references to support points instead of relying on isolated verses."
      ],
      mistakes: [
        "Taking verses out of context to fit a personal narrative.",
        "Over-relying on personal experiences instead of biblical truth.",
        "Misinterpreting the original meaning of Scripture."
      ],
      color: "bg-emerald-100 dark:bg-emerald-950",
      iconColor: "text-emerald-600 dark:text-emerald-400",
      borderColor: "border-emerald-200 dark:border-emerald-800"
    },
    {
      id: "logical-flow",
      title: "Logical Flow & Structure 🧠",
      description: "Is the sermon well-organized, clear, and easy to follow?",
      aspects: [
        "Clear introduction – Engages the audience and introduces the main theme.",
        "Coherent structure – Each section naturally leads to the next without confusion.",
        "Smooth transitions – Logical progression from point to point.",
        "Focused message – Stays on topic without unnecessary digressions or repetition."
      ],
      mistakes: [
        "Jumping between ideas without clear connections.",
        "Long-winded explanations that lose audience engagement.",
        "No clear takeaway or central theme."
      ],
      color: "bg-blue-100 dark:bg-blue-950",
      iconColor: "text-blue-600 dark:text-blue-400",
      borderColor: "border-blue-200 dark:border-blue-800"
    },
    {
      id: "practical-application",
      title: "Practical Application 🔥",
      description: "Does the sermon connect with the audience and offer clear, actionable steps?",
      aspects: [
        "Real-life relevance – Addresses challenges and questions people face today.",
        "Calls to action – Encourages listeners to apply biblical truth in their daily lives.",
        "Concrete examples – Uses real-world scenarios to illustrate spiritual principles.",
        "Balance between theology & application – Doesn't just teach but transforms."
      ],
      mistakes: [
        "The sermon stays theoretical without helping listeners apply the message.",
        "Overuse of complex theology that loses the general audience.",
        "No clear practical takeaway at the end."
      ],
      color: "bg-orange-100 dark:bg-orange-950",
      iconColor: "text-orange-600 dark:text-orange-400",
      borderColor: "border-orange-200 dark:border-orange-800"
    },
    {
      id: "spiritual-impact",
      title: "Spiritual Impact ❤️",
      description: "Does the sermon move the audience toward a deeper faith and conviction?",
      aspects: [
        "Emotional connection – Engages both the heart and the mind.",
        "Inspiration & encouragement – Uplifts, challenges, and strengthens faith.",
        "Christ-centered focus – Keeps Jesus at the core rather than self-help ideas.",
        "Spirit-led conviction – Moves people toward repentance, faith, and action."
      ],
      mistakes: [
        "The sermon is too intellectual and lacks emotional depth.",
        "Focuses more on self-improvement than on God's transformation.",
        "Lacks a clear, compelling message that leaves an impact."
      ],
      color: "bg-purple-100 dark:bg-purple-950",
      iconColor: "text-purple-600 dark:text-purple-400",
      borderColor: "border-purple-200 dark:border-purple-800"
    },
    {
      id: "engagement-delivery",
      title: "Engagement & Delivery 🎙",
      description: "Is the sermon engaging, well-communicated, and adapted to the audience?",
      aspects: [
        "Tone & energy – The sermon is dynamic, not monotonous.",
        "Use of storytelling – Well-placed stories & analogies make it memorable.",
        "Audience awareness – The message fits the context and needs of the listeners.",
        "Balanced length – Not too short (rushed) or too long (loses attention)."
      ],
      mistakes: [
        "A flat, robotic tone that lacks passion.",
        "Too much technical language that alienates listeners.",
        "No eye contact or engagement (if analyzing a video sermon)."
      ],
      color: "bg-pink-100 dark:bg-pink-950",
      iconColor: "text-pink-600 dark:text-pink-400",
      borderColor: "border-pink-200 dark:border-pink-800"
    }
  ];

  // Sélectionner la liste de critères en fonction de la langue actuelle
  const criteria = currentLang === 'fr' ? frenchCriteria : englishCriteria;

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <h1 className="text-4xl font-bold mb-8 text-center">
        {currentLang === 'fr' 
          ? "Les Critères d'Analyse de TheoCheck" 
          : "TheoCheck's Analysis Criteria"}
      </h1>
      
      <Card className="mb-8">
        <CardHeader className="text-center pb-2">
          <CardTitle>
            {currentLang === 'fr' 
              ? "Comment TheoCheck Analyse vos Sermons" 
              : "How TheoCheck Analyzes Your Sermons"}
          </CardTitle>
          <CardDescription>
            {currentLang === 'fr'
              ? "TheoCheck évalue chaque sermon selon cinq critères essentiels, garantissant une évaluation objective et précise."
              : "TheoCheck evaluates sermons based on five core criteria, ensuring a precise, objective, and actionable review."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="criteria" className="w-full" onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="criteria">
                {currentLang === 'fr' ? "Critères Détaillés" : "Detailed Criteria"}
              </TabsTrigger>
              <TabsTrigger value="visualization">
                {currentLang === 'fr' ? "Visualisation" : "Visualization"}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="criteria" className="pt-6">
              <p className="mb-6 text-center text-muted-foreground">
                {currentLang === 'fr'
                  ? "Chaque critère est évalué sur une échelle de 1 à 10, et contribue à l'analyse globale."
                  : "Each criterion is rated on a scale of 1-10 and contributes to the overall analysis."}
              </p>
              
              <div className="space-y-6">
                {criteria.map((criterion) => (
                  <Card key={criterion.id} className={`${criterion.color} ${criterion.borderColor} border-l-4`}>
                    <CardHeader className="pb-2">
                      <CardTitle className={`text-xl ${criterion.iconColor}`}>
                        {criterion.title}
                      </CardTitle>
                      <CardDescription className="text-foreground/90 font-medium">
                        {criterion.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="aspects">
                          <AccordionTrigger className="text-sm font-semibold">
                            {currentLang === 'fr' ? "Aspects évalués" : "Key aspects evaluated"}
                          </AccordionTrigger>
                          <AccordionContent>
                            <ul className="list-none space-y-2 pl-1">
                              {criterion.aspects.map((aspect, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-green-600 mr-2 mt-1">✓</span>
                                  <span>{aspect}</span>
                                </li>
                              ))}
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="mistakes">
                          <AccordionTrigger className="text-sm font-semibold">
                            {currentLang === 'fr' ? "Erreurs pénalisées" : "Common mistakes penalized"}
                          </AccordionTrigger>
                          <AccordionContent>
                            <ul className="list-none space-y-2 pl-1">
                              {criterion.mistakes.map((mistake, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-red-600 mr-2 mt-1">❌</span>
                                  <span>{mistake}</span>
                                </li>
                              ))}
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="visualization" className="pt-6">
              <div className="flex flex-col items-center">
                <h3 className="text-xl font-semibold mb-4">
                  {currentLang === 'fr' ? "Exemple de Graphique Radar" : "Sample Radar Chart"}
                </h3>
                <p className="mb-6 text-center text-muted-foreground max-w-3xl">
                  {currentLang === 'fr'
                    ? "Le graphique radar illustre les scores pour chaque critère, permettant d'identifier rapidement les forces et les axes d'amélioration d'un sermon."
                    : "The radar chart illustrates scores for each criterion, allowing you to quickly identify the strengths and areas for improvement in a sermon."}
                </p>
                
                <div className="w-full h-[400px] max-w-xl mx-auto">
                  <ResponsiveContainer>
                    <RadarChart data={sampleChartData}>
                      <PolarGrid stroke="hsl(var(--muted-foreground))" opacity={0.3} />
                      <PolarAngleAxis
                        dataKey="subject"
                        tick={{ 
                          fill: 'hsl(var(--foreground))', 
                          fontSize: 12,
                        }}
                      />
                      <Radar
                        name="Score"
                        dataKey="score"
                        fill="hsl(var(--primary))"
                        fillOpacity={0.6}
                        stroke="hsl(var(--primary))"
                      />
                      <Tooltip content={<CustomTooltip />} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="mt-8 bg-muted p-4 rounded-lg max-w-xl mx-auto">
                  <h4 className="text-lg font-semibold mb-2">
                    {currentLang === 'fr' ? "Comment interpréter le graphique :" : "How to interpret the chart:"}
                  </h4>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>
                        {currentLang === 'fr'
                          ? "Plus la zone colorée s'étend vers l'extérieur sur un axe, plus le score pour ce critère est élevé."
                          : "The further the colored area extends outward on an axis, the higher the score for that criterion."}
                      </span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>
                        {currentLang === 'fr'
                          ? "Un graphique équilibré indique un sermon bien équilibré. Des pointes indiquent des forces spécifiques."
                          : "A balanced chart indicates a well-rounded sermon. Spikes indicate specific strengths."}
                      </span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>
                        {currentLang === 'fr'
                          ? "Survolez chaque point pour voir le score exact et identifier les axes d'amélioration."
                          : "Hover over each point to see the exact score and identify areas for improvement."}
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <div className="text-center">
        <p className="text-muted-foreground">
          {currentLang === 'fr'
            ? "Ces critères permettent une analyse équilibrée qui respecte à la fois la fidélité biblique et l'efficacité de la communication."
            : "These criteria enable a balanced analysis that respects both biblical fidelity and communication effectiveness."}
        </p>
      </div>
    </div>
  );
}