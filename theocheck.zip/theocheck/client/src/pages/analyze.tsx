import { SermonForm } from "@/components/sermons/SermonForm";
import { AuthCheck } from "@/components/auth/AuthCheck";
import { useTranslation } from "react-i18next";

export default function Analyze() {
  const { t, i18n } = useTranslation();

  return (
    <AuthCheck>
      <div className="mx-auto max-w-3xl px-4 py-6 sm:py-12 overflow-x-hidden">
        <h1 className="mb-4 sm:mb-8 text-2xl sm:text-3xl font-bold">{t("common.analyze")}</h1>
        <SermonForm />
      </div>
    </AuthCheck>
  );
}