import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { loadStripe } from '@stripe/stripe-js';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react";

// Initialise Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export default function PaymentSuccess() {
  const [location, setLocation] = useLocation();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const { t } = useTranslation();

  useEffect(() => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const paymentIntentId = urlParams.get('payment_intent');
    const paymentIntentClientSecret = urlParams.get('payment_intent_client_secret');
    const redirectStatus = urlParams.get('redirect_status');

    const verifyPayment = async () => {
      if (redirectStatus === 'succeeded') {
        setStatus('success');
        setMessage(t("payment.successMessage"));
      } else if (paymentIntentId && paymentIntentClientSecret) {
        try {
          const stripe = await stripePromise;
          if (!stripe) {
            throw new Error('Stripe failed to load');
          }

          const { paymentIntent } = await stripe.retrievePaymentIntent(paymentIntentClientSecret);
          
          if (paymentIntent?.status === 'succeeded') {
            setStatus('success');
            setMessage(t("payment.successMessage"));
            
            // Track successful donation in Firebase
            try {
              await fetch('/api/track/donation-success', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  paymentIntentId: paymentIntent.id,
                  amount: paymentIntent.amount / 100, // Convert from cents
                  userId: 'user_payment_success'
                })
              });
            } catch (error) {
              console.error('Failed to track donation:', error);
            }
          } else {
            setStatus('error');
            setMessage(t("payment.genericError"));
          }
        } catch (error) {
          console.error('Error verifying payment:', error);
          setStatus('error');
          setMessage(t("payment.verificationError"));
        }
      } else {
        setStatus('error');
        setMessage(t("payment.missingParams"));
      }
    };

    verifyPayment();
  }, [t]);

  const goToHomePage = () => {
    setLocation('/');
  };

  const goToAnalyzePage = () => {
    setLocation('/analyze');
  };

  return (
    <div className="container py-12 max-w-xl mx-auto">
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {status === 'loading' && <Loader2 className="h-6 w-6 text-primary animate-spin" />}
            {status === 'success' && <CheckCircle className="h-6 w-6 text-green-500" />}
            {status === 'error' && <AlertCircle className="h-6 w-6 text-destructive" />}
            {status === 'loading' ? t("payment.verifying") : 
             status === 'success' ? t("payment.paymentSuccessTitle") : 
             t("payment.paymentError")}
          </CardTitle>
          <CardDescription>
            {status === 'loading' ? t("payment.verifyingDescription") : null}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            {message}
          </p>
          {status === 'success' && (
            <div className="mt-6 p-4 bg-muted rounded-md">
              <h3 className="font-medium mb-2">{t("payment.whatNext")}</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>{t("payment.benefitAnalysis")}</li>
                <li>{t("payment.benefitExport")}</li>
                <li>{t("payment.benefitSupport")}</li>
              </ul>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex gap-4 justify-end">
          <Button variant="outline" onClick={goToHomePage}>
            {t("common.backToHome")}
          </Button>
          {status === 'success' && (
            <Button onClick={goToAnalyzePage}>
              {t("payment.analyzeSermon")}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}