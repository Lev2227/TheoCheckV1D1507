import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useTranslation } from "react-i18next";
import { Globe } from "lucide-react";

export default function Privacy() {
  const { t } = useTranslation();
  const lastUpdated = "2025-05-07"; // Date de dernière mise à jour
  
  const { i18n } = useTranslation();
  const isEnglish = i18n.language.startsWith('en');

  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-theo-dark mb-2">
          {isEnglish ? "Privacy Policy" : "Politique de Confidentialité"}
        </h1>
        <p className="text-muted-foreground">
          {isEnglish ? "Last updated:" : "Dernière mise à jour:"} {lastUpdated}
        </p>
        <div className="mt-3 flex items-center gap-2 text-sm">
          <p className="text-muted-foreground">
            {isEnglish ? "TheoCheck is a product of" : "TheoCheck est un produit de"}
          </p>
          <a 
            href="https://parlecoute.com" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-flex items-center gap-1 text-purple-900 dark:text-purple-400 hover:underline font-medium"
          >
            <Globe className="h-4 w-4" />
            parlecoute.com
          </a>
        </div>
      </div>

      <div className="prose prose-lg max-w-none text-muted-foreground mb-8">
        <p>
          {isEnglish ? 
            "At TheoCheck, we place great importance on protecting your personal data. This privacy policy describes how we collect, use, and protect your information when you use our sermon analysis service." 
            : 
            "Chez TheoCheck, nous accordons une grande importance à la protection de vos données personnelles. Cette politique de confidentialité décrit comment nous collectons, utilisons et protégeons vos informations lorsque vous utilisez notre service d'analyse de sermons."
          }
        </p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-theo-dark">
            {isEnglish ? "Information Collected" : "Informations collectées"}
          </CardTitle>
          <CardDescription>
            {isEnglish ? "Types of data we collect when you use TheoCheck" : "Les types de données que nous recueillons lors de votre utilisation de TheoCheck"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Account Information" : "Informations de compte"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish 
                ? "When you create an account, we collect your name, email address, and encrypted password. This information is necessary to allow you access to your account and saved analyses."
                : "Lorsque vous créez un compte, nous collectons votre nom, adresse e-mail et mot de passe crypté. Ces informations sont nécessaires pour vous permettre d'accéder à votre compte et à vos analyses sauvegardées."
              }
            </p>
          </div>
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Sermon Content" : "Contenu des sermons"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "The sermons you submit for analysis are stored on our secure servers. This content is used only to provide the analysis service and is never shared with third parties."
                : "Les sermons que vous soumettez pour analyse sont stockés sur nos serveurs sécurisés. Ce contenu est utilisé uniquement pour fournir le service d'analyse et n'est jamais partagé avec des tiers."
              }
            </p>
          </div>
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Usage Data" : "Données d'utilisation"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "We collect information about how you interact with our platform to improve your experience and resolve technical issues."
                : "Nous recueillons des informations sur la façon dont vous interagissez avec notre plateforme afin d'améliorer votre expérience et de résoudre les problèmes techniques."
              }
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-theo-dark">
            {isEnglish ? "Data Usage" : "Utilisation des données"}
          </CardTitle>
          <CardDescription>
            {isEnglish ? "How we use your data to improve your experience" : "Comment nous utilisons vos données pour améliorer votre expérience"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Service Provision" : "Fourniture de services"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish 
                ? "Your data is primarily used to provide, maintain, and improve our sermon analysis service. This includes generating analyses, storing your sermons, and personalizing recommendations."
                : "Vos données sont utilisées principalement pour fournir, maintenir et améliorer notre service d'analyse de sermons. Cela inclut la génération d'analyses, le stockage de vos sermons et la personnalisation des recommandations."
              }
            </p>
          </div>
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Service Improvements" : "Améliorations du service"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "We may use anonymized data to improve our analysis algorithms and the accuracy of our theological evaluations. This data is always devoid of personally identifiable information."
                : "Nous pouvons utiliser des données anonymisées pour améliorer nos algorithmes d'analyse et la précision de nos évaluations théologiques. Ces données sont toujours dépourvues d'informations personnelles identifiables."
              }
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-theo-dark">
            {isEnglish ? "Data Protection" : "Protection des données"}
          </CardTitle>
          <CardDescription>
            {isEnglish ? "Security measures to protect your information" : "Mesures de sécurité pour protéger vos informations"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Data Encryption" : "Chiffrement des données"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "All sensitive data is encrypted in transit and at rest using modern encryption protocols. Your passwords are never stored in plain text."
                : "Toutes les données sensibles sont chiffrées en transit et au repos à l'aide de protocoles de cryptage modernes. Vos mots de passe ne sont jamais stockés en clair."
              }
            </p>
          </div>
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Secure Storage" : "Stockage sécurisé"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "We use leading cloud services with recognized security certifications to store your data. Access to this data is strictly controlled and limited to authorized personnel."
                : "Nous utilisons des services cloud de premier plan avec des certifications de sécurité reconnues pour stocker vos données. L'accès à ces données est strictement contrôlé et limité au personnel autorisé."
              }
            </p>
          </div>
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Authentication" : "Authentification"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "Your account authentication is securely managed through Firebase, a recognized authentication platform that meets the strictest security standards."
                : "L'authentification de votre compte est gérée de manière sécurisée via Firebase, une plateforme d'authentification reconnue qui respecte les normes de sécurité les plus strictes."
              }
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-theo-dark">
            {isEnglish ? "Your Rights" : "Vos droits"}
          </CardTitle>
          <CardDescription>
            {isEnglish ? "Control your personal data" : "Contrôler vos données personnelles"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Access and Correction" : "Accès et correction"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "You have the right to access your personal data and have it corrected if it is inaccurate. You can manage most of this information directly through your user account."
                : "Vous avez le droit d'accéder à vos données personnelles et de les faire corriger si elles sont inexactes. Vous pouvez gérer la plupart de ces informations directement via votre compte utilisateur."
              }
            </p>
          </div>
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Data Deletion" : "Suppression des données"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "You can request the deletion of your account and all associated data at any time through the settings page or by contacting us directly."
                : "Vous pouvez demander la suppression de votre compte et de toutes les données associées à tout moment via la page des paramètres ou en nous contactant directement."
              }
            </p>
          </div>
          <div>
            <h3 className="font-medium mb-2">
              {isEnglish ? "Contact" : "Contact"}
            </h3>
            <p className="text-muted-foreground">
              {isEnglish
                ? "For any questions regarding this privacy policy or to exercise your rights, please contact us via our contact form or at privacy@theocheck.com."
                : "Pour toute question concernant cette politique de confidentialité ou pour exercer vos droits, veuillez nous contacter via notre formulaire de contact ou à l'adresse privacy@theocheck.com."
              }
            </p>
            <p className="text-muted-foreground mt-2">
              {isEnglish
                ? "TheoCheck is a service developed by "
                : "TheoCheck est un service développé par "
              }
              <a href="https://parlecoute.com" target="_blank" rel="noopener noreferrer" className="text-purple-900 dark:text-purple-400 hover:underline">parlecoute.com</a>.
              {isEnglish
                ? " For more information about our other services, feel free to visit our main site."
                : " Pour plus d'informations sur nos autres services, n'hésitez pas à visiter notre site principal."
              }
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
