import { useState, useEffect } from "react";
import { useAuth } from "@/lib/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useTranslation } from "react-i18next";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Moon, Sun, Globe, Mail, Loader2 } from "lucide-react";
import { SubscriptionInfoCard } from "@/components/subscription/SubscriptionInfo";
import { UpgradeModal } from "@/components/subscription/UpgradeModal";
import { SubscriptionTier } from "@shared/schema";
import { Switch } from "@/components/ui/switch";
import { subscribeToNewsletter, isEmailSubscribed, updateUserSubscription } from "@/lib/newsletter";
import { NewsletterPopup } from "@/components/ui/newsletter-popup";

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const [isLoading, setIsLoading] = useState(false);
  const [checkingSubscription, setCheckingSubscription] = useState(false);
  const [newsletterLoading, setNewsletterLoading] = useState(false);
  const [isSubscribedToNewsletter, setIsSubscribedToNewsletter] = useState(
    localStorage.getItem("theocheck_newsletter_subscribed") === "true"
  );
  const [showNewsletterPopup, setShowNewsletterPopup] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [language, setLanguage] = useState<'fr' | 'en'>(
    (localStorage.getItem('i18nextLng') || 'fr').startsWith('en') ? 'en' : 'fr'
  );
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [currentSubscriptionTier, setCurrentSubscriptionTier] = useState<SubscriptionTier>('free');
  
  // Vérifie si l'utilisateur est déjà abonné à la newsletter lors du chargement du composant
  useEffect(() => {
    const checkNewsletterStatus = async () => {
      if (user?.email) {
        setCheckingSubscription(true);
        try {
          const subscribed = await isEmailSubscribed(user.email);
          setIsSubscribedToNewsletter(subscribed);
          // Mise à jour du localStorage pour refléter l'état réel
          localStorage.setItem("theocheck_newsletter_subscribed", subscribed ? "true" : "false");
        } catch (error) {
          console.error("Erreur lors de la vérification du statut newsletter:", error);
        } finally {
          setCheckingSubscription(false);
        }
      }
    };
    
    checkNewsletterStatus();
  }, [user?.email]);

  const handleSaveSettings = async () => {
    setIsLoading(true);
    try {
      // Save settings logic will be implemented here
      toast({
        title: t("settings.success"),
        description: t("settings.successMessage"),
      });
    } catch (error) {
      toast({
        title: t("settings.error"),
        description: t("settings.errorMessage"),
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.classList.toggle('dark');
  };
  
  const changeLanguage = (lang: 'fr' | 'en') => {
    setLanguage(lang);
    i18n.changeLanguage(lang);
    toast({
      title: t("common.languageChanged"),
      description: t("common.languageChangeEffect"),
    });
  };
  
  const handleUpgradeClick = () => {
    setIsUpgradeModalOpen(true);
  };
  
  const handleUpgradeSuccess = () => {
    // Simulate receiving updated subscription information from the server
    setCurrentSubscriptionTier('premium');
    toast({
      title: t("subscription.upgradeSuccess"),
      description: t("subscription.upgradeSuccessDetails"),
    });
  };
  
  // Gestion de l'abonnement à la newsletter
  const toggleNewsletterSubscription = async (checked: boolean) => {
    if (!user?.email) {
      toast({
        title: t("newsletter.error", "Erreur"),
        description: t("newsletter.needLogin", "Vous devez être connecté pour vous abonner à la newsletter"),
        variant: "destructive",
      });
      return;
    }
    
    setNewsletterLoading(true);
    
    try {
      // Si l'utilisateur veut s'abonner mais n'est pas déjà abonné
      if (checked && !isSubscribedToNewsletter) {
        const success = await subscribeToNewsletter(user.email, user.uid, i18n.language);
        
        if (success) {
          setIsSubscribedToNewsletter(true);
          localStorage.setItem("theocheck_newsletter_subscribed", "true");
          localStorage.setItem("theocheck_newsletter_email", user.email);
          
          toast({
            title: t("newsletter.subscribeSuccess", "Abonnement réussi"),
            description: t("newsletter.subscribeMessage", "Vous êtes maintenant abonné à notre newsletter"),
          });
        } else {
          toast({
            title: t("newsletter.error", "Erreur"),
            description: t("newsletter.subscribeError", "Une erreur s'est produite lors de l'abonnement"),
            variant: "destructive",
          });
        }
      } 
      // Si l'utilisateur veut se désabonner
      else if (!checked && isSubscribedToNewsletter) {
        const success = await updateUserSubscription(user.uid, false, user.email);
        
        if (success) {
          setIsSubscribedToNewsletter(false);
          localStorage.setItem("theocheck_newsletter_subscribed", "false");
          
          toast({
            title: t("newsletter.unsubscribeSuccess", "Désabonnement réussi"),
            description: t("newsletter.unsubscribeMessage", "Vous êtes maintenant désabonné de notre newsletter"),
          });
        } else {
          toast({
            title: t("newsletter.error", "Erreur"),
            description: t("newsletter.unsubscribeError", "Une erreur s'est produite lors du désabonnement"),
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      console.error("Erreur newsletter:", error);
      toast({
        title: t("newsletter.error", "Erreur"),
        description: t("newsletter.genericError", "Une erreur s'est produite"),
        variant: "destructive",
      });
    } finally {
      setNewsletterLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="mb-8 text-3xl font-bold">{t("settings.title")}</h1>

      <div className="space-y-6">
        {/* Commenté pour cacher le système de subscription pour l'instant */}
        {/* <SubscriptionInfoCard 
          subscription={undefined}
          onUpgrade={handleUpgradeClick}
        /> */}

        {/* Section de préférences d'analyse supprimée comme demandé */}

        <Card className="border-secondary/20 shadow-sm">
          <CardHeader className="bg-secondary/10 rounded-t-lg">
            <CardTitle className="text-foreground flex items-center">
              <Globe className="h-5 w-5 mr-2 text-secondary" />
              {t("common.language", "Langue")}
            </CardTitle>
            <CardDescription>
              {t("settings.language.description", "Choisissez votre langue préférée")}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>{t("settings.language.preference", "Langue de l'interface")}</Label>
              <div className="flex space-x-2">
                <Button
                  variant={language === 'fr' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => changeLanguage('fr')}
                  className="w-20"
                >
                  Français
                </Button>
                <Button
                  variant={language === 'en' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => changeLanguage('en')}
                  className="w-20"
                >
                  English
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 shadow-sm">
          <CardHeader className="bg-primary/10 rounded-t-lg">
            <CardTitle className="text-foreground flex items-center">
              <Sun className="h-5 w-5 mr-2 text-primary" />
              {t("settings.theme.title")}
            </CardTitle>
            <CardDescription>
              {t("settings.theme.description")}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>{t("settings.theme.darkMode")}</Label>
              <Button
                variant="outline"
                size="icon"
                onClick={toggleTheme}
              >
                {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-[#E6F591]/40 shadow-sm">
          <CardHeader className="bg-[#E6F591]/10 rounded-t-lg">
            <CardTitle className="text-foreground flex items-center">
              <Mail className="h-5 w-5 mr-2 text-[#38334D]" />
              {t("newsletter.title", "Newsletter")}
            </CardTitle>
            <CardDescription>
              {t("newsletter.description", "Recevez des conseils pour préparer de meilleurs sermons")}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>{t("newsletter.subscription", "S'abonner à la newsletter")}</Label>
                <p className="text-sm text-muted-foreground">
                  {t("newsletter.benefits", "Astuces, bonnes pratiques et ressources exclusives")}
                </p>
              </div>
              {checkingSubscription ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <div className="flex items-center space-x-3">
                  <Switch 
                    checked={isSubscribedToNewsletter} 
                    onCheckedChange={toggleNewsletterSubscription}
                    disabled={newsletterLoading}
                  />
                  {newsletterLoading && <Loader2 className="h-4 w-4 animate-spin" />}
                </div>
              )}
            </div>
            
            {!isSubscribedToNewsletter && !user?.email && (
              <Button 
                variant="outline" 
                className="w-full mt-2"
                onClick={() => setShowNewsletterPopup(true)}
              >
                {t("newsletter.subscribe", "S'abonner maintenant")}
              </Button>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button 
            onClick={handleSaveSettings} 
            disabled={isLoading}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            {isLoading ? t("settings.saving") : t("settings.save")}
          </Button>
        </div>
      </div>
      
      {/* Popups et modals */}
      <UpgradeModal
        isOpen={isUpgradeModalOpen}
        onClose={() => setIsUpgradeModalOpen(false)}
        currentTier={currentSubscriptionTier}
        onSuccess={handleUpgradeSuccess}
      />
      
      {/* Popup Newsletter */}
      <NewsletterPopup 
        forceOpen={showNewsletterPopup} 
        onClose={() => setShowNewsletterPopup(false)}
      />
    </div>
  );
}