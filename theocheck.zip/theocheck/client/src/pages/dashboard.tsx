import { useState, useEffect } from "react";
import { useAuth } from "@/lib/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, DollarSign, Share2, TrendingUp, Users, FileText, RefreshCw, PieChart } from "lucide-react";
import { useTranslation } from "react-i18next";
import { db } from "@/lib/firebase";
import { collection, getDocs, query, where, orderBy, limit } from "firebase/firestore";
import { 
  BarChart as RechartsBarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell
} from "recharts";

interface KPIData {
  totalDonations: number;
  totalRevenue: number;
  totalShares: number;
  totalAnalyses: number;
  engagementRate: number;
  recentEvents: any[];
}

export default function Dashboard() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [kpiData, setKpiData] = useState<KPIData>({
    totalDonations: 0,
    totalRevenue: 0,
    totalShares: 0,
    totalAnalyses: 0,
    engagementRate: 0,
    recentEvents: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadKPIData();
    }
  }, [user]);

  const loadKPIData = async () => {
    try {
      setLoading(true);

      // Load KPI data from our backend API instead of directly from Firebase
      const response = await fetch('/api/kpi-dashboard');
      
      if (response.ok) {
        const data = await response.json();
        console.log('KPI data from backend:', data);
        setKpiData({
          totalDonations: data.totalDonations || 0,
          totalRevenue: data.totalRevenue || 0,
          totalShares: data.totalShares || 0,
          totalAnalyses: data.totalAnalyses || 0,
          engagementRate: data.engagementRate || 0,
          recentEvents: data.recentEvents || []
        });
      } else {
        console.warn('Could not load KPI data from backend, using defaults');
        setKpiData({
          totalDonations: 0,
          totalRevenue: 0,
          totalShares: 0,
          totalAnalyses: 0,
          engagementRate: 0,
          recentEvents: []
        });
      }

    } catch (error) {
      console.error("Error loading KPI data:", error);
      // Set default values if there's an error
      setKpiData({
        totalDonations: 0,
        totalRevenue: 0,
        totalShares: 0,
        totalAnalyses: 0,
        engagementRate: 0,
        recentEvents: []
      });
    } finally {
      setLoading(false);
    }
  };

  const initializeFirebaseCollections = async () => {
    try {
      // Create sample documents to initialize collections
      const collections = [
        { name: 'donations', data: { initialized: true, timestamp: new Date() } },
        { name: 'sharing_events', data: { initialized: true, timestamp: new Date() } },
        { name: 'analysis_metrics', data: { initialized: true, timestamp: new Date() } },
        { name: 'kpi_events', data: { initialized: true, timestamp: new Date() } }
      ];

      for (const col of collections) {
        const docRef = collection(db, col.name);
        // This will create the collection if it doesn't exist
        console.log(`Initialized collection: ${col.name}`);
      }
    } catch (error) {
      console.error("Error initializing Firebase collections:", error);
    }
  };

  const testKPITracking = async () => {
    try {
      // Test tracking a donation
      await fetch('/api/track/donation-success', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentIntentId: 'test_' + Date.now(),
          amount: 5,
          userId: user?.uid
        })
      });

      // Test tracking a share
      await fetch('/api/track/share', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await user?.getIdToken()}`
        },
        body: JSON.stringify({
          shareMethod: 'test',
          sermonId: 1
        })
      });

      // Reload data
      await loadKPIData();
    } catch (error) {
      console.error("Error testing KPI tracking:", error);
    }
  };

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Access Denied</h1>
        <p>You need to be logged in to view the dashboard.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">TheoCheck Analytics Dashboard</h1>
        <div className="flex gap-2">
          <Button onClick={loadKPIData} variant="outline" disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh Data
          </Button>

        </div>
      </div>

      {loading ? (
        <div className="text-center py-8">Loading dashboard data...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Donations */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Donations</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpiData.totalDonations}</div>
              <p className="text-xs text-muted-foreground">
                €{kpiData.totalRevenue.toFixed(2)} total revenue
              </p>
            </CardContent>
          </Card>

          {/* Total Shares */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Platform Shares</CardTitle>
              <Share2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpiData.totalShares}</div>
              <p className="text-xs text-muted-foreground">
                Users sharing TheoCheck
              </p>
            </CardContent>
          </Card>

          {/* Total Analyses */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Sermon Analyses</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpiData.totalAnalyses}</div>
              <p className="text-xs text-muted-foreground">
                Total sermons analyzed
              </p>
            </CardContent>
          </Card>

          {/* Engagement Rate */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Engagement</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {kpiData.totalAnalyses > 0 ? Math.round((kpiData.totalShares / kpiData.totalAnalyses) * 100) : 0}%
              </div>
              <p className="text-xs text-muted-foreground">
                Share to analysis ratio
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Visual Charts Section */}
      {!loading && (
        <>
          {/* Chart Data Preparation */}
          {(() => {
            const barChartData = [
              {
                name: 'Donations',
                value: kpiData.totalDonations,
                color: '#3B82F6'
              },
              {
                name: 'Shares',
                value: kpiData.totalShares,
                color: '#10B981'
              },
              {
                name: 'Analyses',
                value: kpiData.totalAnalyses,
                color: '#F59E0B'
              }
            ];

            const pieChartData = [
              {
                name: 'Donations',
                value: kpiData.totalDonations,
                color: '#3B82F6'
              },
              {
                name: 'Shares',
                value: kpiData.totalShares,
                color: '#10B981'
              },
              {
                name: 'Analyses',
                value: kpiData.totalAnalyses,
                color: '#F59E0B'
              }
            ];

            const COLORS = ['#3B82F6', '#10B981', '#F59E0B'];

            return (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                {/* Bar Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart className="h-5 w-5" />
                      Activity Overview
                    </CardTitle>
                    <CardDescription>
                      Comparison of user engagement metrics
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RechartsBarChart data={barChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="value" fill="#3B82F6" />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Pie Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <PieChart className="h-5 w-5" />
                      Engagement Breakdown
                    </CardTitle>
                    <CardDescription>
                      Distribution of platform activities
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RechartsPieChart>
                        <Pie
                          data={pieChartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {pieChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            );
          })()}

          {/* Revenue Breakdown Chart */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Revenue & Support Metrics
              </CardTitle>
              <CardDescription>
                Financial support and engagement correlation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <RechartsBarChart data={[
                  { name: 'Revenue (€)', value: kpiData.totalRevenue, color: '#059669' },
                  { name: 'Donations', value: kpiData.totalDonations, color: '#3B82F6' },
                  { name: 'Engagement %', value: kpiData.engagementRate, color: '#F59E0B' }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value, name) => [
                    name.includes('€') ? `€${value}` : name.includes('%') ? `${value}%` : value,
                    name
                  ]} />
                  <Legend />
                  <Bar dataKey="value" fill="#059669" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </>
      )}

      {/* Recent Events */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest user interactions and events</CardDescription>
        </CardHeader>
        <CardContent>
          {kpiData.recentEvents.length > 0 ? (
            <div className="space-y-2">
              {kpiData.recentEvents.map((event, index) => (
                <div key={index} className="flex justify-between items-center p-2 border rounded">
                  <div>
                    <span className="font-medium">{event.eventType}</span>
                    {event.userId && (
                      <span className="text-sm text-muted-foreground ml-2">
                        User: {event.userId.substring(0, 8)}...
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {event.timestamp?.toDate?.()?.toLocaleDateString() || 'No date'}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No recent events. Click 'Test KPI Tracking' to generate sample data.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}