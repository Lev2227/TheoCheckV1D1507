import { apiRequest } from "./queryClient";

export async function analyzeSermon(content: string) {
  const response = await apiRequest("POST", "/api/analyze", { content });
  return response.json();
}