import { apiRequest } from './queryClient';

export interface NewsletterSubscription {
  email: string;
  subscribeDate: Date;
  userId?: string; // Optionnel, pour lier à un utilisateur connecté
  active: boolean;
  locale: string; // 'fr' ou 'en' - préférence de langue pour la newsletter
}

/**
 * Vérifie si un email est déjà abonné à la newsletter
 */
export async function isEmailSubscribed(email: string): Promise<boolean> {
  try {
    if (!email) {
      console.error('Email requis pour vérifier l\'abonnement');
      return false;
    }
    
    console.log('Vérification du statut d\'abonnement pour:', email);
    
    const response = await apiRequest('GET', `/api/newsletter/status?email=${encodeURIComponent(email)}`);
    
    if (!response.ok) {
      throw new Error(`Erreur lors de la vérification: ${response.status}`);
    }
    
    const data = await response.json();
    console.log('Statut d\'abonnement:', data);
    
    return data.subscribed;
  } catch (error) {
    console.error('Erreur lors de la vérification de l\'abonnement:', error);
    return false;
  }
}

/**
 * Ajoute un nouvel abonné à la newsletter
 */
export async function subscribeToNewsletter(
  email: string, 
  userId?: string,
  locale: string = 'fr'
): Promise<boolean> {
  try {
    if (!email) {
      console.error('Email requis pour l\'abonnement');
      return false;
    }
    
    console.log('Abonnement à la newsletter pour:', email);
    
    const response = await apiRequest('POST', '/api/newsletter/subscribe', {
      email,
      userId,
      locale
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('Détails de l\'erreur d\'abonnement:', errorData);
      throw new Error(`Erreur lors de l'abonnement: ${response.status}`);
    }
    
    const data = await response.json();
    console.log('Résultat abonnement:', data);
    
    // Stocker dans localStorage pour usage hors ligne
    if (data.success) {
      localStorage.setItem('theocheck_newsletter_subscribed', 'true');
      localStorage.setItem('theocheck_newsletter_email', email);
    }
    
    return data.success;
  } catch (error) {
    console.error('Erreur lors de l\'abonnement à la newsletter:', error);
    return false;
  }
}

/**
 * Met à jour l'abonnement d'un utilisateur existant (utilisé dans les paramètres)
 */
export async function updateUserSubscription(
  userId: string, 
  isSubscribed: boolean,
  email?: string
): Promise<boolean> {
  try {
    if (!userId && !email) {
      console.error('UserId ou email requis pour mettre à jour l\'abonnement');
      return false;
    }
    
    console.log('Mise à jour de l\'abonnement pour:', userId || email);
    
    if (isSubscribed) {
      // Si on veut s'abonner, on utilise l'API d'abonnement
      if (email) {
        return await subscribeToNewsletter(email, userId);
      } else {
        console.error('Email requis pour créer un nouvel abonnement');
        return false;
      }
    } else {
      // Si on veut se désabonner
      const response = await apiRequest('POST', '/api/newsletter/unsubscribe', {
        userId,
        email
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Détails de l\'erreur de désabonnement:', errorData);
        throw new Error(`Erreur lors du désabonnement: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('Résultat désabonnement:', data);
      
      // Mettre à jour localStorage
      if (data.success) {
        localStorage.setItem('theocheck_newsletter_subscribed', 'false');
      }
      
      return data.success;
    }
  } catch (error) {
    console.error('Erreur lors de la mise à jour de l\'abonnement:', error);
    return false;
  }
}