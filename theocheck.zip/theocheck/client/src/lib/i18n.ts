import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// French translations
const fr = {
  payment: {
    title: "Paiement",
    checkoutTitle: "Finaliser votre paiement",
    checkoutDescription: "Veuillez entrer vos informations de paiement ci-dessous",
    securePayment: "Traitement sécurisé du paiement",
    amount: "Montant",
    pay: "Payer maintenant",
    processing: "Traitement en cours...",
    cancel: "Annuler",
    success: "Paiement réussi",
    successMessage: "Merci pour votre soutien !",
    error: "Échec du paiement",
    genericError: "Une erreur s'est produite lors du traitement du paiement",
    intentError: "Erreur lors de la création de l'intention de paiement",
    donationDescription: "Don pour TheoCheck",
    verifying: "Vérification du paiement",
    verifyingDescription: "Veuillez patienter pendant que nous vérifions votre paiement...",
    paymentSuccessTitle: "Paiement réussi !",
    paymentError: "Erreur de paiement",
    whatNext: "Ce que vous pouvez attendre maintenant :",
    benefitAnalysis: "Capacités d'analyse de sermon améliorées",
    benefitExport: "Exportez votre analyse dans plusieurs formats",
    benefitSupport: "Support prioritaire pour vos questions",
    analyzeSermon: "Analyser un sermon",
    proceedToPayment: "Procéder au paiement",
    missingParams: "Informations de paiement manquantes",
    verificationError: "Erreur lors de la vérification de votre paiement",
  },
  share: {
    title: "Partager l'analyse",
    description: "Partagez les résultats d'analyse avec d'autres personnes",
    copy: "Copier le lien",
    footer: "En partageant cette analyse, vous acceptez nos conditions d'utilisation.",
    theocheck: {
      title: "Partager TheoCheck",
      description: "Aidez vos amis prédicateurs à améliorer leurs sermons avec TheoCheck"
    }
  },
  promotion: {
    likeOurService: "Vous aimez TheoCheck ?",
    helpUsGrow: "Aidez-nous à grandir en partageant TheoCheck avec vos amis et collègues prédicateurs. Votre soutien fait toute la différence !",
    shareWithFriends: "Partager avec des amis",
    supportUs: "Soutenir financièrement"
  },
  donation: {
    title: "Soutenez TheoCheck",
    description: "Votre soutien financier nous aide à maintenir et améliorer TheoCheck pour tous les utilisateurs",
    amount: "Montant",
    custom: "Personnalisé",
    submit: "Faire un don",
    donate: "Faire un don",
    processing: "Traitement en cours...",
    thanks: "Merci pour votre soutien !",
    thanksMessage: "Votre contribution aide TheoCheck à continuer sa mission de soutien aux prédicateurs.",
    monthly: "Don mensuel",
    oneTime: "Don unique",
    promotion: "Merci d'avoir utilisé TheoCheck! Souhaitez-vous soutenir notre mission?",
    chooseAmount: "Choisissez un montant",
    popular: "Populaire",
    footer: "Votre don aide à maintenir et améliorer TheoCheck",
    success: {
      title: "Merci pour votre don !",
      description: "Votre soutien est très apprécié et nous aide à continuer notre mission."
    },
    error: "Une erreur s'est produite lors du traitement de votre don",
    small: {
      title: "Petite tasse",
      description: "Équivalent d'un café, montre votre appréciation"
    },
    medium: {
      title: "Bon coup de pouce",
      description: "Aide à maintenir notre service et à l'améliorer"
    },
    large: {
      title: "Grand soutien",
      description: "Contribue au développement de nouvelles fonctionnalités"  
    }
  },
  auth: {
    welcome: "Bienvenue sur TheoCheck",
    startAnalyzing: "Connectez-vous pour commencer à analyser vos sermons",
    login: "Se connecter",
    register: "S'inscrire",
    email: "Email",
    password: "Mot de passe",
    confirmPassword: "Confirmer le mot de passe",
    loginSuccess: "Connexion réussie",
    loginError: "Erreur de connexion",
    registerSuccess: "Inscription réussie",
    registerError: "Erreur d'inscription",
    loggingIn: "Connexion...",
    registering: "Inscription...",
    welcomeMessage: "Bienvenue sur TheoCheck",
    analyzeWith: "Analysez vos sermons avec TheoCheck",
    errors: {
      generic: "Une erreur s'est produite lors de la connexion",
      userNotFound: "Aucun compte trouvé avec cet email",
      wrongPassword: "Mot de passe incorrect",
      invalidEmail: "Format d'email invalide",
      passwordMismatch: "Les mots de passe ne correspondent pas",
      genericRegister: "Une erreur s'est produite lors de l'inscription",
      emailInUse: "Un compte existe déjà avec cet email",
      weakPassword: "Le mot de passe doit contenir au moins 6 caractères"
    },
    features: {
      analysis: "Analyse détaillée de la structure et du contenu",
      charts: "Graphiques interactifs pour visualiser les points forts",
      suggestions: "Suggestions personnalisées pour améliorer vos prédications",
      pdf: "Rapports PDF téléchargeables"
    }
  },
  common: {
    analyze: "Analysez votre sermon",
    learnMore: "En savoir plus",
    login: "Connexion",
    logout: "Déconnexion",
    settings: "Paramètres",
    userPreferences: "Préférences utilisateur",
    language: "Langue et région",
    notifications: "Notifications",
    contact: "Contact",
    about: "À propos",
    criteria: "Critères d'analyse",
    languageChanged: "Langue modifiée",
    languageChangeEffect: "Les changements sont appliqués",
    error: "Erreur",
    comingSoon: "bientôt disponible",
    returnHome: "Retour à l'accueil",
    betaMessage: "TheoCheck est en version bêta. Des nouvelles fonctionnalités et améliorations sont en cours de développement. Vous pourriez rencontrer quelques bugs.",
    privacy: "Politique de confidentialité",
    terms: "Conditions d'utilisation",
    cancel: "Annuler",
    processing: "Traitement en cours...",
    share: "Partager",
    donate: "Soutenir",
    copied: "Copié",
    linkCopied: "Lien copié dans le presse-papier",
    maybeNextTime: "Peut-être une prochaine fois"
  },
  home: {
    title: "Analysez vos sermons avec l'IA",
    subtitle: "Soumettez votre sermon et recevez une analyse détaillée, des retours personnalisés, et des suggestions concrètes pour améliorer votre prédication.",
    features: {
      analysis: {
        title: "Analyse complète",
        description: "Évaluation détaillée de votre sermon selon plusieurs critères",
        items: [
          "Structure et cohérence",
          "Clarté théologique",
          "Pertinence et application",
          "Engagement et style"
        ]
      },
      visualization: {
        title: "Visualisation interactive",
        description: "Graphiques et statistiques pour mieux comprendre vos forces et faiblesses",
        items: [
          "Graphique radar des compétences",
          "Histogramme des points forts",
          "Analyse comparative",
          "Suivi des progrès"
        ]
      },
      report: {
        title: "Rapport détaillé",
        description: "Téléchargez un rapport complet pour approfondir votre analyse",
        items: [
          "Rapport PDF téléchargeable",
          "Conseils personnalisés",
          "Suggestions d'amélioration",
          "Ressources recommandées"
        ]
      }
    }
  },
  sermons: {
    success: "Succès",
    submissionSuccess: "Votre sermon a été soumis avec succès pour analyse",
    analysisError: "Une erreur s'est produite lors de l'analyse",
    serviceUnavailable: "Le service d'analyse est temporairement indisponible. Veuillez réessayer dans quelques minutes.",
    authError: "Erreur d'authentification. Veuillez vous reconnecter.",
    form: {
      title: "Titre du sermon",
      content: "Contenu du sermon",
      bibleReference: "Référence biblique (Optionnel)",
      bibleReferencePlaceholder: "ex: Jean 3:16",
      analyzing: "Analyse en cours...",
      submit: "Analyser le sermon"
    }
  },
  analysis: {
    results: "Résultats de l'Analyse",
    overallScore: "Note Globale",
    strengths: "Points Forts",
    improvements: "Points à Améliorer",
    summary: "Résumé",
    keyScriptures: "Références Bibliques Clés",
    applicationPoints: "Points d'Application",
    theologicalTradition: "Tradition Théologique",
    downloadPdf: "Télécharger le Rapport PDF",
    emotionalMeter: "Compteur d'Émotions",
    emotionalMeterDescription: "Les émotions véhiculées par le prédicateur dans ce sermon",
    detailedAnalysis: "Analyse Détaillée",
    detailedDescription: "Évaluation intégrée dans le texte avec commentaires et retours",
    generating: "Génération en cours...",
    success: "Analyse Détaillée Terminée",
    successDetails: "Votre sermon a été analysé en détail. Consultez les commentaires et suggestions ci-dessous.",
    emotions: {
      joy: "Joie",
      hope: "Espoir",
      conviction: "Conviction",
      compassion: "Compassion",
      urgency: "Urgence",
      reverence: "Révérence"
    },
    scores: {
      biblicalFidelity: "Fidélité Biblique",
      structure: "Structure",
      practicalApplication: "Application Pratique",
      authenticity: "Authenticité",
      interactivity: "Interactivité"
    }
  },
  about: {
    title: "À propos de TheoCheck",
    mission: {
      title: "Notre Mission",
      description: "Dans un monde où les principes de base du christianisme sont le plus souvent ignorés, les églises et les pasteurs sont appelés à communiquer l'évangile avec justesse et clarté. Mais comment savoir si une prédication va réellement toucher son auditoire ?"
    },
    solution: {
      title: "TheoCheck est la solution",
      description: "Nous offrons une évaluation précise de vos prises de parole en nous appuyant sur des critères objectifs et une analyse guidée par des principes bibliques."
    },
    quote: {
      text: "Il n'existe aucune raison pour que la prédication de l'Évangile soit vécue comme un fardeau, ni pour l'orateur ni pour son auditoire.",
      author: "Charles Spurgeon"
    },
    future: {
      text: "Demain, les pasteurs ne se demanderont plus seulement \"As-tu bien préparé ta prédication ?\" mais \"Est-ce que tu l'as ThéoChecké ?\""
    },
    commitment: {
      text: "Parce que la vérité mérite d'être bien communiquée, et que la croissance spirituelle passe par une évaluation constructive."
    },
    tagline: "L'Esprit guide, nous assistons",
    team: {
      title: "Qui sommes-nous ?",
      description: "Nous sommes une équipe désireuse de mettre la technologie au service de l'évangile.",
      members: {
        stephane: {
          name: "Stéphane",
          description: "Des idées plein la tête, une vie professionnelle déjà bien remplie, j'ai créé il y a deux ans Par L'Écoute, une société de services chrétienne friendly pour mettre mes compétences au service des organisations qui servent l'évangile, et développer des projets qui poursuivent le même objectif."
        },
        lev: {
          name: "Lev",
          description: "Arrivé en France en 2022 après l'invasion de l'Ukraine et passionné par le marketing, je suis convaincu qu'il n'est jamais trop tôt pour se lancer. Le projet TheoCheck s'inscrit dans mon ambition d'intégrer le domaine du marketing après un BAC +3 en Techniques de Commercialisation des Systèmes Industriels. Il me permet d'acquérir des méthodes de travail efficaces et de développer des compétences essentielles pour mon avenir professionnel."
        },
        ivan: {
          name: "Ivan",
          description: "Lycéen de 18 ans, intéressé par la technologie et l'innovation, j'ai intégré TheoCheck pour développer des compétences dans le milieu du marketing et en apprendre plus sur les outils de l'intelligence artificielle. Je souhaite acquérir de l'expérience professionnelle et mettre mon travail au service des projets innovants et à fort impact. Curieux et motivé, je cherche à comprendre comment l'intelligence artificielle peut transformer le monde."
        }
      }
    }
  },
  contact: {
    title: "Contactez-nous",
    description: "Notre équipe est là pour vous aider. N'hésitez pas à nous contacter pour toute question.",
    success: "Message envoyé",
    successMessage: "Votre message a été envoyé avec succès. Nous vous répondrons dans les plus brefs délais.",
    error: "Erreur",
    errorMessage: "Une erreur s'est produite lors de l'envoi du message. Veuillez réessayer.",
    form: {
      name: "Nom",
      email: "Email",
      message: "Message",
      subject: "Sujet",
      submit: "Envoyer",
      sending: "Envoi en cours..."
    }
  },
  settings: {
    title: "Paramètres",
    success: "Paramètres sauvegardés",
    successMessage: "Vos préférences ont été mises à jour avec succès.",
    error: "Erreur",
    errorMessage: "Une erreur est survenue lors de la sauvegarde des paramètres.",
    saving: "Sauvegarde en cours...",
    save: "Sauvegarder les changements",
    language: {
      description: "Choisissez votre langue préférée",
      preference: "Langue de l'interface"
    },
    preferences: {
      title: "Préférences d'Analyse",
      description: "Personnalisez la façon dont vos sermons sont analysés",
      theologicalTradition: "Tradition Théologique",
      audience: "Préférences d'analyse",
      select: "Sélectionnez...",
      traditions: {
        reformed: "Réformée",
        lutheran: "Luthérienne",
        catholic: "Catholique",
        baptist: "Baptiste",
        pentecostal: "Pentecôtiste"
      },
      audiences: {
        committed: "Chrétiens convaincus",
        seekers: "Chercheurs spirituels",
        nonbelievers: "Non croyants",
        youth: "Jeunesse",
        mixed: "Public mixte"
      }
    },
    theme: {
      title: "Apparence",
      description: "Personnalisez l'apparence de l'application",
      darkMode: "Mode sombre"
    },
    notifications: {
      title: "Notifications",
      description: "Gérez vos préférences de notification",
      email: "Notifications par Email",
      analysis: "Analyse Terminée"
    }
  },
  errors: {
    error: "Erreur",
    loginRequired: "Veuillez vous connecter pour télécharger le rapport",
    pdfDownloadFailed: "Erreur lors du téléchargement du rapport",
    analysisError: "Erreur d'analyse",
    serviceUnavailable: "Le service d'analyse est temporairement indisponible. Veuillez réessayer dans quelques minutes.",
    contentRequired: "Le contenu du sermon est nécessaire pour l'analyse détaillée",
    analysisGenerationFailed: "Échec de la génération de l'analyse détaillée",
    copyFailed: "Impossible de copier le lien"
  },
  subscription: {
    title: "Abonnement",
    description: "Gérez votre abonnement et accédez à des fonctionnalités premium",
    featuresTitle: "Fonctionnalités", // Pour l'affichage du titre de la section
    featuresList: "Liste des fonctionnalités",
    status: "Statut de l'abonnement",
    activeUntil: "Actif jusqu'au {{date}}",
    autoRenewEnabled: "Renouvellement automatique activé",
    autoRenewDisabled: "Renouvellement automatique désactivé",
    upgrade: "Passer à la version premium",
    manage: "Gérer l'abonnement",
    viewInvoices: "Voir les factures",
    tiers: {
      free: "Gratuit",
      premium: "Premium",
      enterprise: "Enterprise"
    },
    popular: "Populaire",
    premiumRecommendation: "Le meilleur rapport qualité-prix, recommandé pour les prédicateurs réguliers",
    sermonLimit: "Limite de {{count}} sermons par mois",
    detailedAnalysis: "Analyse détaillée dans le texte",
    prioritySupport: "Support prioritaire",
    exportFormats: "Formats d'export: {{formats}}",
    perMonth: "par mois",
    upgradePlan: "Mettre à niveau votre abonnement",
    upgradePlanDescription: "Choisissez un abonnement qui correspond à vos besoins",
    currentPlan: "Actuel",
    currentPlanButton: "Votre forfait actuel",
    selectPlan: "Sélectionner",
    proceedToPayment: "Procéder au paiement",
    upgradeSuccess: "Mise à niveau réussie",
    upgradeSuccessDetails: "Votre abonnement a été mis à niveau avec succès",
    upgradeError: "Erreur de mise à niveau",
    upgradeErrorDetails: "Une erreur s'est produite lors de la mise à niveau de votre abonnement",
    features: {
      sermonLimit: "{{count}} sermons par mois",
      unlimitedSermons: "Sermons illimités",
      basicAnalysis: "Analyse de base",
      pdfExport: "Export PDF",
      detailedAnalysis: "Analyse détaillée dans le texte",
      prioritySupport: "Support prioritaire",
      advancedExports: "Exports avancés (PDF, DOCX, HTML)"
    },
    free: "Gratuit",
    pricePerMonth: "{{price}}€ / mois"
  },
  terms: {
    title: "Conditions d'Utilisation",
    introduction: {
      title: "Introduction",
      content: "Bienvenue sur TheoCheck. Veuillez lire attentivement ces conditions d'utilisation avant d'utiliser notre application. En utilisant TheoCheck, vous acceptez d'être lié par ces conditions."
    },
    acceptanceOfTerms: {
      title: "Acceptation des Conditions",
      content: "En accédant à TheoCheck ou en l'utilisant, vous acceptez d'être lié par ces Conditions d'Utilisation et par toutes les lois et réglementations applicables. Si vous n'acceptez pas ces conditions, vous ne pouvez pas utiliser TheoCheck."
    },
    services: {
      title: "Description des Services",
      content: "TheoCheck est un service d'analyse de sermons assisté par intelligence artificielle qui offre les fonctionnalités suivantes :",
      items: {
        analysis: "Analyse de sermons basée sur des critères théologiques et homilétiques",
        feedback: "Retours personnalisés et suggestions d'amélioration",
        storage: "Stockage sécurisé de vos sermons et analyses",
        export: "Possibilité d'exporter et de partager vos analyses"
      }
    },
    intellectualProperty: {
      title: "Propriété Intellectuelle",
      content1: "TheoCheck, y compris son contenu, ses fonctionnalités et sa technologie, est protégé par les lois sur la propriété intellectuelle.",
      content2: "Vous conservez tous les droits sur les sermons et autres contenus que vous soumettez à TheoCheck pour analyse."
    },
    userContent: {
      title: "Contenu Utilisateur",
      content1: "En soumettant du contenu à TheoCheck, vous garantissez que vous avez le droit de le faire et que ce contenu ne viole pas les droits d'autrui.",
      content2: "Nous ne revendiquons aucun droit de propriété sur votre contenu, mais nous nous réservons le droit de l'utiliser de manière anonymisée pour améliorer nos services."
    },
    liability: {
      title: "Limitation de Responsabilité",
      content: "TheoCheck est fourni 'tel quel' sans garantie d'aucune sorte. Nous ne garantissons pas l'exactitude, la fiabilité ou l'efficacité des analyses produites par notre service."
    },
    privacy: {
      title: "Confidentialité",
      content: "Votre vie privée est importante pour nous. Notre Politique de Confidentialité explique comment nous recueillons, utilisons et protégeons vos informations personnelles."
    },
    changes: {
      title: "Modifications des Conditions",
      content: "Nous nous réservons le droit de modifier ces conditions à tout moment. Votre utilisation continue de TheoCheck après de telles modifications constitue votre acceptation des nouvelles conditions."
    },
    contact: {
      title: "Contact",
      content: "Si vous avez des questions concernant ces conditions, veuillez nous contacter via notre formulaire de contact."
    },
    lastUpdated: "Dernière mise à jour : {{date}}"
  }
};

// English translations
const en = {
  payment: {
    title: "Checkout",
    checkoutTitle: "Complete Your Payment",
    checkoutDescription: "Please enter your payment details below",
    securePayment: "Secure payment processing",
    amount: "Amount",
    pay: "Pay Now",
    processing: "Processing...",
    cancel: "Cancel",
    success: "Payment Successful",
    successMessage: "Thank you for your support!",
    error: "Payment Failed",
    genericError: "An error occurred during payment processing",
    intentError: "Error creating payment intent",
    donationDescription: "TheoCheck donation",
    verifying: "Verifying payment",
    verifyingDescription: "Please wait while we verify your payment...",
    paymentSuccessTitle: "Payment Successful!",
    paymentError: "Payment Error",
    whatNext: "What you can expect now:",
    benefitAnalysis: "Enhanced sermon analysis capabilities",
    benefitExport: "Export your analysis in multiple formats",
    benefitSupport: "Priority support for your questions",
    analyzeSermon: "Analyze a sermon",
    proceedToPayment: "Proceed to checkout",
    missingParams: "Missing payment information",
    verificationError: "Error verifying your payment",
  },
  share: {
    title: "Share Analysis",
    description: "Share analysis results with others",
    copy: "Copy link",
    footer: "By sharing this analysis, you agree to our terms of use.",
    theocheck: {
      title: "Share TheoCheck",
      description: "Help your preacher friends improve their sermons with TheoCheck"
    }
  },
  promotion: {
    likeOurService: "Do you like TheoCheck?",
    helpUsGrow: "Help us grow by sharing TheoCheck with your friends and fellow preachers. Your support makes all the difference!",
    shareWithFriends: "Share with friends",
    supportUs: "Support financially"
  },
  donation: {
    title: "Support TheoCheck",
    description: "Your financial support helps us maintain and improve TheoCheck for all users",
    amount: "Amount",
    custom: "Custom",
    submit: "Donate",
    donate: "Donate",
    processing: "Processing...",
    thanks: "Thank you for your support!",
    thanksMessage: "Your contribution helps TheoCheck continue its mission of supporting preachers.",
    monthly: "Monthly donation",
    oneTime: "One-time donation",
    promotion: "Thank you for using TheoCheck! Would you like to support our mission?",
    chooseAmount: "Choose an amount",
    popular: "Popular",
    footer: "Your donation helps maintain and improve TheoCheck",
    success: {
      title: "Thank you for your donation!",
      description: "Your support is greatly appreciated and helps us continue our mission."
    },
    error: "An error occurred while processing your donation",
    small: {
      title: "Small Cup",
      description: "Equivalent to a coffee, shows your appreciation"
    },
    medium: {
      title: "Good Boost",
      description: "Helps maintain our service and improve it"
    },
    large: {
      title: "Great Support",
      description: "Contributes to the development of new features"  
    }
  },
  auth: {
    welcome: "Welcome to TheoCheck",
    startAnalyzing: "Sign in to start analyzing your sermons",
    login: "Sign in",
    register: "Sign up",
    email: "Email",
    password: "Password",
    confirmPassword: "Confirm Password",
    loginSuccess: "Login Successful",
    loginError: "Login Error",
    registerSuccess: "Registration Successful",
    registerError: "Registration Error",
    loggingIn: "Signing in...",
    registering: "Signing up...",
    welcomeMessage: "Welcome to TheoCheck",
    analyzeWith: "Analyze your sermons with TheoCheck",
    errors: {
      generic: "An error occurred during login",
      userNotFound: "No account found with this email",
      wrongPassword: "Incorrect password",
      invalidEmail: "Invalid email format",
      passwordMismatch: "Passwords do not match",
      genericRegister: "An error occurred during registration",
      emailInUse: "An account already exists with this email",
      weakPassword: "Password must be at least 6 characters"
    },
    features: {
      analysis: "Detailed analysis of structure and content",
      charts: "Interactive charts to visualize strengths",
      suggestions: "Personalized suggestions to improve your preaching",
      pdf: "Downloadable PDF reports"
    }
  },
  common: {
    analyze: "Analyze your sermon",
    learnMore: "Learn more",
    login: "Login",
    logout: "Logout",
    settings: "Settings",
    userPreferences: "User Preferences",
    language: "Language & Region",
    notifications: "Notifications",
    contact: "Contact",
    about: "About",
    criteria: "Analysis Criteria",
    languageChanged: "Language Changed",
    languageChangeEffect: "Changes have been applied",
    error: "Error",
    comingSoon: "coming soon",
    returnHome: "Return to Home",
    betaMessage: "TheoCheck is in beta. New features and improvements are under development. You may encounter some bugs.",
    privacy: "Privacy Policy",
    terms: "Terms of Use",
    cancel: "Cancel",
    processing: "Processing...",
    share: "Share",
    donate: "Support",
    copied: "Copied",
    linkCopied: "Link copied to clipboard",
    maybeNextTime: "Maybe next time"
  },
  home: {
    title: "Analyze Your Sermons with AI",
    subtitle: "Submit your sermon and receive detailed analysis, personalized feedback, and concrete suggestions to improve your preaching.",
    features: {
      analysis: {
        title: "Complete Analysis",
        description: "Detailed evaluation of your sermon across multiple criteria",
        items: [
          "Structure and coherence",
          "Theological clarity",
          "Relevance and application",
          "Engagement and style"
        ]
      },
      visualization: {
        title: "Interactive Visualization",
        description: "Charts and statistics to better understand your strengths and weaknesses",
        items: [
          "Skills radar chart",
          "Strengths histogram",
          "Comparative analysis",
          "Progress tracking"
        ]
      },
      report: {
        title: "Detailed Report",
        description: "Download a comprehensive report to deepen your analysis",
        items: [
          "Downloadable PDF report",
          "Personalized advice",
          "Improvement suggestions",
          "Recommended resources"
        ]
      }
    }
  },
  sermons: {
    success: "Success",
    submissionSuccess: "Your sermon has been successfully submitted for analysis",
    analysisError: "An error occurred during analysis",
    serviceUnavailable: "The analysis service is temporarily unavailable. Please try again in a few minutes.",
    authError: "Authentication error. Please log in again.",
    form: {
      title: "Sermon Title",
      content: "Sermon Content",
      bibleReference: "Bible Reference (Optional)",
      bibleReferencePlaceholder: "e.g. John 3:16",
      analyzing: "Analysis in progress...",
      submit: "Analyze Sermon"
    }
  },
  analysis: {
    results: "Analysis Results",
    overallScore: "Overall Score",
    strengths: "Strengths",
    improvements: "Areas for Improvement",
    summary: "Summary",
    keyScriptures: "Key Scripture References",
    applicationPoints: "Application Points",
    theologicalTradition: "Theological Tradition",
    downloadPdf: "Download PDF Report",
    emotionalMeter: "Emotion Meter",
    emotionalMeterDescription: "Emotions conveyed by the preacher in this sermon",
    detailedAnalysis: "Detailed Analysis",
    detailedDescription: "In-text evaluation with comments and feedback",
    generating: "Generating...",
    success: "Detailed Analysis Complete",
    successDetails: "Your sermon has been analyzed in detail. Review the comments and suggestions below.",
    emotions: {
      joy: "Joy",
      hope: "Hope",
      conviction: "Conviction",
      compassion: "Compassion",
      urgency: "Urgency",
      reverence: "Reverence"
    },
    scores: {
      biblicalFidelity: "Biblical Fidelity",
      structure: "Structure",
      practicalApplication: "Practical Application",
      authenticity: "Authenticity",
      interactivity: "Interactivity"
    }
  },
  about: {
    title: "About TheoCheck",
    mission: {
      title: "Our Mission",
      description: "In a world where the basic principles of Christianity are often ignored, churches and pastors are called to communicate the gospel with accuracy and clarity. But how can we ensure that a sermon will truly reach its audience?"
    },
    solution: {
      title: "TheoCheck is the solution",
      description: "We offer precise evaluation of your speaking by relying on objective criteria and analysis guided by biblical principles."
    },
    quote: {
      text: "No reason exists why the preaching of the gospel should be a miserable operation either to the speaker or to the hearer.",
      author: "Charles Spurgeon"
    },
    future: {
      text: "Tomorrow, pastors won't just ask \"Have you prepared your sermon well?\" but \"Have you TheoChecked it?\""
    },
    commitment: {
      text: "Because truth deserves to be well communicated, and spiritual growth comes through constructive evaluation."
    },
    tagline: "The Spirit guides, we assist",
    team: {
      title: "Who are we?",
      description: "We are a team eager to put technology at the service of the gospel.",
      members: {
        stephane: {
          name: "Stéphane",
          description: "Full of ideas and with an already busy professional life, two years ago I created Par L'Écoute, a Christian-friendly service company to put my skills at the service of organizations that serve the gospel, and develop projects that pursue the same goal."
        },
        lev: {
          name: "Lev",
          description: "Having arrived in France in 2022 after the invasion of Ukraine and passionate about marketing, I firmly believe it's never too early to start. The TheoCheck project aligns with my ambition to enter the marketing field after completing a Bachelor's degree in Industrial Systems Marketing. It allows me to acquire effective work methods and develop essential skills for my professional future."
        },
        ivan: {
          name: "Ivan",
          description: "As an 18-year-old high school student interested in technology and innovation, I joined TheoCheck to develop skills in marketing and learn more about artificial intelligence tools. I aim to gain professional experience and contribute to innovative projects with significant impact. Curious and motivated, I seek to understand how artificial intelligence can transform the world."
        }
      }
    }
  },
  contact: {
    title: "Contact Us",
    description: "Our team is here to help. Feel free to reach out with any questions.",
    success: "Message Sent",
    successMessage: "Your message has been sent successfully. We will get back to you soon.",
    error: "Error",
    errorMessage: "An error occurred while sending your message. Please try again.",
    form: {
      name: "Name",
      email: "Email",
      message: "Message",
      subject: "Subject",
      submit: "Send",
      sending: "Sending..."
    }
  },
  settings: {
    title: "Settings",
    success: "Settings saved",
    successMessage: "Your preferences have been updated successfully.",
    error: "Error",
    errorMessage: "An error occurred while saving settings.",
    saving: "Saving...",
    save: "Save changes",
    language: {
      description: "Choose your preferred language",
      preference: "Interface language"
    },
    preferences: {
      title: "Analysis Preferences",
      description: "Customize how your sermons are analyzed",
      theologicalTradition: "Theological Tradition",
      audience: "Analysis Preferences",
      select: "Select...",
      traditions: {
        reformed: "Reformed",
        lutheran: "Lutheran",
        catholic: "Catholic",
        baptist: "Baptist",
        pentecostal: "Pentecostal"
      },
      audiences: {
        committed: "Committed Christians",
        seekers: "Spiritual seekers",
        nonbelievers: "Non-believers", 
        youth: "Youth",
        mixed: "Mixed audience"
      }
    },
    theme: {
      title: "Appearance",
      description: "Customize the application appearance",
      darkMode: "Dark mode"
    },
    notifications: {
      title: "Notifications",
      description: "Manage your notification preferences",
      email: "Email notifications",
      analysis: "Analysis Complete"
    }
  },
  errors: {
    error: "Error",
    loginRequired: "Please login to download the report",
    pdfDownloadFailed: "Failed to download the report",
    analysisError: "Analysis Error",
    serviceUnavailable: "The analysis service is temporarily unavailable. Please try again in a few minutes.",
    contentRequired: "Sermon content is required for detailed analysis",
    analysisGenerationFailed: "Failed to generate detailed analysis",
    copyFailed: "Failed to copy link"
  },
  subscription: {
    title: "Subscription",
    description: "Manage your subscription and access premium features",
    featuresTitle: "Features",
    featuresList: "Features",
    status: "Subscription Status",
    activeUntil: "Active until {{date}}",
    autoRenewEnabled: "Auto-renewal enabled",
    autoRenewDisabled: "Auto-renewal disabled",
    upgrade: "Upgrade to premium",
    manage: "Manage subscription",
    viewInvoices: "View invoices",
    tiers: {
      free: "Free",
      premium: "Premium",
      enterprise: "Enterprise"
    },
    popular: "Popular",
    premiumRecommendation: "Best value for money, recommended for regular preachers",
    sermonLimit: "Limit of {{count}} sermons per month",
    detailedAnalysis: "Detailed in-text analysis",
    prioritySupport: "Priority support",
    exportFormats: "Export formats: {{formats}}",
    perMonth: "per month",
    upgradePlan: "Upgrade your plan",
    upgradePlanDescription: "Choose a plan that suits your needs",
    currentPlan: "Current",
    currentPlanButton: "Your current plan",
    selectPlan: "Select",
    proceedToPayment: "Proceed to payment",
    upgradeSuccess: "Upgrade successful",
    upgradeSuccessDetails: "Your subscription has been successfully upgraded",
    upgradeError: "Upgrade error",
    upgradeErrorDetails: "An error occurred while upgrading your subscription",
    features: {
      sermonLimit: "{{count}} sermons per month",
      unlimitedSermons: "Unlimited sermons",
      basicAnalysis: "Basic analysis",
      pdfExport: "PDF export",
      detailedAnalysis: "Detailed in-text analysis",
      prioritySupport: "Priority support",
      advancedExports: "Advanced exports (PDF, DOCX, HTML)"
    },
    free: "Free",
    pricePerMonth: "${{price}} / month"
  },
  terms: {
    title: "Terms of Use",
    introduction: {
      title: "Introduction",
      content: "Welcome to TheoCheck. Please read these terms of use carefully before using our application. By using TheoCheck, you agree to be bound by these terms."
    },
    acceptanceOfTerms: {
      title: "Acceptance of Terms",
      content: "By accessing or using TheoCheck, you agree to be bound by these Terms of Use and by all applicable laws and regulations. If you do not agree to these terms, you may not use TheoCheck."
    },
    services: {
      title: "Description of Services",
      content: "TheoCheck is an AI-assisted sermon analysis service offering the following features:",
      items: {
        analysis: "Sermon analysis based on theological and homiletical criteria",
        feedback: "Personalized feedback and improvement suggestions",
        storage: "Secure storage of your sermons and analyses",
        export: "Ability to export and share your analyses"
      }
    },
    intellectualProperty: {
      title: "Intellectual Property",
      content1: "TheoCheck, including its content, features, and technology, is protected by intellectual property laws.",
      content2: "You retain all rights to the sermons and other content you submit to TheoCheck for analysis."
    },
    userContent: {
      title: "User Content",
      content1: "By submitting content to TheoCheck, you warrant that you have the right to do so and that the content does not violate the rights of others.",
      content2: "We do not claim ownership of your content, but we reserve the right to use it in anonymized form to improve our services."
    },
    liability: {
      title: "Limitation of Liability",
      content: "TheoCheck is provided 'as is' without warranty of any kind. We do not guarantee the accuracy, reliability, or effectiveness of the analyses produced by our service."
    },
    privacy: {
      title: "Privacy",
      content: "Your privacy is important to us. Our Privacy Policy explains how we collect, use, and protect your personal information."
    },
    changes: {
      title: "Changes to Terms",
      content: "We reserve the right to modify these terms at any time. Your continued use of TheoCheck after such changes constitutes your acceptance of the new terms."
    },
    contact: {
      title: "Contact",
      content: "If you have any questions regarding these terms, please contact us through our contact form."
    },
    lastUpdated: "Last updated: {{date}}"
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      fr: { translation: fr },
      en: { translation: en }
    },
    fallbackLng: 'fr',
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;