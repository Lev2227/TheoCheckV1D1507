// ====================================================================
// ENHANCED ANALYSIS SERVICE
// ====================================================================
// This service uses the rich data from hybrid analysis to provide
// more relevant and personalized suggestions and detailed analysis.
// ====================================================================

import OpenAI from "openai";
import { SermonAnalysis } from "@shared/schema";
import {
  ENHANCED_CUSTOM_SUGGESTIONS_PROMPT_FR,
  ENHANCED_CUSTOM_SUGGESTIONS_PROMPT_EN,
  ENHANCED_DETAILED_ANALYSIS_PROMPT_FR,
  ENHANCED_DETAILED_ANALYSIS_PROMPT_EN,
  BIBLICAL_ACCURACY_DETAILED_PROMPT_FR,
  BIBLICAL_ACCURACY_DETAILED_PROMPT_EN,
} from "./enhanced-analysis-prompts";

export class EnhancedAnalysisService {
  private openai: OpenAI;

  constructor(apiKey: string) {
    this.openai = new OpenAI({ apiKey });
  }

  /**
   * Utility method to safely parse JSON responses from OpenAI
   */
  private safeJsonParse<T>(content: string, fallback: T): T {
    if (!content) {
      console.error('Empty response from OpenAI');
      return fallback;
    }

    try {
      return JSON.parse(content) as T;
    } catch (error) {
      console.error('JSON parsing error in enhanced analysis:', error);
      console.error('Raw content:', content);
      
      // Try to extract JSON from the response if it's wrapped in text
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          return JSON.parse(jsonMatch[0]) as T;
        } catch (secondError) {
          console.error('Second JSON parsing attempt failed:', secondError);
        }
      }
      
      console.error('Using fallback data due to JSON parsing failure');
      return fallback;
    }
  }

  /**
   * Generate enhanced custom suggestions using hybrid analysis results
   */
  async generateEnhancedCustomSuggestions(
    sermonContent: string,
    hybridAnalysis: SermonAnalysis,
    language: 'fr' | 'en' = 'fr'
  ): Promise<string> {
    console.log("Generating enhanced custom suggestions using hybrid analysis data");

    // Prepare detailed analysis context
    const analysisContext = this.prepareAnalysisContext(sermonContent, hybridAnalysis);
    
    const prompt = language === 'fr' 
      ? ENHANCED_CUSTOM_SUGGESTIONS_PROMPT_FR 
      : ENHANCED_CUSTOM_SUGGESTIONS_PROMPT_EN;

    const enhancedPrompt = `${prompt}

DONNÉES DE L'ANALYSE HYBRIDE :
${analysisContext}

CONTENU DU SERMON À ANALYSER :
${sermonContent}

Génère maintenant 3-5 suggestions d'amélioration hyper-personnalisées basées sur ces données spécifiques.`;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: enhancedPrompt },
        { role: "user", content: "Génère les suggestions personnalisées basées sur l'analyse hybride fournie." }
      ],
      max_tokens: 2000,
      temperature: 0.7
    });

    return response.choices[0].message.content || "";
  }

  /**
   * Generate enhanced detailed analysis using hybrid analysis results
   */
  async generateEnhancedDetailedAnalysis(
    sermonContent: string,
    hybridAnalysis: SermonAnalysis,
    language: 'fr' | 'en' = 'fr'
  ): Promise<string> {
    console.log("Generating enhanced detailed analysis using hybrid analysis data");

    // Prepare detailed analysis context
    const analysisContext = this.prepareAnalysisContext(sermonContent, hybridAnalysis);
    
    const prompt = language === 'fr' 
      ? ENHANCED_DETAILED_ANALYSIS_PROMPT_FR 
      : ENHANCED_DETAILED_ANALYSIS_PROMPT_EN;

    const enhancedPrompt = `${prompt}

DONNÉES DE L'ANALYSE HYBRIDE :
${analysisContext}

CONTENU DU SERMON À ANALYSER :
${sermonContent}

Génère maintenant une analyse détaillée HTML interactive basée sur ces données spécifiques.`;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: enhancedPrompt },
        { role: "user", content: "Génère l'analyse détaillée HTML basée sur l'analyse hybride fournie." }
      ],
      max_tokens: 4000,
      temperature: 0.6
    });

    return response.choices[0].message.content || "";
  }

  /**
   * Generate biblical accuracy detailed feedback
   */
  async generateBiblicalAccuracyFeedback(
    sermonContent: string,
    hybridAnalysis: SermonAnalysis,
    language: 'fr' | 'en' = 'fr'
  ): Promise<string> {
    console.log("Generating biblical accuracy detailed feedback");

    const prompt = language === 'fr' 
      ? BIBLICAL_ACCURACY_DETAILED_PROMPT_FR 
      : BIBLICAL_ACCURACY_DETAILED_PROMPT_EN;

    const biblicalData = {
      score: hybridAnalysis.scores.fideliteBiblique,
      theologicalTradition: hybridAnalysis.theologicalTradition,
      keyScriptures: hybridAnalysis.keyScriptures,
      strengths: hybridAnalysis.strengths.filter(s => s.toLowerCase().includes('biblique') || s.toLowerCase().includes('biblical')),
      improvements: hybridAnalysis.improvements.filter(s => s.toLowerCase().includes('biblique') || s.toLowerCase().includes('biblical'))
    };

    const enhancedPrompt = `${prompt}

DONNÉES BIBLIQUES DE L'ANALYSE :
Score de fidélité biblique : ${biblicalData.score}/10
Tradition théologique identifiée : ${biblicalData.theologicalTradition}
Références bibliques clés : ${biblicalData.keyScriptures.join(', ')}
Forces bibliques identifiées : ${biblicalData.strengths.join('; ')}
Améliorations bibliques suggérées : ${biblicalData.improvements.join('; ')}

CONTENU DU SERMON :
${sermonContent}`;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: enhancedPrompt },
        { role: "user", content: "Génère l'analyse de fidélité biblique détaillée." }
      ],
      max_tokens: 2000,
      temperature: 0.5
    });

    return response.choices[0].message.content || "";
  }

  /**
   * Prepare comprehensive analysis context from hybrid results
   */
  private prepareAnalysisContext(sermonContent: string, hybridAnalysis: SermonAnalysis): string {
    return `
=== RÉSULTATS DE L'ANALYSE HYBRIDE ===

SCORES GLOBAUX :
- Fidélité Biblique : ${hybridAnalysis.scores.fideliteBiblique}/10
- Structure : ${hybridAnalysis.scores.structure}/10
- Application Pratique : ${hybridAnalysis.scores.applicationPratique}/10
- Authenticité : ${hybridAnalysis.scores.authenticite}/10
- Interactivité : ${hybridAnalysis.scores.interactivite}/10
- Score Global : ${hybridAnalysis.overallScore}/10

FORCES IDENTIFIÉES :
${hybridAnalysis.strengths.map((strength, i) => `${i + 1}. ${strength}`).join('\n')}

AMÉLIORATIONS SUGGÉRÉES :
${hybridAnalysis.improvements.map((improvement, i) => `${i + 1}. ${improvement}`).join('\n')}

ANALYSE THÉOLOGIQUE :
- Tradition : ${hybridAnalysis.theologicalTradition}
- Thèmes principaux : ${hybridAnalysis.topics.join(', ')}

RÉFÉRENCES BIBLIQUES CLÉS :
${hybridAnalysis.keyScriptures.join('\n')}

POINTS D'APPLICATION PRATIQUE :
${hybridAnalysis.applicationPoints.join('\n')}

ILLUSTRATIONS UTILISÉES :
${hybridAnalysis.illustrationsUsed.join('\n')}

ENGAGEMENT DE L'AUDIENCE :
- Émotionnel : ${hybridAnalysis.audienceEngagement.emotional}/10
- Intellectuel : ${hybridAnalysis.audienceEngagement.intellectual}/10
- Pratique : ${hybridAnalysis.audienceEngagement.practical}/10

TON ÉMOTIONNEL :
- Joie : ${hybridAnalysis.emotionalTone.joy}/10
- Espoir : ${hybridAnalysis.emotionalTone.hope}/10
- Conviction : ${hybridAnalysis.emotionalTone.conviction}/10
- Compassion : ${hybridAnalysis.emotionalTone.compassion}/10
- Urgence : ${hybridAnalysis.emotionalTone.urgency}/10
- Révérence : ${hybridAnalysis.emotionalTone.reverence}/10

RÉSUMÉ DE L'ANALYSE :
${hybridAnalysis.summary}

=== FIN DES DONNÉES D'ANALYSE ===
`;
  }

  /**
   * Identify weakest areas for targeted suggestions
   */
  private identifyWeakestAreas(hybridAnalysis: SermonAnalysis): string[] {
    const scores = hybridAnalysis.scores;
    const weakAreas = [];

    if (scores.fideliteBiblique < 7) weakAreas.push('Fidélité Biblique');
    if (scores.structure < 7) weakAreas.push('Structure');
    if (scores.applicationPratique < 7) weakAreas.push('Application Pratique');
    if (scores.authenticite < 7) weakAreas.push('Authenticité');
    if (scores.interactivite < 7) weakAreas.push('Interactivité');

    return weakAreas;
  }

  /**
   * Identify strongest areas to maintain and build upon
   */
  private identifyStrongestAreas(hybridAnalysis: SermonAnalysis): string[] {
    const scores = hybridAnalysis.scores;
    const strongAreas = [];

    if (scores.fideliteBiblique >= 8) strongAreas.push('Fidélité Biblique');
    if (scores.structure >= 8) strongAreas.push('Structure');
    if (scores.applicationPratique >= 8) strongAreas.push('Application Pratique');
    if (scores.authenticite >= 8) strongAreas.push('Authenticité');
    if (scores.interactivite >= 8) strongAreas.push('Interactivité');

    return strongAreas;
  }
}