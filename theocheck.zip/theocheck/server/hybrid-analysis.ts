import OpenAI from "openai";
import { type SermonAnalysis } from "@shared/schema";
import {
  SermonStructure,
  PartialAnalysis,
  BiblicalAccuracyAnalysis,
  STRUCTURE_SEQUENCING_PROMPT_FR,
  STRUCTURE_SEQUENCING_PROMPT_EN,
  INTRODUCTION_ANALYSIS_PROMPT_FR,
  INTRODUCTION_ANALYSIS_PROMPT_EN,
  MAIN_PART_ANALYSIS_PROMPT_FR,
  MAIN_PART_ANALYSIS_PROMPT_EN,
  CONCLUSION_ANALYSIS_PROMPT_FR,
  CONCLUSION_ANALYSIS_PROMPT_EN,
  BIBLICAL_ACCURACY_PROMPT_FR,
  BIBLICAL_ACCURACY_PROMPT_EN,
  FINAL_SYNTHESIS_PROMPT_FR,
  FINAL_SYNTHESIS_PROMPT_EN,
} from "./analysis-prompts";

export class HybridAnalysisService {
  private openai: OpenAI;

  constructor(apiKey: string) {
    this.openai = new OpenAI({ apiKey });
  }

  /**
   * Utility method to safely parse JSON responses from OpenAI
   */
  private safeJsonParse<T>(content: string, fallback: T): T {
    if (!content) {
      console.error('Empty response from OpenAI');
      return fallback;
    }

    try {
      return JSON.parse(content) as T;
    } catch (error) {
      console.error('JSON parsing error:', error);
      console.error('Raw content:', content);
      
      // Try to extract JSON from the response if it's wrapped in text
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          return JSON.parse(jsonMatch[0]) as T;
        } catch (secondError) {
          console.error('Second JSON parsing attempt failed:', secondError);
        }
      }
      
      console.error('Using fallback data due to JSON parsing failure');
      return fallback;
    }
  }

  /**
   * Main method that orchestrates the entire hybrid analysis process
   */
  async analyzeSermon(content: string, language: 'fr' | 'en' = 'fr'): Promise<SermonAnalysis> {
    try {
      console.log(`Starting hybrid analysis for sermon in language: ${language}`);
      
      // Step 1: Analyze structure
      console.log('Step 1: Analyzing sermon structure...');
      const structure = await this.analyzeStructure(content, language);
      console.log('Structure analysis completed:', { 
        introductionLength: structure.introduction.length, 
        mainPartsCount: structure.mainParts.length,
        conclusionLength: structure.conclusion.length
      });

      // Step 2: Analyze each section in parallel
      console.log('Step 2: Starting parallel analysis of sermon sections...');
      const introductionAnalysis = this.analyzeIntroduction(structure.introduction, language);
      const mainPartsAnalyses = structure.mainParts.map((part, index) => 
        this.analyzeMainPart(part, language, index)
      );
      const conclusionAnalysis = this.analyzeConclusion(structure.conclusion, language);

      // Step 3: Biblical accuracy analysis
      console.log('Step 3: Starting biblical accuracy analysis...');
      const biblicalAccuracyAnalysis = this.analyzeBiblicalAccuracy(content, language);

      // Wait for all parallel analyses to complete
      const [introAnalysis, ...mainAnalyses] = await Promise.all([
        introductionAnalysis,
        ...mainPartsAnalyses
      ]);
      const conclusionAnalysisFinal = await conclusionAnalysis;
      const biblicalAccuracy = await biblicalAccuracyAnalysis;

      console.log('All parallel analyses completed');

      // Step 4: Final synthesis
      console.log('Step 4: Synthesizing final analysis...');
      const finalAnalysis = await this.synthesizeFinalAnalysis(
        structure,
        introAnalysis,
        mainAnalyses,
        conclusionAnalysisFinal,
        biblicalAccuracy,
        language
      );

      console.log('Hybrid analysis completed successfully');
      return finalAnalysis;
    } catch (error) {
      console.error('Error in hybrid analysis:', error);
      throw error;
    }
  }

  /**
   * AGENT 1: Structure Sequencing
   */
  private async analyzeStructure(content: string, language: 'fr' | 'en'): Promise<SermonStructure> {
    const prompt = language === 'fr' 
      ? STRUCTURE_SEQUENCING_PROMPT_FR 
      : STRUCTURE_SEQUENCING_PROMPT_EN;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        { role: "user", content: content }
      ],
      response_format: { type: "json_object" },
      max_tokens: 4000,
      temperature: 0.3
    });

    const responseContent = response.choices[0].message.content;
    const fallback: SermonStructure = {
      introduction: "Introduction non identifiée",
      mainParts: ["Partie principale non segmentée"],
      conclusion: "Conclusion non identifiée"
    };

    return this.safeJsonParse(responseContent || '', fallback);
  }

  /**
   * AGENT 2: Introduction Analysis
   */
  private async analyzeIntroduction(introduction: string, language: 'fr' | 'en'): Promise<PartialAnalysis> {
    const prompt = language === 'fr' 
      ? INTRODUCTION_ANALYSIS_PROMPT_FR 
      : INTRODUCTION_ANALYSIS_PROMPT_EN;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        { role: "user", content: introduction }
      ],
      response_format: { type: "json_object" },
      max_tokens: 3000,
      temperature: 0.5
    });

    const responseContent = response.choices[0].message.content;
    const fallback: PartialAnalysis = {
      scores: { fideliteBiblique: 5, structure: 5, applicationPratique: 5, authenticite: 5, interactivite: 5 },
      strengths: ["Analyse non disponible"],
      improvements: ["Analyse non disponible"],
      summary: "Analyse non disponible",
      topics: ["Non identifié"],
      keyScriptures: ["Non identifié"],
      applicationPoints: ["Non identifié"],
      illustrationsUsed: ["Non identifié"],
      audienceEngagement: { emotional: 5, intellectual: 5, practical: 5 },
      emotionalTone: { joy: 5, hope: 5, conviction: 5, compassion: 5, urgency: 5, reverence: 5 }
    };

    return this.safeJsonParse(responseContent || '', fallback);
  }

  /**
   * AGENT 3: Main Part Analysis
   */
  private async analyzeMainPart(
    mainPart: string, 
    language: 'fr' | 'en', 
    partIndex: number
  ): Promise<PartialAnalysis> {
    const prompt = language === 'fr' 
      ? MAIN_PART_ANALYSIS_PROMPT_FR 
      : MAIN_PART_ANALYSIS_PROMPT_EN;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        { role: "user", content: `Partie ${partIndex + 1}:\n\n${mainPart}` }
      ],
      response_format: { type: "json_object" },
      max_tokens: 3000,
      temperature: 0.5
    });

    const responseContent = response.choices[0].message.content;
    const fallback: PartialAnalysis = {
      scores: { fideliteBiblique: 5, structure: 5, applicationPratique: 5, authenticite: 5, interactivite: 5 },
      strengths: ["Analyse non disponible"],
      improvements: ["Analyse non disponible"],
      summary: "Analyse non disponible",
      topics: ["Non identifié"],
      keyScriptures: ["Non identifié"],
      applicationPoints: ["Non identifié"],
      illustrationsUsed: ["Non identifié"],
      audienceEngagement: { emotional: 5, intellectual: 5, practical: 5 },
      emotionalTone: { joy: 5, hope: 5, conviction: 5, compassion: 5, urgency: 5, reverence: 5 }
    };

    return this.safeJsonParse(responseContent || '', fallback);
  }

  /**
   * AGENT 4: Conclusion Analysis
   */
  private async analyzeConclusion(conclusion: string, language: 'fr' | 'en'): Promise<PartialAnalysis> {
    const prompt = language === 'fr' 
      ? CONCLUSION_ANALYSIS_PROMPT_FR 
      : CONCLUSION_ANALYSIS_PROMPT_EN;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        { role: "user", content: conclusion }
      ],
      response_format: { type: "json_object" },
      max_tokens: 3000,
      temperature: 0.5
    });

    const responseContent = response.choices[0].message.content;
    const fallback: PartialAnalysis = {
      scores: { fideliteBiblique: 5, structure: 5, applicationPratique: 5, authenticite: 5, interactivite: 5 },
      strengths: ["Analyse non disponible"],
      improvements: ["Analyse non disponible"],
      summary: "Analyse non disponible",
      topics: ["Non identifié"],
      keyScriptures: ["Non identifié"],
      applicationPoints: ["Non identifié"],
      illustrationsUsed: ["Non identifié"],
      audienceEngagement: { emotional: 5, intellectual: 5, practical: 5 },
      emotionalTone: { joy: 5, hope: 5, conviction: 5, compassion: 5, urgency: 5, reverence: 5 }
    };

    return this.safeJsonParse(responseContent || '', fallback);
  }

  /**
   * AGENT 5: Biblical Accuracy Specialist
   */
  private async analyzeBiblicalAccuracy(
    content: string, 
    language: 'fr' | 'en'
  ): Promise<BiblicalAccuracyAnalysis> {
    const prompt = language === 'fr' 
      ? BIBLICAL_ACCURACY_PROMPT_FR 
      : BIBLICAL_ACCURACY_PROMPT_EN;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        { role: "user", content: content }
      ],
      response_format: { type: "json_object" },
      max_tokens: 4000,
      temperature: 0.3
    });

    const responseContent = response.choices[0].message.content;
    const fallback: BiblicalAccuracyAnalysis = {
      fideliteBiblique: 5,
      theologicalTradition: "Non identifiée",
      keyScriptures: ["Non identifié"],
      biblicalAccuracyIssues: ["Analyse non disponible"],
      contextualAccuracy: ["Analyse non disponible"],
      doctrineSoundness: 5
    };

    return this.safeJsonParse(responseContent || '', fallback);
  }

  /**
   * AGENT 6: Final Synthesis
   */
  private async synthesizeFinalAnalysis(
    structure: SermonStructure,
    introAnalysis: PartialAnalysis,
    mainAnalyses: PartialAnalysis[],
    conclusionAnalysis: PartialAnalysis,
    biblicalAccuracy: BiblicalAccuracyAnalysis,
    language: 'fr' | 'en'
  ): Promise<SermonAnalysis> {
    const prompt = language === 'fr' 
      ? FINAL_SYNTHESIS_PROMPT_FR 
      : FINAL_SYNTHESIS_PROMPT_EN;

    const analysisData = {
      structure,
      introAnalysis,
      mainAnalyses,
      conclusionAnalysis,
      biblicalAccuracy
    };

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        { role: "user", content: JSON.stringify(analysisData) }
      ],
      response_format: { type: "json_object" },
      max_tokens: 5000,
      temperature: 0.4
    });

    const responseContent = response.choices[0].message.content;
    const fallback: SermonAnalysis = {
      scores: { fideliteBiblique: 5, structure: 5, applicationPratique: 5, authenticite: 5, interactivite: 5 },
      overallScore: 5,
      strengths: ["Analyse non disponible"],
      improvements: ["Analyse non disponible"],
      summary: "Analyse non disponible en raison d'une erreur technique",
      topics: ["Non identifié"],
      theologicalTradition: "Non identifiée",
      keyScriptures: ["Non identifié"],
      applicationPoints: ["Non identifié"],
      illustrationsUsed: ["Non identifié"],
      audienceEngagement: { emotional: 5, intellectual: 5, practical: 5 },
      emotionalTone: { joy: 5, hope: 5, conviction: 5, compassion: 5, urgency: 5, reverence: 5 }
    };

    return this.safeJsonParse(responseContent || '', fallback);
  }

  /**
   * Utility method to calculate weighted scores from multiple analyses
   */
  private calculateWeightedScores(analyses: PartialAnalysis[]): any {
    const weights = {
      introduction: 0.2,
      mainParts: 0.6,
      conclusion: 0.2
    };

    const totalScores = {
      fideliteBiblique: 0,
      structure: 0,
      applicationPratique: 0,
      authenticite: 0,
      interactivite: 0
    };

    // Calculate weighted average
    analyses.forEach((analysis, index) => {
      const weight = index === 0 ? weights.introduction : 
                    index === analyses.length - 1 ? weights.conclusion : 
                    weights.mainParts / (analyses.length - 2);
      
      Object.keys(totalScores).forEach(key => {
        totalScores[key as keyof typeof totalScores] += analysis.scores[key as keyof typeof analysis.scores] * weight;
      });
    });

    return totalScores;
  }
}