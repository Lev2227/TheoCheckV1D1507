import { db } from "./db";
import { 
  userEvents, 
  donations, 
  sharingEvents, 
  analysisMetrics, 
  referralTracking,
  type InsertUserEvent,
  type InsertDonation,
  type InsertSharingEvent,
  type InsertAnalysisMetric,
  type InsertReferralTracking
} from "@shared/schema";
import { eq, sql, desc, and, gte, lte } from "drizzle-orm";

export class AnalyticsService {
  // Track user events (general)
  async trackEvent(event: InsertUserEvent) {
    try {
      await db.insert(userEvents).values(event);
    } catch (error) {
      console.error("Failed to track event:", error);
    }
  }

  // Track donations
  async trackDonation(donation: InsertDonation) {
    try {
      const [result] = await db.insert(donations).values(donation).returning();
      return result;
    } catch (error) {
      console.error("Failed to track donation:", error);
      throw error;
    }
  }

  // Track sharing events
  async trackSharing(share: InsertSharingEvent) {
    try {
      await db.insert(sharingEvents).values(share);
    } catch (error) {
      console.error("Failed to track sharing:", error);
    }
  }

  // Track analysis metrics
  async trackAnalysis(analysis: InsertAnalysisMetric) {
    try {
      await db.insert(analysisMetrics).values(analysis);
    } catch (error) {
      console.error("Failed to track analysis:", error);
    }
  }

  // Track referrals
  async trackReferral(referral: InsertReferralTracking) {
    try {
      await db.insert(referralTracking).values(referral);
    } catch (error) {
      console.error("Failed to track referral:", error);
    }
  }

  // Get KPI Dashboard Data
  async getKPIDashboard(startDate?: Date, endDate?: Date) {
    const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
    const end = endDate || new Date();

    try {
      // Total sermon analyses
      const totalAnalyses = await db
        .select({ count: sql<number>`count(*)` })
        .from(analysisMetrics)
        .where(and(
          gte(analysisMetrics.createdAt, start),
          lte(analysisMetrics.createdAt, end)
        ));

      // Total donations and revenue
      const donationStats = await db
        .select({
          totalDonations: sql<number>`count(*)`,
          totalRevenue: sql<number>`sum(${donations.amount})`,
          avgDonation: sql<number>`avg(${donations.amount})`
        })
        .from(donations)
        .where(and(
          eq(donations.status, 'completed'),
          gte(donations.createdAt, start),
          lte(donations.createdAt, end)
        ));

      // Sharing metrics
      const sharingStats = await db
        .select({
          totalShares: sql<number>`count(*)`,
          engagementRate: sql<number>`avg(case when ${sharingEvents.recipientEngaged} then 1 else 0 end) * 100`
        })
        .from(sharingEvents)
        .where(and(
          gte(sharingEvents.createdAt, start),
          lte(sharingEvents.createdAt, end)
        ));

      // Popular sharing methods
      const shareMethodStats = await db
        .select({
          method: sharingEvents.shareMethod,
          count: sql<number>`count(*)`
        })
        .from(sharingEvents)
        .where(and(
          gte(sharingEvents.createdAt, start),
          lte(sharingEvents.createdAt, end)
        ))
        .groupBy(sharingEvents.shareMethod)
        .orderBy(desc(sql`count(*)`));

      // User acquisition sources
      const acquisitionSources = await db
        .select({
          source: userEvents.referrer,
          signups: sql<number>`count(*)`
        })
        .from(userEvents)
        .where(and(
          eq(userEvents.eventType, 'signup'),
          gte(userEvents.timestamp, start),
          lte(userEvents.timestamp, end)
        ))
        .groupBy(userEvents.referrer)
        .orderBy(desc(sql`count(*)`));

      // Analysis cost tracking
      const costStats = await db
        .select({
          totalCost: sql<number>`sum(${analysisMetrics.costEstimate})`,
          avgTokensPerAnalysis: sql<number>`avg(${analysisMetrics.tokensUsed})`
        })
        .from(analysisMetrics)
        .where(and(
          gte(analysisMetrics.createdAt, start),
          lte(analysisMetrics.createdAt, end)
        ));

      return {
        period: { start, end },
        analyses: {
          total: totalAnalyses[0]?.count || 0,
          avgCost: costStats[0]?.totalCost || 0,
          avgTokens: costStats[0]?.avgTokensPerAnalysis || 0
        },
        revenue: {
          totalDonations: donationStats[0]?.totalDonations || 0,
          totalRevenue: donationStats[0]?.totalRevenue || 0,
          avgDonation: donationStats[0]?.avgDonation || 0
        },
        sharing: {
          totalShares: sharingStats[0]?.totalShares || 0,
          engagementRate: sharingStats[0]?.engagementRate || 0,
          methodBreakdown: shareMethodStats
        },
        acquisition: {
          sources: acquisitionSources
        }
      };
    } catch (error) {
      console.error("Failed to get KPI dashboard:", error);
      throw error;
    }
  }

  // Get user engagement funnel
  async getUserEngagementFunnel(startDate?: Date, endDate?: Date) {
    const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate || new Date();

    try {
      // Signups
      const signups = await db
        .select({ count: sql<number>`count(distinct ${userEvents.userId})` })
        .from(userEvents)
        .where(and(
          eq(userEvents.eventType, 'signup'),
          gte(userEvents.timestamp, start),
          lte(userEvents.timestamp, end)
        ));

      // First analysis
      const firstAnalysis = await db
        .select({ count: sql<number>`count(distinct ${analysisMetrics.userId})` })
        .from(analysisMetrics)
        .where(and(
          gte(analysisMetrics.createdAt, start),
          lte(analysisMetrics.createdAt, end)
        ));

      // Users who shared
      const shared = await db
        .select({ count: sql<number>`count(distinct ${sharingEvents.userId})` })
        .from(sharingEvents)
        .where(and(
          gte(sharingEvents.createdAt, start),
          lte(sharingEvents.createdAt, end)
        ));

      // Users who donated
      const donated = await db
        .select({ count: sql<number>`count(distinct ${donations.userId})` })
        .from(donations)
        .where(and(
          eq(donations.status, 'completed'),
          gte(donations.createdAt, start),
          lte(donations.createdAt, end)
        ));

      const signupCount = signups[0]?.count || 0;
      
      return {
        signups: signupCount,
        firstAnalysis: firstAnalysis[0]?.count || 0,
        shared: shared[0]?.count || 0,
        donated: donated[0]?.count || 0,
        conversionRates: {
          signupToAnalysis: signupCount > 0 ? ((firstAnalysis[0]?.count || 0) / signupCount * 100) : 0,
          analysisToShare: signupCount > 0 ? ((shared[0]?.count || 0) / signupCount * 100) : 0,
          analysisToDonation: signupCount > 0 ? ((donated[0]?.count || 0) / signupCount * 100) : 0
        }
      };
    } catch (error) {
      console.error("Failed to get engagement funnel:", error);
      throw error;
    }
  }
}

export const analytics = new AnalyticsService();