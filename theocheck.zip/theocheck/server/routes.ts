import type { Express, Request, Response } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertSermonSchema, type SermonAnalysis } from "@shared/schema";
import OpenAI from "openai";
import admin from "firebase-admin";
import PDFDocument from "pdfkit";
import { getFirestore } from "firebase-admin/firestore";
import path from "path";
import Stripe from "stripe";
import { analytics } from "./analytics";
import { HybridAnalysisService } from "./hybrid-analysis";
import { EnhancedAnalysisService } from "./enhanced-analysis-service";

// Simple Firebase Admin initialization
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n')
    })
  });
}

const db = getFirestore();


// Add custom properties to Express.Request
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
      };
    }
  }
}

// Firebase auth middleware
const authenticateUser = async (req: Request, res: any, next: any) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const token = authHeader.split('Bearer ')[1];
    const decodedToken = await admin.auth().verifyIdToken(token);
    req.user = { id: decodedToken.uid };
    next();
  } catch (error) {
    console.error("Auth error:", error);
    res.status(401).json({ message: "Unauthorized" });
  }
};

// Initialisation de Stripe avec la clé API secrète
if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Missing STRIPE_SECRET_KEY environment variable');
}

// Initialiser Stripe seulement si la clé est disponible
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2022-11-15' as Stripe.LatestApiVersion, // Version compatible
    })
  : null;

// KPI Tracking Functions for Firebase
async function trackKPIEvent(eventType: string, data: any) {
  try {
    await db.collection('kpi_events').add({
      eventType,
      data,
      timestamp: new Date(),
      ...data
    });
  } catch (error) {
    console.error('Failed to track KPI event:', error);
  }
}

async function trackDonation(amount: number, userId?: string, paymentIntentId?: string, status: string = 'pending') {
  try {
    await db.collection('donations').add({
      userId: userId || 'anonymous',
      amount,
      paymentIntentId,
      status,
      timestamp: new Date(),
      currency: 'EUR'
    });
  } catch (error) {
    console.error('Failed to track donation:', error);
  }
}

async function trackSharing(userId: string, shareMethod: string, sermonId?: number) {
  try {
    await db.collection('sharing_events').add({
      userId: userId || 'anonymous',
      shareMethod,
      sermonId: sermonId || null,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('Failed to track sharing:', error);
  }
}

async function trackAnalysis(userId: string, sermonId: number, modelUsed: string = 'gpt-4o') {
  try {
    await db.collection('analysis_metrics').add({
      userId: userId || 'anonymous',
      sermonId,
      modelUsed,
      timestamp: new Date(),
      analysisStartTime: new Date()
    });
  } catch (error) {
    console.error('Failed to track analysis:', error);
  }
}

async function trackSermonCount(userId: string, sermonId: number, title: string) {
  try {
    await db.collection('sermoncount').add({
      userId: userId || 'anonymous',
      sermonId,
      title: title || 'Untitled Sermon',
      timestamp: new Date(),
      status: 'analyzed'
    });
    console.log('Sermon count tracked successfully for sermon:', sermonId);
  } catch (error) {
    console.error('Failed to track sermon count:', error);
  }
}

export async function registerRoutes(app: Express) {
  
  // Route pour créer une intention de paiement Stripe
  app.post("/api/create-payment-intent", async (req: Request, res: Response) => {
    try {
      if (!stripe) {
        return res.status(500).json({ 
          error: 'Stripe configuration is missing. Please contact the administrator.' 
        });
      }

      const { amount, description = 'TheoCheck donation' } = req.body;
      
      // Validation du montant
      if (!amount || typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ error: 'Invalid amount' });
      }

      // Création de l'intention de paiement
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Conversion en centimes
        currency: 'eur',
        description,
        metadata: {
          integration_check: 'accept_a_payment',
        }
      });

      // Track donation attempt in Firebase
      await trackDonation(amount, req.user?.id || 'anonymous', paymentIntent.id, 'pending');

      res.json({
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error: any) {
      console.error('Stripe payment intent error:', error);
      res.status(500).json({ 
        error: 'Failed to create payment intent', 
        details: process.env.NODE_ENV === 'development' ? error.message : undefined 
      });
    }
  });

  // Route pour vérifier un paiement
  app.get("/api/verify-payment/:id", async (req: Request, res: Response) => {
    try {
      if (!stripe) {
        return res.status(500).json({ error: 'Stripe configuration is missing' });
      }

      const { id } = req.params;
      
      // Récupération des détails du paiement
      const paymentIntent = await stripe.paymentIntents.retrieve(id);
      
      res.json({
        status: paymentIntent.status,
        amount: paymentIntent.amount / 100, // Conversion de centimes en euros
        currency: paymentIntent.currency,
      });
    } catch (error: any) {
      console.error('Payment verification error:', error);
      res.status(500).json({ error: 'Failed to verify payment' });
    }
  });
  app.get("/api/sermons/:id", authenticateUser, async (req, res) => {
    try {
      const sermonId = parseInt(req.params.id);
      const sermon = await storage.getSermon(sermonId);

      if (!sermon) {
        return res.status(404).json({ message: "Sermon not found" });
      }

      if (sermon.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      res.json(sermon);
    } catch (error) {
      console.error("Error fetching sermon:", error);
      res.status(500).json({ message: "Failed to fetch sermon" });
    }
  });

  app.post("/api/analyze", authenticateUser, async (req, res) => {
    try {
      const sermonId = req.body.sermonId;
      const language = req.body.language || 'fr'; // Get language from request
      const sermon = await storage.getSermon(sermonId);

      if (!sermon) {
        return res.status(404).json({ message: "Sermon not found" });
      }

      if (sermon.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      console.log(`Starting hybrid analysis for sermon: ${sermonId} in language: ${language}`);
      
      // Track analysis start in Firebase
      await trackAnalysis(req.user!.id, sermonId, 'gpt-4o');
      
      if (!process.env.OPENAI_API_KEY) {
        throw new Error("OpenAI API key is not configured");
      }

      const hybridAnalysis = new HybridAnalysisService(process.env.OPENAI_API_KEY);
      const analysis = await hybridAnalysis.analyzeSermon(sermon.content, language);
      const updatedSermon = await storage.updateSermonAnalysis(sermonId, analysis);

      // Mettre à jour l'analyse dans Firebase Firestore
      try {
        console.log("Attempting to update sermon analysis in Firebase Firestore...");
        
        // Rechercher le document par appSermonId
        const sermonsRef = db.collection('sermons');
        const snapshot = await sermonsRef.where('appSermonId', '==', sermonId).get();
        
        if (!snapshot.empty) {
          // Mettre à jour le premier document trouvé (il ne devrait y en avoir qu'un)
          const docRef = snapshot.docs[0].ref;
          await docRef.update({
            analysis: analysis
          });
          console.log("Analysis updated in Firebase Firestore for sermon ID:", sermonId);
        } else {
          console.log("No matching sermon document found in Firebase Firestore with appSermonId:", sermonId);
          
          // Si aucun document n'existe, créer un nouveau document
          const docRef = await db.collection('sermons').add({
            title: sermon.title,
            content: sermon.content,
            bibleReference: sermon.bibleReference,
            userId: req.user!.id,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            appSermonId: sermonId,
            analysis: analysis
          });
          
          console.log("New sermon document created in Firebase Firestore with analysis, ID:", docRef.id);
        }
      } catch (firestoreError) {
        console.error("Error updating analysis in Firebase Firestore:", firestoreError);
        // On continue même si la mise à jour dans Firestore échoue
      }

      // Update user preferences based on the analysis
      const user = await storage.getUserByFirebaseId(req.user.id);
      if (user) {
        const preferences = user.preferences || {
          favoriteTopics: [],
          theologicalTradition: analysis.theologicalTradition,
          preferredStyle: "",
          lastViewedSermons: []
        };

        // Update preferences based on this sermon
        const uniqueTopics = new Set([...preferences.favoriteTopics, ...analysis.topics]);
        preferences.favoriteTopics = [];
        uniqueTopics.forEach(topic => preferences.favoriteTopics.push(topic));
        preferences.lastViewedSermons = [sermonId, ...preferences.lastViewedSermons].slice(0, 10);

        await storage.updateUserPreferences(user.id, preferences);
      }

      res.json(updatedSermon);
    } catch (error: any) {
      console.error("Analysis error:", error);
      let message = "Failed to analyze sermon";
      let status = 500;

      if (error.status === 429) {
        message = "429 You exceeded your current quota, please check your plan and billing details.";
        status = 429;
      } else if (error.status === 401) {
        message = "API authentication error. Please contact support.";
        status = 401;
      }

      res.status(status).json({
        message,
        details: error.message || "Unknown error"
      });
    }
  });

  app.get("/api/sermons", authenticateUser, async (req, res) => {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const sermons = await storage.getSermonsByUserId(userId);
    res.json(sermons);
  });

  app.post("/api/sermons", authenticateUser, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const parsed = insertSermonSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid sermon data" });
      }

      // 1. Créer le sermon dans le stockage interne
      const sermon = await storage.createSermon({
        ...parsed.data,
        userId,
        analysis: null,
        topics: [],
        theologicalTradition: null,
        bibleReference: parsed.data.bibleReference || null,
      });

      // 2. Enregistrer les données dans Firebase Firestore
      try {
        console.log("Attempting to save sermon to Firebase Firestore...");
        
        const docRef = await db.collection('sermons').add({
          title: parsed.data.title,
          content: parsed.data.content,
          bibleReference: parsed.data.bibleReference || null,
          userId: userId,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          appSermonId: sermon.id, // ID de l'application
          analysis: null // Sera mis à jour après l'analyse
        });
        
        console.log("Sermon saved to Firebase Firestore, document ID:", docRef.id);
      } catch (firestoreError) {
        console.error("Error saving sermon to Firebase Firestore:", firestoreError);
        // On continue même si l'enregistrement dans Firestore échoue
      }

      // 3. Immédiatement analyser le sermon avec le système hybride
      console.log("Starting hybrid sermon analysis for:", sermon.id);

      try {
        if (!process.env.OPENAI_API_KEY) {
          throw new Error("OpenAI API key is not configured");
        }

        const hybridAnalysis = new HybridAnalysisService(process.env.OPENAI_API_KEY);
        const analysis = await hybridAnalysis.analyzeSermon(sermon.content, 'fr');
        const updatedSermon = await storage.updateSermonAnalysis(sermon.id, analysis);
        
        // Track sermon count in dedicated Firebase collection
        await trackSermonCount(userId, sermon.id, sermon.title);
        
        // 4. Mettre à jour l'analyse dans Firebase Firestore
        try {
          // Rechercher le document par appSermonId
          const sermonsRef = db.collection('sermons');
          const snapshot = await sermonsRef.where('appSermonId', '==', sermon.id).get();
          
          if (!snapshot.empty) {
            // Mettre à jour le premier document trouvé (il ne devrait y en avoir qu'un)
            const docRef = snapshot.docs[0].ref;
            await docRef.update({
              analysis: analysis
            });
            console.log("Analysis updated in Firebase Firestore for sermon ID:", sermon.id);
          } else {
            console.log("No matching sermon document found in Firebase Firestore with appSermonId:", sermon.id);
          }
        } catch (firestoreUpdateError) {
          console.error("Error updating analysis in Firebase Firestore:", firestoreUpdateError);
          // On continue même si la mise à jour dans Firestore échoue
        }
        
        res.json(updatedSermon);
      } catch (error: any) {
        console.error("OpenAI API Error:", error);
        res.status(500).json({
          message: "Erreur lors de l'analyse du sermon",
          details: error.message
        });
      }
    } catch (error: any) {
      console.error("Error in /api/sermons:", error);
      res.status(500).json({
        message: "Une erreur est survenue",
        details: error.message
      });
    }
  });

  app.get("/api/sermons/recommendations", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUserByFirebaseId(req.user!.id);
      if (!user || !user.preferences) {
        return res.json([]);
      }

      const allSermons = await storage.getSermonsByUserId(req.user!.id);
      const recommendations = allSermons
        .filter(sermon => !user.preferences!.lastViewedSermons.includes(sermon.id))
        .map(sermon => ({
          sermon,
          score: calculateRecommendationScore(sermon, user.preferences!)
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 5)
        .map(r => r.sermon);

      res.json(recommendations);
    } catch (error) {
      console.error("Error getting recommendations:", error);
      res.status(500).json({ message: "Failed to get recommendations" });
    }
  });

  // KPI Tracking Endpoints
  app.post("/api/track/share", authenticateUser, async (req: Request, res: Response) => {
    try {
      const { shareMethod, sermonId } = req.body;
      await trackSharing(req.user!.id, shareMethod, sermonId);
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to track sharing:", error);
      res.status(500).json({ error: "Failed to track sharing event" });
    }
  });

  app.post("/api/track/donation-success", async (req: Request, res: Response) => {
    try {
      const { paymentIntentId, amount, userId } = req.body;
      await trackDonation(amount, userId, paymentIntentId, 'completed');
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to track donation success:", error);
      res.status(500).json({ error: "Failed to track donation" });
    }
  });

  app.post("/api/track/event", authenticateUser, async (req: Request, res: Response) => {
    try {
      const { eventType, data } = req.body;
      await trackKPIEvent(eventType, { ...data, userId: req.user!.id });
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to track event:", error);
      res.status(500).json({ error: "Failed to track event" });
    }
  });

  app.get("/api/kpi-dashboard", async (req: Request, res: Response) => {
    try {
      console.log('=== KPI Dashboard API Called ===');
      
      const [donationsSnapshot, sharingSnapshot, sermonCountSnapshot] = await Promise.all([
        db.collection('donations').get(),
        db.collection('sharing_events').get(), 
        db.collection('sermoncount').get()
      ]);

      let totalDonations = 0;
      let totalRevenue = 0;
      
      console.log(`Found ${donationsSnapshot.size} donation records`);
      donationsSnapshot.forEach((doc) => {
        const data = doc.data();
        if (data.status === 'completed' || data.status === 'pending') {
          totalDonations++;
          totalRevenue += parseFloat(data.amount) || 0;
        }
      });

      const totalShares = sharingSnapshot.size;
      
      console.log(`Reading from sermoncount collection: found ${sermonCountSnapshot.size} sermon analysis records`);
      
      // Use sermoncount collection if available, otherwise fall back to main sermons collection
      let totalAnalyses = sermonCountSnapshot.size;
      
      if (sermonCountSnapshot.size === 0) {
        console.log('Sermoncount collection is empty, reading from main sermons collection as fallback');
        try {
          const existingSermonsSnapshot = await db.collection('sermons').get();
          let count = 0;
          console.log(`Checking ${existingSermonsSnapshot.size} sermons for analysis data`);
          
          existingSermonsSnapshot.forEach((doc) => {
            const data = doc.data();
            if (data.analysis) {
              count++;
              console.log(`Found analyzed sermon: ${data.title?.substring(0, 30)}...`);
            }
          });
          totalAnalyses = count;
          console.log(`Found ${count} analyzed sermons in main collection`);
        } catch (error) {
          console.error('Error reading from sermons collection:', error);
        }
      }
      
      // Log sermon count data
      sermonCountSnapshot.forEach((doc) => {
        const data = doc.data();
        console.log(`Sermon analysis found:`, { 
          id: doc.id, 
          title: data.title?.substring(0, 50) + '...', 
          status: data.status,
          timestamp: data.timestamp
        });
      });

      // Calculate engagement rate based on available data
      const engagementRate = totalAnalyses > 0 
        ? Math.round((totalShares / totalAnalyses) * 100) 
        : 0;

      console.log(`KPI Summary: Donations=${totalDonations}, Revenue=${totalRevenue}, Shares=${totalShares}, Analyses=${totalAnalyses}, Engagement=${engagementRate}%`);

      const result = {
        totalDonations,
        totalRevenue,
        totalShares,
        totalAnalyses,
        engagementRate,
        recentEvents: []
      };
      
      console.log('=== Sending KPI data ===', result);
      res.json(result);

    } catch (error) {
      console.error('Error loading KPI dashboard:', error);
      res.status(500).json({ 
        totalDonations: 0,
        totalRevenue: 0,
        totalShares: 0,
        totalAnalyses: 0,
        recentEvents: []
      });
    }
  });
  
  // Endpoint pour obtenir des recommandations personnalisées basées sur l'analyse hybride
  app.post("/api/sermons/:id/get-custom-suggestions", authenticateUser, async (req, res) => {
    try {
      const sermonId = parseInt(req.params.id);
      const { language = 'fr' } = req.body;
      const sermon = await storage.getSermon(sermonId);

      if (!sermon) {
        return res.status(404).json({ message: "Sermon not found" });
      }

      if (sermon.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      if (!sermon.analysis) {
        return res.status(400).json({ message: "Ce sermon n'a pas encore été analysé" });
      }

      if (!process.env.OPENAI_API_KEY) {
        throw new Error("OpenAI API key is not configured");
      }
      
      // Utiliser le service amélioré qui exploite l'analyse hybride
      const enhancedService = new EnhancedAnalysisService(process.env.OPENAI_API_KEY);
      
      console.log("Génération de suggestions personnalisées basées sur l'analyse hybride");
      const customSuggestions = await enhancedService.generateEnhancedCustomSuggestions(
        sermon.content,
        sermon.analysis,
        language
      );
      
      res.json({ 
        success: true,
        customSuggestions,
        sermonId,
        usedHybridAnalysis: true
      });
      
    } catch (error) {
      console.error("Error generating enhanced custom suggestions:", error);
      res.status(500).json({ 
        success: false,
        message: "Erreur lors de la génération des suggestions personnalisées améliorées",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Endpoint pour l'analyse détaillée basée sur l'analyse hybride
  app.post("/api/sermons/:id/detailed-analysis", authenticateUser, async (req, res) => {
    try {
      const sermonId = parseInt(req.params.id);
      const { language = 'fr' } = req.body;
      const sermon = await storage.getSermon(sermonId);

      if (!sermon) {
        return res.status(404).json({ message: "Sermon not found" });
      }

      if (sermon.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      if (!sermon.analysis) {
        return res.status(400).json({ message: "Ce sermon n'a pas encore été analysé" });
      }

      if (!process.env.OPENAI_API_KEY) {
        throw new Error("OpenAI API key is not configured");
      }
      
      // Utiliser le service amélioré qui exploite l'analyse hybride
      const enhancedService = new EnhancedAnalysisService(process.env.OPENAI_API_KEY);
      
      console.log("Génération d'analyse détaillée basée sur l'analyse hybride");
      const detailedAnalysis = await enhancedService.generateEnhancedDetailedAnalysis(
        sermon.content,
        sermon.analysis,
        language
      );
      
      res.json({ 
        success: true,
        detailedAnalysis,
        sermonId,
        usedHybridAnalysis: true
      });
      
    } catch (error) {
      console.error("Error generating enhanced detailed analysis:", error);
      res.status(500).json({ 
        success: false,
        message: "Erreur lors de la génération de l'analyse détaillée améliorée",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Contact form endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;

      if (!name || !email || !subject || !message) {
        return res.status(400).json({
          success: false,
          message: "All fields are required"
        });
      }

      console.log("Attempting to save contact form:", { name, email, subject });

      const docRef = await db.collection('contacts').add({
        name,
        email,
        subject,
        message,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        status: 'new'
      });

      console.log("Contact form saved successfully, ID:", docRef.id);

      res.json({
        success: true,
        message: "Message received successfully",
        id: docRef.id
      });
    } catch (error) {
      console.error("Error saving contact form:", error);
      res.status(500).json({
        success: false,
        message: "Failed to save contact form",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/sermons/:id/pdf", authenticateUser, async (req, res) => {
    try {
      const sermonId = parseInt(req.params.id);
      const sermon = await storage.getSermon(sermonId);

      if (!sermon) {
        return res.status(404).json({ message: "Sermon not found" });
      }

      if (sermon.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      // Create PDF with better styling
      const doc = new PDFDocument({
        margins: { top: 50, bottom: 50, left: 50, right: 50 },
        size: 'A4'
      });

      // Set response headers
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=analyse-sermon-${sermonId}.pdf`);

      // Pipe the PDF to the response
      doc.pipe(res);

      // Header
      doc.fontSize(24)
        .fillColor('#1a365d')
        .text('TheoCheck', { align: 'center' });

      doc.fontSize(16)
        .fillColor('#4a5568')
        .text('Rapport d\'Analyse de Sermon', { align: 'center' });

      doc.moveDown(2);

      // Title and date section
      doc.fontSize(20)
        .fillColor('#2d3748')
        .text(sermon.title);

      doc.fontSize(12)
        .fillColor('#718096')
        .text(`Date d'analyse: ${new Date().toLocaleDateString('fr-FR')}`)
        .moveDown();

      // Divider
      doc.moveTo(50, doc.y)
        .lineTo(545, doc.y)
        .stroke('#e2e8f0');

      const analysis = sermon.analysis;
      if (analysis) {
        // Overall score with visual emphasis
        doc.moveDown()
          .fontSize(16)
          .fillColor('#2d3748')
          .text('Note Globale', { continued: true })
          .fillColor('#48bb78')
          .text(`: ${analysis.overallScore}/10`, { align: 'right' })
          .moveDown();

        // Scores section with visual presentation
        doc.fontSize(14)
          .fillColor('#2d3748')
          .text('Évaluation Détaillée')
          .moveDown(0.5);

        const scores = [
          { label: 'Fidélité Biblique', score: analysis.scores.fideliteBiblique },
          { label: 'Structure', score: analysis.scores.structure },
          { label: 'Application Pratique', score: analysis.scores.applicationPratique },
          { label: 'Authenticité', score: analysis.scores.authenticite },
          { label: 'Interactivité', score: analysis.scores.interactivite }
        ];

        scores.forEach(({ label, score }) => {
          const barWidth = score * 40; // Scale the bar width based on score
          doc.fontSize(12)
            .fillColor('#4a5568')
            .text(`${label}: ${score}/10`, { continued: false });

          // Draw score bar
          doc.rect(doc.x, doc.y, barWidth, 10)
            .fill('#48bb78');
          doc.moveDown(0.8);
        });

        // Key Insights section
        doc.moveDown()
          .fontSize(16)
          .fillColor('#2d3748')
          .text('Points Clés')
          .moveDown(0.5);

        doc.fontSize(12)
          .fillColor('#4a5568')
          .text(analysis.summary)
          .moveDown();

        // Strengths section with visual bullets
        doc.fontSize(14)
          .fillColor('#2d3748')
          .text('Points Forts')
          .moveDown(0.5);

        analysis.strengths.forEach(strength => {
          doc.fontSize(12)
            .fillColor('#48bb78')
            .text('•', { continued: true })
            .fillColor('#4a5568')
            .text(` ${strength}`)
            .moveDown(0.5);
        });

        // Areas for Improvement with recommendations
        doc.moveDown()
          .fontSize(14)
          .fillColor('#2d3748')
          .text('Recommandations d\'Amélioration')
          .moveDown(0.5);

        analysis.improvements.forEach(improvement => {
          doc.fontSize(12)
            .fillColor('#e53e3e')
            .text('•', { continued: true })
            .fillColor('#4a5568')
            .text(` ${improvement}`)
            .moveDown(0.5);
        });

        // Biblical References section
        doc.moveDown()
          .fontSize(14)
          .fillColor('#2d3748')
          .text('Références Bibliques')
          .moveDown(0.5);

        analysis.keyScriptures.forEach(scripture => {
          doc.fontSize(12)
            .fillColor('#4a5568')
            .text(`• ${scripture}`)
            .moveDown(0.3);
        });

        // Practical Application
        doc.moveDown()
          .fontSize(14)
          .fillColor('#2d3748')
          .text('Applications Pratiques')
          .moveDown(0.5);

        analysis.applicationPoints.forEach(point => {
          doc.fontSize(12)
            .fillColor('#4a5568')
            .text(`• ${point}`)
            .moveDown(0.3);
        });

        // Theological Analysis
        doc.moveDown()
          .fontSize(14)
          .fillColor('#2d3748')
          .text('Analyse Théologique')
          .moveDown(0.5);

        doc.fontSize(12)
          .fillColor('#4a5568')
          .text(`Tradition Théologique: ${analysis.theologicalTradition}`)
          .moveDown();

        // Footer
        doc.fontSize(10)
          .fillColor('#718096')
          .text('TheoCheck - Analyse IA de Sermons', 50, doc.page.height - 50, {
            align: 'center'
          });
      }

      // Finalize PDF
      doc.end();
    } catch (error) {
      console.error("Error generating PDF:", error);
      res.status(500).json({ message: "Erreur lors de la génération du rapport PDF" });
    }
  });
  
  // Newsletter API endpoints
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const { email, userId, locale = 'fr' } = req.body;
      
      if (!email) {
        return res.status(400).json({
          success: false,
          message: "Email is required"
        });
      }
      
      console.log("Attempting to subscribe to newsletter:", { email, userId, locale });
      
      // Vérifier si l'email est déjà inscrit
      const newsletterRef = db.collection('newsletter_subscriptions');
      const existingQuery = await newsletterRef.where('email', '==', email).get();
      
      if (!existingQuery.empty) {
        // Email déjà inscrit, on met à jour le statut si nécessaire
        const docRef = existingQuery.docs[0].ref;
        await docRef.update({
          active: true,
          locale: locale,
          userId: userId || null,
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        
        return res.status(200).json({
          success: true,
          message: "Subscription updated successfully",
          status: "updated"
        });
      }
      
      // Nouvel abonnement
      const docRef = await newsletterRef.add({
        email,
        userId: userId || null,
        active: true,
        locale,
        subscribeDate: admin.firestore.FieldValue.serverTimestamp(),
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      
      console.log("Newsletter subscription created:", docRef.id);
      
      res.status(201).json({
        success: true,
        message: "Subscription successful",
        status: "created",
        id: docRef.id
      });
    } catch (error) {
      console.error("Error during newsletter subscription:", error);
      res.status(500).json({
        success: false,
        message: "Failed to process newsletter subscription",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  
  // API pour vérifier le statut d'un abonnement
  app.get("/api/newsletter/status", async (req, res) => {
    try {
      const email = req.query.email as string;
      
      if (!email) {
        return res.status(400).json({
          success: false,
          message: "Email is required"
        });
      }
      
      const newsletterRef = db.collection('newsletter_subscriptions');
      const query = await newsletterRef.where('email', '==', email).where('active', '==', true).get();
      
      res.status(200).json({
        success: true,
        subscribed: !query.empty
      });
    } catch (error) {
      console.error("Error checking newsletter status:", error);
      res.status(500).json({
        success: false,
        message: "Failed to check subscription status",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  
  // API pour désabonner
  app.post("/api/newsletter/unsubscribe", async (req, res) => {
    try {
      const { email, userId } = req.body;
      
      if (!email && !userId) {
        return res.status(400).json({
          success: false,
          message: "Email or userId is required"
        });
      }
      
      const newsletterRef = db.collection('newsletter_subscriptions');
      let query;
      
      if (email) {
        query = await newsletterRef.where('email', '==', email).get();
      } else {
        query = await newsletterRef.where('userId', '==', userId).get();
      }
      
      if (query.empty) {
        return res.status(404).json({
          success: false,
          message: "Subscription not found"
        });
      }
      
      // Mettre à jour le document
      const docRef = query.docs[0].ref;
      await docRef.update({
        active: false,
        unsubscribeDate: admin.firestore.FieldValue.serverTimestamp()
      });
      
      res.status(200).json({
        success: true,
        message: "Unsubscribed successfully"
      });
    } catch (error) {
      console.error("Error during newsletter unsubscription:", error);
      res.status(500).json({
        success: false,
        message: "Failed to process unsubscription",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

interface UserPreferences {
  favoriteTopics: string[];
  theologicalTradition: string;
  preferredStyle: string;
  lastViewedSermons: number[];
}

interface LocalSermon {
  id: number;
  userId: string;
  content: string;
  title: string;
  createdAt: Date;
  analysis?: SermonAnalysis;
}


function calculateRecommendationScore(sermon: any, preferences: UserPreferences): number {
  let score = 0;

  // Topic matching
  if (sermon.analysis?.topics) {
    const matchingTopics = sermon.analysis.topics.filter((topic: string) =>
      preferences.favoriteTopics.includes(topic)
    );
    score += matchingTopics.length * 2;
  }

  // Theological tradition matching
  if (sermon.analysis?.theologicalTradition === preferences.theologicalTradition) {
    score += 3;
  }

  // Quality score bonus
  if (sermon.analysis?.overallScore) {
    score += sermon.analysis.overallScore / 2;
  }

  return score;
}

// Note: Sermon analysis now uses the hybrid analysis system from analysis-prompts.ts
// These old prompts have been removed as they're no longer used

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY is required");
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });