# TheoCheck - Multilingual AI-Powered Sermon Analysis Platform

## Overview

TheoCheck is a multilingual AI-powered sermon analysis platform designed to help pastors and Christian leaders analyze their sermons using advanced AI technology. The platform provides detailed theological analysis, practical feedback, and actionable insights to improve sermon quality and delivery.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Internationalization**: React-i18next supporting French and English

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with tsx for execution
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Firebase Authentication with Google Sign-in
- **Payment Processing**: Stripe integration for donations
- **AI Integration**: OpenAI GPT-4 for sermon analysis

### Key Components

#### Authentication System
- Firebase Authentication for user management
- Google OAuth integration
- JWT token-based API authentication
- User session management

#### Sermon Analysis Engine
- **Hybrid Prompt Chain System**: Multi-agent analysis architecture
- **6 Specialized Agents**:
  1. **Structure Sequencing Agent**: Segments sermon into introduction, main parts, conclusion
  2. **Introduction Analysis Agent**: Analyzes introduction based on 5 criteria
  3. **Main Part Analysis Agents**: Analyzes each main part individually
  4. **Conclusion Analysis Agent**: Analyzes conclusion based on 5 criteria
  5. **Biblical Accuracy Specialist**: Focuses exclusively on biblical fidelity
  6. **Final Synthesis Agent**: Compiles all analyses into final report
- **Parallel Processing**: Multiple agents work simultaneously for faster analysis
- **Comprehensive Evaluation**: Same 5 criteria system maintained
- **Multilingual Support**: French/English analysis capabilities

#### Database Layer
- PostgreSQL for primary data storage
- Drizzle ORM for type-safe database operations
- Firebase Firestore for real-time analytics and KPI tracking
- Schema includes: users, sermons, donations, sharing events, analytics

#### Payment System
- Stripe integration for donation processing
- Payment intent creation and verification
- Secure webhook handling for payment confirmations

## Data Flow

The application follows a typical client-server architecture:

1. **User Authentication**: Users authenticate via Firebase Auth
2. **Sermon Submission**: Users submit sermons through React frontend
3. **AI Analysis**: Backend processes sermons using OpenAI GPT-4
4. **Data Storage**: Analysis results stored in PostgreSQL
5. **Real-time Updates**: Analytics tracked in Firebase Firestore
6. **Payment Processing**: Donations handled via Stripe integration

## External Dependencies

### Core Services
- **OpenAI API**: GPT-4 for sermon analysis and feedback generation
- **Firebase**: Authentication, Firestore for analytics
- **Stripe**: Payment processing for donations
- **PostgreSQL**: Primary database (configured via Drizzle)

### Development Tools
- **Vite**: Build tool and development server
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Component library built on Radix UI
- **TypeScript**: Type safety across the entire stack

## Deployment Strategy

The application is designed for modern deployment platforms:

- **Build Process**: Vite builds the frontend, esbuild bundles the backend
- **Environment Variables**: Configured for Firebase, Stripe, OpenAI, and database credentials
- **Static Assets**: Frontend built to `dist/public` directory
- **API Routes**: Express server handles all `/api/*` routes
- **Database**: PostgreSQL with Drizzle migrations

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Changelog

```
Changelog:
- July 05, 2025. Initial setup
- July 05, 2025. Implemented Hybrid Prompt Chain System for sermon analysis
  - Created 6 specialized AI agents for comprehensive analysis
  - Added parallel processing for faster analysis
  - Maintained same 5-criteria evaluation system
  - Enhanced biblical accuracy analysis with dedicated specialist agent
- July 05, 2025. Fixed "échec de l'analyse du sermon" error
  - Added robust JSON parsing error handling in hybrid analysis service
  - Implemented safe fallback responses for all AI agents
  - Enhanced error recovery with regex-based JSON extraction
  - Eliminated unterminated JSON string parsing errors
```